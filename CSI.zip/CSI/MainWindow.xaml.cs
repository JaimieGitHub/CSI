﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xaml;
using System.Data;
using System.IO;
#pragma warning disable CS0105 // The using directive for 'System.Collections.Generic' appeared previously in this namespace
using System.Collections.Generic;
#pragma warning restore CS0105 // The using directive for 'System.Collections.Generic' appeared previously in this namespace
using MahApps.Metro.Controls;
using System.Resources;
using System.Collections;
using System.Reflection;
using System.Runtime.InteropServices;
using Newtonsoft.Json;

namespace CSI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 


    public partial class MainWindow : MetroWindow
    {

        DataSet TeluguDataset = new DataSet();
        Window1 wn = new Window1();

        DataSet EnglishDataset = new DataSet();
        string BookName = "";
        string Chapter = "";
        string ChapterID = "";
        private List<string> EnglishSongList;
        private List<string> TeluguSongList;
        public MainWindow()
        {

            InitializeComponent();
            fillSonglist();//English song titles 
            fillTeluguSongslList();//Telugu song titles
            fillBooks();
            object obj = new object();
            getTSongs("1");
            getESongs("1");

            //  getTSongsTitles();
            DataContext = this;



        }

        private void getTSongsTitles()
        {
#pragma warning disable CS0168 // The variable 'Text' is declared but never used
            string Text;
#pragma warning restore CS0168 // The variable 'Text' is declared but never used
#pragma warning disable CS0168 // The variable 'para' is declared but never used
            string[] para;
#pragma warning restore CS0168 // The variable 'para' is declared but never used
#pragma warning disable CS0168 // The variable 'nTExt' is declared but never used
            string nTExt;
#pragma warning restore CS0168 // The variable 'nTExt' is declared but never used
            StringBuilder strbldr = new StringBuilder();
            //    System.IO.StreamReader reader;
            StreamWriter sw = new StreamWriter(@"C:\temp\t.txt");
            for (int i = 1; i < 430; i++)
            {

                //   reader = new System.IO.StreamReader(@"TS\" + i + ".json");

                using (StreamReader file = File.OpenText(@"TS\" + i + ".json"))
                using (JsonTextReader reader = new JsonTextReader(file))
                {
                    Newtonsoft.Json.Linq.JObject o2 = (Newtonsoft.Json.Linq.JObject)Newtonsoft.Json.Linq.JToken.ReadFrom(reader);
                    // 
                    string title;
                    //"ragam":"కాంభోజి","SongId":"1","thalam":"ఆట","author":"బేళాళ జాన్","Album"
                    string ragam;
#pragma warning disable CS0168 // The variable 'SongId' is declared but never used
                    string SongId;
#pragma warning restore CS0168 // The variable 'SongId' is declared but never used
                    string thalam;
                    string author;
                    string verse;
                    Newtonsoft.Json.Linq.JArray a = (Newtonsoft.Json.Linq.JArray)o2["Verses"];
                    int cnt = a.Count;
                    title = (string)o2.SelectToken("title");
                    ragam = (string)o2.SelectToken("ragam");
                    thalam = (string)o2.SelectToken("thalam");
                    author = (string)o2.SelectToken("author");
                    //for (int ji = 0; ji <= cnt; ji++)
                    {
                        verse = (string)o2.SelectToken("Verses[" + 0 + "]");
                    }

                    sw.WriteLine(i.ToString() + ": " + verse);


                }
            }
        }

        private void fillSonglist()
        {
            EnglishSongList = new List<string>();
            EnglishSongList.Add("	1: O FOR a thousand tongues to sing	".Trim());
            EnglishSongList.Add("	2: ALL people that on earth do dwell,	".Trim());
            EnglishSongList.Add("	3: BEFORE Jehovah's awful throne,	".Trim());
            EnglishSongList.Add("	4: FROM all that dwell below the skies	".Trim());
            EnglishSongList.Add("	5: LET all the world In every corner sing :	".Trim());
            EnglishSongList.Add("	6: ENTERNAL Power! whose high abode	".Trim());
            EnglishSongList.Add("	7: O HEAVENLY King, look down from above;	".Trim());
            EnglishSongList.Add("	8: O WORSHIP the King,	".Trim());
            EnglishSongList.Add("	9: O WORSHIP the Lord in the beauty of holiness!	".Trim());
            EnglishSongList.Add("	10: NOW thank we all our God,	".Trim());
            EnglishSongList.Add("	11: WITH gladness we worship,rejoice as we sing,	".Trim());
            EnglishSongList.Add("	12: PRAISE,my soul,the  King  of heaven,	".Trim());
            EnglishSongList.Add("	13:GLORIA IN  EXCELSIS	".Trim());
            EnglishSongList.Add("	14: PRAISE the Lord who reigns above,	".Trim());
            EnglishSongList.Add("	15: PRAISE to the  living  God!	".Trim());
            EnglishSongList.Add("	16: RAISE the psalm: let earth adoring,	".Trim());
            EnglishSongList.Add("	17: MEET and right it IS to sing;	".Trim());
            EnglishSongList.Add("	18: LET us with a gladsome mind	".Trim());
            EnglishSongList.Add("	19: PRAlSE, O praise our God and King	".Trim());
            EnglishSongList.Add("	20: COME, O come, in pious lays	".Trim());
            EnglishSongList.Add("	21: THE God of Abraham praise,	".Trim());
            EnglishSongList.Add("	22: COME, let us all unite and sing God is love	".Trim());
            EnglishSongList.Add("	23: KING of glory, King of peace,	".Trim());
            EnglishSongList.Add("	24:  O GOD, my strength and fortitude,	".Trim());
            EnglishSongList.Add("	25: ROUND the Lord In glory seated,	".Trim());
            EnglishSongList.Add("	26: YE holy angels bright,	".Trim());
            EnglishSongList.Add("	27: ANGELS holy, High and lowly,	".Trim());
            EnglishSongList.Add("	28: ANGELS holy, High and lowly,	".Trim());
            EnglishSongList.Add("	29: ALL things praise Thee,Lord most high;	".Trim());
            EnglishSongList.Add("	30: FROM glory to glory advancing,	".Trim());
            EnglishSongList.Add("	31: GOD reveals His presence :	".Trim());
            EnglishSongList.Add("	32: LORD of all being, throned afar,	".Trim());
            EnglishSongList.Add("	33: TNFINITE God, to Thee we raise	".Trim());
            EnglishSongList.Add("	34: IMMORTAL, Invisible, God  only wise,	".Trim());
            EnglishSongList.Add("	35: FOR the beauty of the earth,	".Trim());
            EnglishSongList.Add("	36: HOLY, holy,holy,Lord God Almighty !	".Trim());
            EnglishSongList.Add("	37: HAIL! holy, holy, holy Lord!	".Trim());
            EnglishSongList.Add("	38: FATHER of heaven, whose love profound	".Trim());
            EnglishSongList.Add("	39: FATHER, In whom we live,	".Trim());
            EnglishSongList.Add("	40: WE give immortal praise	".Trim());
            EnglishSongList.Add("	41: GOD Is a name my soul adores,	".Trim());
            EnglishSongList.Add("	42: O GOD, Thou bottomless abyss !	".Trim());
            EnglishSongList.Add("	43: THERE is a book, who runs may read,	".Trim());
            EnglishSongList.Add("	44: THE spacious firmament on high.	".Trim());
            EnglishSongList.Add("	45: MY soul, praise the Lord!	".Trim());
            EnglishSongList.Add("	46: I SING the almighty power of God,	".Trim());
            EnglishSongList.Add("	47: FATHER of all I  whose powerful voice	".Trim());
            EnglishSongList.Add("	48: HIGH in the heavens, eternal God,	".Trim());
            EnglishSongList.Add("	49:  THY ceaseless, unexhausted love,	".Trim());
            EnglishSongList.Add("	50: THE Lord's my Shepherd, I'll not want;	".Trim());
            EnglishSongList.Add("	51: THE God of love my Shepherd Is,	".Trim());
            EnglishSongList.Add("	52: O LOVE of God, how strong and true;	".Trim());
            EnglishSongList.Add("	53: GOD Is love : His mercy brightens	".Trim());
            EnglishSongList.Add("	54: MY soul, repeat His praise	".Trim());
            EnglishSongList.Add("	55: LORD God, by whom all change Is wrought,	".Trim());
            EnglishSongList.Add("	56: SWEET Is  the memory of Thy grace,	".Trim());
            EnglishSongList.Add("	57: IN all my vast concerns with Thee,	".Trim());
            EnglishSongList.Add("	58: THE Lord Jehovah reigns;	".Trim());
            EnglishSongList.Add("	59: GOOD Thou art, and good Thou dost,	".Trim());
            EnglishSongList.Add("	60: ERE God had built the mountains,	".Trim());
            EnglishSongList.Add("	61: EARTH,with all thy thousand voices,	".Trim());
            EnglishSongList.Add("	62: O LOVE, how deep, how broad,how high	".Trim());
            EnglishSongList.Add("	63: ETERNAL depth of love divine,	".Trim());
            EnglishSongList.Add("	64: PRAISE to the Lord, the Almighty,	".Trim());
            EnglishSongList.Add("	65: O GOD of God, in whom combine,	".Trim());
            EnglishSongList.Add("	66: O GOD of all grace,	".Trim());
            EnglishSongList.Add("	67: O GOD, of good the unfathomed seal	".Trim());
            EnglishSongList.Add("	68: NONE Is like Jeshurun's God,	".Trim());
            EnglishSongList.Add("	69: THIS, this Is the God we adore,	".Trim());
            EnglishSongList.Add("	70: ALL my hope on God Is founded;	".Trim());
            EnglishSongList.Add("	71: WE come unto our fathers' God;	".Trim());
            EnglishSongList.Add("	72: BEGIN, my soul, some heavenly theme;	".Trim());
            EnglishSongList.Add("	73: MY God, how wonderful Thou art,	".Trim());
            EnglishSongList.Add("	74: PRAISE to the Holiest in the height,	".Trim());
            EnglishSongList.Add("	75: FATHER, whose everlasting love	".Trim());
            EnglishSongList.Add("	76: THE King of love my Shepherd is,	".Trim());
            EnglishSongList.Add("	77: WHAT shall I do my God to love,	".Trim());
            EnglishSongList.Add("	78: HOW shall I sing that majesty	".Trim());
            EnglishSongList.Add("	79: PRAISE ye the Lord! Tis good to raise	".Trim());
            EnglishSongList.Add("	80: THEE will I praise with all my heart,	".Trim());
            EnglishSongList.Add("	81: NOT what what these hands have done	".Trim());
            EnglishSongList.Add("	82: HARK the glad sound! the Saviour comes,	".Trim());
            EnglishSongList.Add("	83: Of the Father's love begotten	".Trim());
            EnglishSongList.Add("	84: ALL glory, laud, and honour	".Trim());
            EnglishSongList.Add("	85: COME,letus Join OUT cheerful songs	".Trim());
            EnglishSongList.Add("	86: STRONG  Son  of  God,  immortal Love,	".Trim());
            EnglishSongList.Add("	87: JESUS comes with all His grace,	".Trim());
            EnglishSongList.Add("	88: WE know, by faith we surely know,	".Trim());
            EnglishSongList.Add("	89: CHRIST,of all my hopes   the ground,	".Trim());
            EnglishSongList.Add("	90: OBJECT of my first desire,	".Trim());
            EnglishSongList.Add("	91: ALL hall the power of Jesu's name;	".Trim());
            EnglishSongList.Add("	92:  JESUS! the name high over all,	".Trim());
            EnglishSongList.Add("	93: TO the Name of our salvation,	".Trim());
            EnglishSongList.Add("	94: NONE  other  Lamb, none  other Name,	".Trim());
            EnglishSongList.Add("	95: JESUS, Sun and Shield art Thou,	".Trim());
            EnglishSongList.Add("	96: JOIN all the glorious names	".Trim());
            EnglishSongList.Add("	97: O FILIAL Deity,	".Trim());
            EnglishSongList.Add("	98: THOU hidden Source of calm repose,	".Trim());
            EnglishSongList.Add("	99: HOW sweet  the  name of Jesus sounds	".Trim());
            EnglishSongList.Add("	100: ONE there Is above all others,	".Trim());
            EnglishSongList.Add("	101: TEST of the weary,	".Trim());
            EnglishSongList.Add("	102: IMMORTAL Love, for ever full,	".Trim());
            EnglishSongList.Add("	103: O LORD and Master of us all,	".Trim());
            EnglishSongList.Add("	104:  THOU great Redeemer, dying Lamb,	".Trim());
            EnglishSongList.Add("	105: JESUS, the First and Last,	".Trim());
            EnglishSongList.Add("	106: JESU The very thought is sweet,	".Trim());
            EnglishSongList.Add("	107: O JESUS, King most wonderful!	".Trim());
            EnglishSongList.Add("	108: JESU, the very thought of Thee ,	".Trim());
            EnglishSongList.Add("	109: JESU, Thou Joy of loving hearts,	".Trim());
            EnglishSongList.Add("	110: JESUS, Lover of my soul,	".Trim());
            EnglishSongList.Add("	111: JESUS, these eyes have never seen	".Trim());
            EnglishSongList.Add("	112: I BLESS the Christ of God;	".Trim());
            EnglishSongList.Add("	113: WHEN morning gilds the skies,	".Trim());
            EnglishSongList.Add("	114: LET earth and heaven agree,	".Trim());
            EnglishSongList.Add("	115: MY heart and voice I raise,	".Trim());
            EnglishSongList.Add("	116: SING we the King who Is coming to reign,	".Trim());
            EnglishSongList.Add("	117: HARK! the herald-angels sing	".Trim());
            EnglishSongList.Add("	118:  O COME, all ye faithful,	".Trim());
            EnglishSongList.Add("	119: ANGELS from the realms of glory,	".Trim());
            EnglishSongList.Add("	120: CHRISTIANS, awake, salute the	".Trim());
            EnglishSongList.Add("	121: ALL my heart this night rejoices,	".Trim());
            EnglishSongList.Add("	122: BRIGBTEST and best	".Trim());
            EnglishSongList.Add("	123:  STILL the night, holy the night!	".Trim());
            EnglishSongList.Add("	124:  SEE, amid the winter's snow,	".Trim());
            EnglishSongList.Add("	125:  LITTLE town of Bethlehem,	".Trim());
            EnglishSongList.Add("	126:  GIVE heed, my heart, lift up thine eyes:	".Trim());
            EnglishSongList.Add("	127:  CRADLED In a manger, meanly	".Trim());
            EnglishSongList.Add("	128: A VIRGIN most pure,as the prophets do tell,	".Trim());
            EnglishSongList.Add("	129: WHILE shepherds watched their flocks by night,	".Trim());
            EnglishSongList.Add("	130: IT came upon the midnight clear,	".Trim());
            EnglishSongList.Add("	131:  THE first Nowell the angel did say	".Trim());
            EnglishSongList.Add("	132: AS with gladness men of old	".Trim());
            EnglishSongList.Add("	133: FROM the eastern mountains	".Trim());
            EnglishSongList.Add("	134: GLORY be to God on high,	".Trim());
            EnglishSongList.Add("	135: STUPENDOUS height of heavenly love,	".Trim());
            EnglishSongList.Add("	136: THE Maker of the stin and moon,	".Trim());
            EnglishSongList.Add("	137: IN the bleak mid-winter,	".Trim());
            EnglishSongList.Add("	138: LOVE came down at Christmas,	".Trim());
            EnglishSongList.Add("	139: THE race that Jong in darkness pined	".Trim());
            EnglishSongList.Add("	140: GOD from on high hath heard;	".Trim());
            EnglishSongList.Add("	141: To us a child of royal birth,	".Trim());
            EnglishSongList.Add("	142: LET earth and heaven combine,	".Trim());
            EnglishSongList.Add("	143: GOOD Christian men, rejoice	".Trim());
            EnglishSongList.Add("	144: MY song Is love unknown;	".Trim());
            EnglishSongList.Add("	145: WHAT grace, O Lord, and beauty shone	".Trim());
            EnglishSongList.Add("	146: JESUS, who lived above the sky,	".Trim());
            EnglishSongList.Add("	147: WHEN the Lord of Love was here,	".Trim());
            EnglishSongList.Add("	148: WE saw  Thee  not  when  Thou didst come	".Trim());
            EnglishSongList.Add("	149: AND didst Thou love the race that loved not Thee?	".Trim());
            EnglishSongList.Add("	150: THOU dldst leave Thy throne	".Trim());
            EnglishSongList.Add("	151: WHO Is He, In yonder stall,	".Trim());
            EnglishSongList.Add("	152: WHAT means this eager, anxious throng,	".Trim());
            EnglishSongList.Add("	153: JESUS, Thy far-extended fame	".Trim());
            EnglishSongList.Add("	154: I HEARD the voice of Jesus say :	".Trim());
            EnglishSongList.Add("	155: HEAL us,Immanuel; hear  our prayer;	".Trim());
            EnglishSongList.Add("	156: O THOU, whom once they flocked to hear,	".Trim());
            EnglishSongList.Add("	157: JESUS calls us! O'er the tumult	".Trim());
            EnglishSongList.Add("	158: THOU say'st: Take up thy cross,	".Trim());
            EnglishSongList.Add("	159: ONE who is all unfit to count	".Trim());
            EnglishSongList.Add("	160: THOU art the Way : to Thee alone	".Trim());
            EnglishSongList.Add("	161: TELL me the old, old story	".Trim());
            EnglishSongList.Add("	162: THOU art my life;if Thou but turn away,	".Trim());
            EnglishSongList.Add("	163: DEAR Master, in whose life I see	".Trim());
            EnglishSongList.Add("	164: BEHOLD a little Child,	".Trim());
            EnglishSongList.Add("	165: FORTY days and forty nights	".Trim());
            EnglishSongList.Add("	166: IT fell upon a summer day,	".Trim());
            EnglishSongList.Add("	167: FIERCE raged  the tempest o'er the deep,	".Trim());
            EnglishSongList.Add("	168: LORD! It is good for us to be	".Trim());
            EnglishSongList.Add("	169: MY Saviour, Thou Thy love to me	".Trim());
            EnglishSongList.Add("	170: O THE bitter shame and sorrow,	".Trim());
            EnglishSongList.Add("	171: JESUS. I will  trust Thee,trust	".Trim());
            EnglishSongList.Add("	172: WITH glorious clouds encompassed round,	".Trim());
            EnglishSongList.Add("	173: Would jesus have the sinner die?	".Trim());
            EnglishSongList.Add("	174: I MET the good Shepherd	".Trim());
            EnglishSongList.Add("	175: WEEP not for Him who onward  bears	".Trim());
            EnglishSongList.Add("	176: MAN of Sorrows!   What a name	".Trim());
            EnglishSongList.Add("	177: AH, holy Jesu, how hast  Thou offended,	".Trim());
            EnglishSongList.Add("	178:  WHEN my love to Christ grows weak,	".Trim());
            EnglishSongList.Add("	179: PLUNGED in a gulf of dark despair	".Trim());
            EnglishSongList.Add("	180: THERE is a green hill far away,	".Trim());
            EnglishSongList.Add("	181:  LAMB of God, whose dying love	".Trim());
            EnglishSongList.Add("	182: WHEN  I survey  the   wondrous cross	".Trim());
            EnglishSongList.Add("	183: IN the Cross of Christ I glory:	".Trim());
            EnglishSongList.Add("	184:  THE royal banners forward go;	".Trim());
            EnglishSongList.Add("	185: AT the Cross, her station keeping,	".Trim());
            EnglishSongList.Add("	186: O LOVE divine I what hast Thou done?	".Trim());
            EnglishSongList.Add("	187: O COME and mourn  with  me awhile;	".Trim());
            EnglishSongList.Add("	188:  ALL ye that pass by,	".Trim());
            EnglishSongList.Add("	189:  THRONED upon the awful Tree,	".Trim());
            EnglishSongList.Add("	190: O  PERFECT life of love!	".Trim());
            EnglishSongList.Add("	191: GOD of unexampled grace,	".Trim());
            EnglishSongList.Add("	192: RIDE on, ride on in majesty!	".Trim());
            EnglishSongList.Add("	193: BEHOLD the Saviour of mankind	".Trim());
            EnglishSongList.Add("	194:  GO to dark Gethsemane,	".Trim());
            EnglishSongList.Add("	195: HE dies! the Friend ol Sinners dies!	".Trim());
            EnglishSongList.Add("	196: We sing the praise of Him who died,	".Trim());
            EnglishSongList.Add("	197: BENEATH the Cross of Jesus	".Trim());
            EnglishSongList.Add("	198:  NEVER further than Thy Cross,	".Trim());
            EnglishSongList.Add("	199: JESUS, keep me near the Cross;	".Trim());
            EnglishSongList.Add("	200: O JESUS, my hope,	".Trim());
            EnglishSongList.Add("	201: THERE is a fountain filled with blood	".Trim());
            EnglishSongList.Add("	202: O SACRED Head once  wounded,	".Trim());
            EnglishSongList.Add("	203: How shall a sinner find	".Trim());
            EnglishSongList.Add("	204: CHRIST the Lord is risen to-day; Halleluiah!	".Trim());
            EnglishSongList.Add("	205:  JESUS CHRIST is risen to-day,	".Trim());
            EnglishSongList.Add("	206: CHRIST is risen! Hallelujah!	".Trim());
            EnglishSongList.Add("	207: CHRIST the Lord is risen again;	".Trim());
            EnglishSongList.Add("	208: THE day of resurrection!	".Trim());
            EnglishSongList.Add("	209: ON wings of living light,	".Trim());
            EnglishSongList.Add("	210:  CHRIST JESUS lay in death's strong bands	".Trim());
            EnglishSongList.Add("	211:  LOW in the grave He lay,	".Trim());
            EnglishSongList.Add("	212: WELCOME, happy morning!Age to age shall say :	".Trim());
            EnglishSongList.Add("	213: THINE be the glory, risen,conquering Son,	".Trim());
            EnglishSongList.Add("	214:  AWAKE, glad soul, awake, awake!	".Trim());
            EnglishSongList.Add("	215: THE strife is o'er, the battle done;	".Trim());
            EnglishSongList.Add("	216: JESUS lives! thy terrors now	".Trim());
            EnglishSongList.Add("	217: YE humble souls that seek the Lord,	".Trim());
            EnglishSongList.Add("	218: THE foe behind, the deep before,	".Trim());
            EnglishSongList.Add("	219:  GOD is gone up on high,	".Trim());
            EnglishSongList.Add("	220: GOD is ascended up on high,	".Trim());
            EnglishSongList.Add("	221: HAIL the day that sees Him rise,	".Trim());
            EnglishSongList.Add("	222: OUR Lord is risen from the dead!	".Trim());
            EnglishSongList.Add("	223: SEE the Conqueror mounts in triumph,	".Trim());
            EnglishSongList.Add("	224: THE golden gates are lifted up,	".Trim());
            EnglishSongList.Add("	225:  CHRIST,  above  all  glory seated!	".Trim());
            EnglishSongList.Add("	226: LOOK,ye  saints!The sight is glorious.	".Trim());
            EnglishSongList.Add("	227:1 CONQUERING Prince and Lord of glory,	".Trim());
            EnglishSongList.Add("	228: TAIL, Thou once despisgd Jesus!	".Trim());
            EnglishSongList.Add("	229: YE faithful souls who Jesus know,	".Trim());
            EnglishSongList.Add("	230: REJOICE    and    be    glad!     the	".Trim());
            EnglishSongList.Add("	231: AWAY with gloom,away with doubt!	".Trim());
            EnglishSongList.Add("	232:  ENTERED the holy place above,	".Trim());
            EnglishSongList.Add("	233: JESUS, to Thee we fly,	".Trim());
            EnglishSongList.Add("	234: NOT all the blood of beasts	".Trim());
            EnglishSongList.Add("	235: I KNOW that my Redeemer lives—	".Trim());
            EnglishSongList.Add("	236: WITH joy we meditate the grace	".Trim());
            EnglishSongList.Add("	237: THERE is no sorrow,Lord,too light	".Trim());
            EnglishSongList.Add("	238: MY faith looks up to Thee,	".Trim());
            EnglishSongList.Add("	239: LORD Jesus, think on me,	".Trim());
            EnglishSongList.Add("	240: O WORD of pity, for our pardon pleading,	".Trim());
            EnglishSongList.Add("	241: O SON of Man, our hero strong and tender,	".Trim());
            EnglishSongList.Add("	242: COME, Thou long-expected Jesus,	".Trim());
            EnglishSongList.Add("	243: JESUS, the Conqueror, reigns,	".Trim());
            EnglishSongList.Add("	244: THE head that once was crowned	".Trim());
            EnglishSongList.Add("	245: HAIL to the Lord's Anointed;	".Trim());
            EnglishSongList.Add("	246: EARTH, rejoice, our Lord is King!	".Trim());
            EnglishSongList.Add("	247: REJOICE, the Lord is King!	".Trim());
            EnglishSongList.Add("	248: JESU, the word bestow,	".Trim());
            EnglishSongList.Add("	249: IN the Name of Jesus	".Trim());
            EnglishSongList.Add("	250: SALVATION! O the Joyful sound!	".Trim());
            EnglishSongList.Add("	251: OMNIPOTENT  Redeemer,	".Trim());
            EnglishSongList.Add("	252: GOD is with us, God is with us,	".Trim());
            EnglishSongList.Add("	253: BREAK,day of God,O break,	".Trim());
            EnglishSongList.Add("	254: HARK what a sound,and too	".Trim());
            EnglishSongList.Add("	255: WAKE, awake, for night lsflying!	".Trim());
            EnglishSongList.Add("	256: THERE'S a light upon the mountains,	".Trim());
            EnglishSongList.Add("	257:  COME, O come, Immanuel,	".Trim());
            EnglishSongList.Add("	258: THOU art coming, O my Saviour,	".Trim());
            EnglishSongList.Add("	259: AND art Thou come with us to dwell,	".Trim());
            EnglishSongList.Add("	260: MINE eyes have seen the glory of	".Trim());
            EnglishSongList.Add("	261: LIGHT of those whose dreary dwelling	".Trim());
            EnglishSongList.Add("	262:  ALL thanks be to God,	".Trim());
            EnglishSongList.Add("	263: SEE how great a flame aspires,	".Trim());
            EnglishSongList.Add("	264:  LO He comes with clouds descending,	".Trim());
            EnglishSongList.Add("	265: LIFT up your heads, ye gates of brass,	".Trim());
            EnglishSongList.Add("	266: FROM north and south and east and west,	".Trim());
            EnglishSongList.Add("	267: LORD, her watch Thy Church is keeping;	".Trim());
            EnglishSongList.Add("	268:  LIGHT of the lonely  pilgrim's heart,	".Trim());
            EnglishSongList.Add("	269: SAVIOUR, we know Thou art	".Trim());
            EnglishSongList.Add("	270:  MY heart is full of Christ, and longs	".Trim());
            EnglishSongList.Add("	271: CROWN Him with many crowns,	".Trim());
            EnglishSongList.Add("	272: JESUS shall reign where'er the sun	".Trim());
            EnglishSongList.Add("	273: COME down, O Love Divine,	".Trim());
            EnglishSongList.Add("	274: LORD,we believe to us and ours	".Trim());
            EnglishSongList.Add("	275: JESUS, we on the word depend	".Trim());
            EnglishSongList.Add("	276: WHEN God of old came down from heaven, ".Trim());

            EnglishSongList.Add("	277:  GRANTED is the Saviours prayer,	".Trim());
            EnglishSongList.Add("	278:  AWAY with our fears,	".Trim());
            EnglishSongList.Add("	279:  HOLY  Spirit, God,	".Trim());
            EnglishSongList.Add("	280:  I WANT the Spirit of power within,	".Trim());
            EnglishSongList.Add("	281:l.Go  not, my soul,In search of Him,	".Trim());
            EnglishSongList.Add("	282: SPIRIT of wisdom, turn our eyes	".Trim());
            EnglishSongList.Add("	283: OUR blest Redeemer,ere He breathed    ".Trim());

            EnglishSongList.Add("	284: FATHER, if Justly still we claim  ".Trim());
            EnglishSongList.Add("	285:  BREATH of God, breathe on us now,	".Trim());
            EnglishSongList.Add("	286: HOLY Spirit, hear us;	".Trim());
            EnglishSongList.Add("	287:  HOLY  Ghost, my Comforter,	".Trim());
            EnglishSongList.Add("	288: HOLY Spirit, truth Divine,	".Trim());
            EnglishSongList.Add("	289:  SPIRIT divine, attend our prayers	".Trim());
            EnglishSongList.Add("	290:  GRACIOUS Spirit, Holy Ghost,	".Trim());
            EnglishSongList.Add("	291: GRACIOUS Spirit,dwell with me!	".Trim());
            EnglishSongList.Add("	292: COME, Holy Spirit, heavenly Dove,	".Trim());
            EnglishSongList.Add("	293: CREATOR Spirit; by whose aid	".Trim());
            EnglishSongList.Add("	294: COME, holy celestial Dove,	".Trim());
            EnglishSongList.Add("	295: SPIRIT blest, who art adored	".Trim());
            EnglishSongList.Add("	296:1 TJ  HOLY Spirit pity me,	".Trim());
            EnglishSongList.Add("	297: COME to our poor nature's night	".Trim());
            EnglishSongList.Add("	298: LORD God the Holy Ghost,	".Trim());
            EnglishSongList.Add("	299: COME,Holy Ghost,all-quickening fire,	".Trim());
            EnglishSongList.Add("	300: BREATHE on me, Breath of God;	".Trim());
            EnglishSongList.Add("	301: ON all the earth Thy Spirit shower;	".Trim());
            EnglishSongList.Add("	302: FATHER of mercies,in Thy word	".Trim());
            EnglishSongList.Add("	303: WORD of God Incarnate,	".Trim());
            EnglishSongList.Add("	304: FATHER of all, in whom alone  ".Trim());

            EnglishSongList.Add("	305:  COME, Holy Ghost, our hearts inspire,	".Trim());
            EnglishSongList.Add("	306: COME, divine Interpreter,	".Trim());
            EnglishSongList.Add("	307: THE Spirit breathes upon the word,	".Trim());
            EnglishSongList.Add("	308: LORD, Thy word abideth,	".Trim());
            EnglishSongList.Add("	309: BREAK Thou the bread of life,	".Trim());
            EnglishSongList.Add("	310: WHEN quiet in my house I sit,	".Trim());
            EnglishSongList.Add("	311:  THY faithfulness,Lord,each moment we find,	".Trim());
            EnglishSongList.Add("	312: BEHOLD the Lamb of God, who bears ".Trim());

            EnglishSongList.Add("	313: TO God be the glory! great things He hath done !	".Trim());
            EnglishSongList.Add("	314: COME let us sing of a wonderful love,	".Trim());
            EnglishSongList.Add("	315: HARK the gospel news is soundIng :	".Trim());
            EnglishSongList.Add("	316: WE have heard a Joyful sound :	".Trim());
            EnglishSongList.Add("	317: WHOSOEVER heareth  Shout,shout the sound;	".Trim());
            EnglishSongList.Add("	318: SOULS of men,scatter	".Trim());
            EnglishSongList.Add("	319: WEARY souls that wander wide	".Trim());
            EnglishSongList.Add("	320: ART thou weary, art languid,	".Trim());
            EnglishSongList.Add("	321: LORD, I hear of showers of blessing	".Trim());
            EnglishSongList.Add("	322: SINNERS Jesus will receive;	".Trim());
            EnglishSongList.Add("	323: COME, sinners, to the gospel feast,	".Trim());
            EnglishSongList.Add("	324: COME,ye sinners,poor and wretched,	".Trim());
            EnglishSongList.Add("	325: COME, ye sinners, to your Lord,	".Trim());
            EnglishSongList.Add("	326: SINNERS, obey the gospel word;	".Trim());
            EnglishSongList.Add("	327: SINNERS,turn;why will ye die?	".Trim());
            EnglishSongList.Add("	328: COME unto Me, ye weary,	".Trim());
            EnglishSongList.Add("	329:1 YE neighbours and friends of Jesus draw near: ".Trim());

            EnglishSongList.Add("	330: O JESUS, Thou art standing	".Trim());
            EnglishSongList.Add("	331: Behold Me standing at the door,	".Trim());
            EnglishSongList.Add("	332: BEHOLD!a Stranger at the door!".Trim());

            EnglishSongList.Add("	333: COME let us, who In Christ believe,	".Trim());
            EnglishSongList.Add("	334: THERE were ninety and nine that safely lay	".Trim());
            EnglishSongList.Add("	335: PASS me not, O gentle Saviour,	".Trim());
            EnglishSongList.Add("	336: TN loving-kindness Jesus came,	".Trim());
            EnglishSongList.Add("	337: GOD loved the world of sinners lost	".Trim());
            EnglishSongList.Add("	338:  REESCUE  the  perishing, care for the dying,	".Trim());
            EnglishSongList.Add("	339:  COME, O Thou Traveller unknown,	".Trim());
            EnglishSongList.Add("	340: COME, O Thou Traveller unknown,	".Trim());
            EnglishSongList.Add("	341: WHEN shall Thy love constrain,	".Trim());
            EnglishSongList.Add("	342: COME, let us to the Lord our God	".Trim());
            EnglishSongList.Add("	343:1 WHEREWITH, O God, draw near, ".Trim());

            EnglishSongList.Add("	344:  JESUS, the sinner's Friend, to Thee,	".Trim());
            EnglishSongList.Add("	345: DRAWN to the Cross which Thou hast blessed	".Trim());
            EnglishSongList.Add("	346: JESUS, full of truth and grace,	".Trim());
            EnglishSongList.Add("	347: COME, O Thou all-victorious Lord,	".Trim());
            EnglishSongList.Add("	348: SAVIOUR, Prince of Israel's race,	".Trim());
            EnglishSongList.Add("	349:  JESUS, If still the same Thou art,	".Trim());
            EnglishSongList.Add("	350: WITH broken heart and contrite sigh, ".Trim());

            EnglishSongList.Add("	351: HEAR Thy welcome voice	".Trim());
            EnglishSongList.Add("	352: OPPRESSED with sin and woe,	".Trim());
            EnglishSongList.Add("	353: JUST aa I am, without one plea	".Trim());
            EnglishSongList.Add("	354: No, not despairingly	".Trim());
            EnglishSongList.Add("	355: WEARY of earth and laden with	".Trim());
            EnglishSongList.Add("	356: GREAT God of wonders all Thy ways	".Trim());
            EnglishSongList.Add("	357: JESUS, in whom the weary find	".Trim());
            EnglishSongList.Add("	358:  DEPTH of mercy I can there be	".Trim());
            EnglishSongList.Add("	359:  OUT of the depths I cry to Thee,	".Trim());
            EnglishSongList.Add("	360: HAPPY the man that finds the grace,	".Trim());
            EnglishSongList.Add("	361: THERE shall my wondering soul begin?	".Trim());
            EnglishSongList.Add("	362: AUTHOR of faith, eternal Word,	".Trim());
            EnglishSongList.Add("	363: SPIRIT of faith, come down,	".Trim());
            EnglishSongList.Add("	364: AH! whither should I go,	".Trim());
            EnglishSongList.Add("	365: GOD of my salvation, hear,	".Trim());
            EnglishSongList.Add("	366: JESUS! Redeemer, Saviour, Lord,	".Trim());
            EnglishSongList.Add("	367: DAY after day I sought the Lord,	".Trim());
            EnglishSongList.Add("	368: ARISE, my soul, arise,	".Trim());
            EnglishSongList.Add("	369: THEE, Jesus, Thee, the sinner's Friend,	".Trim());
            EnglishSongList.Add("	370: JESU, Thy blood and righteousness	".Trim());
            EnglishSongList.Add("	371:  AND can it be that I should gain	".Trim());
            EnglishSongList.Add("	372: THE God of love,to earth He came,	".Trim());
            EnglishSongList.Add("	373: LORD, I was blind ! I could not see	".Trim());
            EnglishSongList.Add("	374: JESUS hath died and hath risen again, ".Trim());

            EnglishSongList.Add("	375: NOW I  have  found  the ground wherein	".Trim());
            EnglishSongList.Add("	376: 'THOU great mysterious God unknown,	".Trim());
            EnglishSongList.Add("	377: HOW can a sinner know	".Trim());
            EnglishSongList.Add("	378: ETERNAL Sun of Righteousness,	".Trim());
            EnglishSongList.Add("	379: THE people that In darkness lay,	".Trim());
            EnglishSongList.Add("	380: I WILL sing the wondrous story	".Trim());
            EnglishSongList.Add("	381: I AM not skilled to understand	".Trim());
            EnglishSongList.Add("	382: LET Him to whom we now belong	".Trim());
            EnglishSongList.Add("	383: BEING of beings, God of love,	".Trim());
            EnglishSongList.Add("	384:  MY soul, through my Redeemer�s care,	".Trim());
            EnglishSongList.Add("	385: JESUS, I fain would find ".Trim());

            EnglishSongList.Add("	386: THOU who camest from above	".Trim());
            EnglishSongList.Add("	387: MY God I  know, I  feel Thee mine,	".Trim());
            EnglishSongList.Add("	388: MY  Saviour how  shall I proclaim,	".Trim());
            EnglishSongList.Add("	389: GREAT God, Indulge my humble claim; ".Trim());
            EnglishSongList.Add("	390: GIVE me the faith which can remove	".Trim());
            EnglishSongList.Add("	391: THY life was given for me,	".Trim());
            EnglishSongList.Add("	392: I BIND unto myself to-day	".Trim());
            EnglishSongList.Add("	393:I.I GIVE my heart to Thee,	".Trim());
            EnglishSongList.Add("	394: JUST as I am. Thine own to be,	".Trim());
            EnglishSongList.Add("	395:  SAVIOUR, while my heart Is tender,	".Trim());
            EnglishSongList.Add("	396: LORD,In the fullness of my might,	".Trim());
            EnglishSongList.Add("	397: LORD of Life and King of Glory,	".Trim());
            EnglishSongList.Add("	398: WHEN Thy soldiers  take their swords,	".Trim());
            EnglishSongList.Add("	399:  WHAT shall I render to my God	".Trim());
            EnglishSongList.Add("	400: TAKE my life, and let It be	".Trim());
            EnglishSongList.Add("	401: GOD'S trumpet wakes the slumbering world :	".Trim());
            EnglishSongList.Add("	402: fAITH of our fathers, living still	".Trim());
            EnglishSongList.Add("	403: MY heart Is fixed, eternal God,Fixed on Thee :	".Trim());
            EnglishSongList.Add("	404: HOW blest Is Thee,	".Trim());
            EnglishSongList.Add("	405: GOD be In my head,	".Trim());
            EnglishSongList.Add("	406: MY God, I am Thine;	".Trim());
            EnglishSongList.Add("	407: HOW happy are they	".Trim());
            EnglishSongList.Add("	408: MY God, the  spring  of all my Joys,	".Trim());
            EnglishSongList.Add("	409: THE glory of the spring how sweet,	".Trim());
            EnglishSongList.Add("	410: CoME, ye that love the Lord,	".Trim());
            EnglishSongList.Add("	411: HEAD of Thy church triumphant,	".Trim());
            EnglishSongList.Add("	412: WORSHIP,and thanks,and blessing,	".Trim());
            EnglishSongList.Add("	413: WHEN all Thy mercies, O my God,	".Trim());
            EnglishSongList.Add("	414: WE thank Thee, Lord, for this air earth,	".Trim());
            EnglishSongList.Add("	415: SING praise to God who reigns above,	".Trim());
            EnglishSongList.Add("	416: LIFE and light and Joy are found	".Trim());
            EnglishSongList.Add("	417: COME, Thou Fount of every blessing,	".Trim());
            EnglishSongList.Add("	418: AWAKE,our souls Away,our fears	".Trim());
            EnglishSongList.Add("	419: HAPPY are they, they that love God,	".Trim());
            EnglishSongList.Add("	420: THROUGH all the changing scenes of life,	".Trim());
            EnglishSongList.Add("	421: I AM so glad that our Father In heaven	".Trim());
            EnglishSongList.Add("	422: BLESSED    assurance,JESUS IS mine :	".Trim());
            EnglishSongList.Add("	423: I'VE found a Friend;O such a Friend!	".Trim());
            EnglishSongList.Add("	424: BLESS the Lord,my soul	".Trim());
            EnglishSongList.Add("	425: MY God, my King,	".Trim());
            EnglishSongList.Add("	426: YE servants of God,	".Trim());
            EnglishSongList.Add("	427: THROUGH all the changing scenes of life,	".Trim());
            EnglishSongList.Add("	428: I'LL praise my Maker while I've breath;	".Trim());
            EnglishSongList.Add("	429:  GOD of my life, through all my days	".Trim());
            EnglishSongList.Add("	430: JESU, Thy boundless love to me	".Trim());
            EnglishSongList.Add("	431: LOVE divine, all loves excelling,	".Trim());
            EnglishSongList.Add("	432: HABK, my soul! It Is the Lord;	".Trim());
            EnglishSongList.Add("	433: THOU hidden love of God, whose height,	".Trim());
            EnglishSongList.Add("	434: LOVE divine, how sweet Thou art	".Trim());
            EnglishSongList.Add("	435: LOVE is the key of life and death,	".Trim());
            EnglishSongList.Add("	436: IT passeth knowledge, that dear love of Thine,	".Trim());
            EnglishSongList.Add("	437: MY Jesus, I love Thee, I know Thou art mine,	".Trim());
            EnglishSongList.Add("	438: JESU, my Lord, my God, my All,	".Trim());
            EnglishSongList.Add("	439: O SAVIOUR, I have nought to plead,	".Trim());
            EnglishSongList.Add("	440: FAR off we need not rove	".Trim());
            EnglishSongList.Add("	441: RICHES unsearchable	".Trim());
            EnglishSongList.Add("	442: HAPPY the heart where graces reign,	".Trim());
            EnglishSongList.Add("	443: LOVED with everlasting love,	".Trim());
            EnglishSongList.Add("	444: BELOVED, let us love :	".Trim());
            EnglishSongList.Add("	445: THEE will I love, my strength, my tower,	".Trim());
            EnglishSongList.Add("	446: MY God, I love Thee—not because	".Trim());
            EnglishSongList.Add("	447: O LOVE, who formedst me to wear	".Trim());
            EnglishSongList.Add("	448: LOVE that wilt not let me go,	".Trim());
            EnglishSongList.Add("	449: LORD,enlarge    our    scanty thought	".Trim());
            EnglishSongList.Add("	450: NOW let us see Thy beauty. Lord,	".Trim());
            EnglishSongList.Add("	451:I. LIFT my heart to Thee, Saviour divine;	".Trim());
            EnglishSongList.Add("	452: WHAT shall I do my God to LOve,	".Trim());
            EnglishSongList.Add("	453: MY Saviour, hear me,	".Trim());
            EnglishSongList.Add("	454: I WOULD commune  with Thee, my God;	".Trim());
            EnglishSongList.Add("	455:I.AS pants the hart for cooling streams,	".Trim());
            EnglishSongList.Add("	456: FOR ever here my rest shall be,	".Trim());
            EnglishSongList.Add("	457: THOU  Shepherd  of   Israel,and mine,	".Trim());
            EnglishSongList.Add("	458: LONG did I toil,and knew no earthly rest;	".Trim());
            EnglishSongList.Add("	459: TO the haven of Thy breast,	".Trim());
            EnglishSongList.Add("	460: TALK with us,Lord,Thyself reveal,	".Trim());
            EnglishSongList.Add("	461: O FOR a closer walk with God,	".Trim());
            EnglishSongList.Add("	462:  HUNGER and I thirst;	".Trim());
            EnglishSongList.Add("	463: O Jesus Christ,grow Thou in me,	".Trim());
            EnglishSongList.Add("	464: JESUS, the all-restoring Word,	".Trim());
            EnglishSongList.Add("	465: OPEN, Lord, my Inward ear,	".Trim());
            EnglishSongList.Add("	466: MY soul, there Is a country	".Trim());
            EnglishSongList.Add("	467:  MY spirit longs for Thee	".Trim());
            EnglishSongList.Add("	468: NEARER, my God, to Thee,	".Trim());
            EnglishSongList.Add("	469: THAT  mystic  Word  of Thine. O sovereign  Lord,	".Trim());
            EnglishSongList.Add("	470: STILL with Thee, O my God,	".Trim());
            EnglishSongList.Add("	471:  O GOD,my God,my all Thou art:	".Trim());
            EnglishSongList.Add("	472: COME In,O come! The  door stands  open  now;	".Trim());
            EnglishSongList.Add("	473: MY heart is resting, O my God,	".Trim());
            EnglishSongList.Add("	474: STILL,still with Thee, when	".Trim());
            EnglishSongList.Add("	475: NEED Thee every hour,	".Trim());
            EnglishSongList.Add("	476: FROM trials unexempted	".Trim());
            EnglishSongList.Add("	477: SON of God, if Thy free grace	".Trim());
            EnglishSongList.Add("	478: JESUS,my Saviour,Brother,Friend,	".Trim());
            EnglishSongList.Add("	479: FAINTING soul, be bold, be strong,	".Trim());
            EnglishSongList.Add("	480: AH! Lord, with trembling I confess,	".Trim());
            EnglishSongList.Add("	481: HARK,how the  watchmen cry!	".Trim());
            EnglishSongList.Add("	482: HARK,'tis the watchman's cry:	".Trim());
            EnglishSongList.Add("	483: SURROUNDED Dyanost of foes,	".Trim());
            EnglishSongList.Add("	484: SOLDIERS of Christ, arise,	".Trim());
            EnglishSongList.Add("	485: I'M not ashamed to own my Lord,	".Trim());
            EnglishSongList.Add("	486: ARM of the Lord, awake, awake !	".Trim());
            EnglishSongList.Add("	487: COME on, my partners in distress,	".Trim());
            EnglishSongList.Add("	488: OFT in danger, oft in woe,	".Trim());
            EnglishSongList.Add("	489: WORKMAN of God O lose not heart,	".Trim());
            EnglishSongList.Add("	490: FiGHT the good fight with all thy might;	".Trim());
            EnglishSongList.Add("	491: CHRISTIAN, seek not yet repose;	".Trim());
            EnglishSongList.Add("	492: THE good fight have fought',	".Trim());
            EnglishSongList.Add("	493: LOVE of love, and Light of light,	".Trim());
            EnglishSongList.Add("	494: A SAFE stronghold our God IS still,	".Trim());
            EnglishSongList.Add("	495: WHO puts his trust	".Trim());
            EnglishSongList.Add("	496: ENTERNAL beam of light divine,	".Trim());
            EnglishSongList.Add("	497: TO the hills I lift mine eyes,	".Trim());
            EnglishSongList.Add("	498: ROCK of Ages, cleft for me,	".Trim());
            EnglishSongList.Add("	499: O SAFE to the Rock that is higher than I,	".Trim());
            EnglishSongList.Add("	500: PEACE, doubting heart I my God's I am :	".Trim());
            EnglishSongList.Add("	501: PEACE, perfect peace, in this dark world of sin?	".Trim());
            EnglishSongList.Add("	502:  OMNIPOTENT Lord, my Saviour and King,	".Trim());
            EnglishSongList.Add("	503: GOD moves In a mysterious way	".Trim());
            EnglishSongList.Add("	504: LEAVE God to order all thy ways,	".Trim());
            EnglishSongList.Add("	505: THOU to whose all-searching sight	".Trim());
            EnglishSongList.Add("	506:  MY spirlt on Thy care,	".Trim());
            EnglishSongList.Add("	507:  COMMIT thou all thy griefs	".Trim());
            EnglishSongList.Add("	508:I.AS helpless as a child who clings	".Trim());
            EnglishSongList.Add("	509: THE Galilean fishers toll	".Trim());
            EnglishSongList.Add("	510: AWAY, my needless fears,	".Trim());
            EnglishSongList.Add("	511: BEGONE,unbelief; my  Saviour Is near,	".Trim());
            EnglishSongList.Add("	512: LORD, as to Thy dear Cross we flee,	".Trim());
            EnglishSongList.Add("	513: Who fathoms the eternal thought?	".Trim());
            EnglishSongList.Add("	514: HE that Is down needs fear no fall,	".Trim());
            EnglishSongList.Add("	515: THY way, not mine. O Lord,	".Trim());
            EnglishSongList.Add("	516:I.WHEN we walk with the Lord	".Trim());
            EnglishSongList.Add("	517: SIMPLY trusting every day.	".Trim());
            EnglishSongList.Add("	518: Jesu,princess treasure,	".Trim());
            EnglishSongList.Add("	519: THEE,  Jesus,full of truth and grace,	".Trim());
            EnglishSongList.Add("	520: I BEING my Bins to Thee,	".Trim());
            EnglishSongList.Add("	521: I AM trusting Thee, Lord Jesus,	".Trim());
            EnglishSongList.Add("	522: I COULD not do without Thee,	".Trim());
            EnglishSongList.Add("	523: I WILL not let Thee go,	".Trim());
            EnglishSongList.Add("	524: MY God, I thank Thee, who hast made	".Trim());
            EnglishSongList.Add("	525: THROUGH the love of  God  our Saviour,	".Trim());
            EnglishSongList.Add("	526: O JESUS, I have promised	".Trim());
            EnglishSongList.Add("	527: SOMETTMES a light surprises	".Trim());
            EnglishSongList.Add("	528: IN heavenly love abiding,	".Trim());
            EnglishSongList.Add("	529: O BLESSED life I the heart at rest	".Trim());
            EnglishSongList.Add("	530: OFT I In my heart have said :	".Trim());
            EnglishSongList.Add("	531: LIGHT of the world. Thy beams I bless,	".Trim());
            EnglishSongList.Add("	532: LET everlasting glories crown	".Trim());
            EnglishSongList.Add("	533: PRAYER is the soul's sincere desire,	".Trim());
            EnglishSongList.Add("	534: JESUS,Thou  sovereign Lord of all,	".Trim());
            EnglishSongList.Add("	535: FROM every stormy wind that blows,	".Trim());
            EnglishSongList.Add("	536: MY God Is anY Hour so sweet,	".Trim());
            EnglishSongList.Add("	537: TIS not to ask for gifts alone,	".Trim());
            EnglishSongList.Add("	538: WHAT a Friend we have in Jesus,	".Trim());
            EnglishSongList.Add("	539: LORD,teach us how to pray aright,	".Trim());
            EnglishSongList.Add("	540: COME, my soul, thy suit prepare,	".Trim());
            EnglishSongList.Add("	541: PRAY,without ceasing pray,	".Trim());
            EnglishSongList.Add("	542: JESUS,my strength,my hope,	".Trim());
            EnglishSongList.Add("	543: HEAR Thou  my prayer, O Lord,	".Trim());
            EnglishSongList.Add("	544: ETERNAL Light!Eternal Light	".Trim());
            EnglishSongList.Add("	545: O DISCLOSE  Thy lovely face	".Trim());
            EnglishSongList.Add("	546: COME,Saviour, Jesus, from above!	".Trim());
            EnglishSongList.Add("	547: THE thing my God doth hate	".Trim());
            EnglishSongList.Add("	548: ALL things are possible to him	".Trim());
            EnglishSongList.Add("	549: LORD, that I may learn of Thee,	".Trim());
            EnglishSongList.Add("	550: FOR a heart to praise my God,	".Trim());
            EnglishSongList.Add("	551:  O LORD, how happy should we be	".Trim());
            EnglishSongList.Add("	552: JESUS, all-atoning Lamb,	".Trim());
            EnglishSongList.Add("	553: COME, Holy Ghost, all-quickening fire!	".Trim());
            EnglishSongList.Add("	554:  O COME and dwell In me,	".Trim());
            EnglishSongList.Add("	555: WHEN, my Saviour, shall I be	".Trim());
            EnglishSongList.Add("	556: DEEPEN the wound Thy hands have made	".Trim());
            EnglishSongList.Add("	557: WHAT Is our calling's glorious hope	".Trim());
            EnglishSongList.Add("	558: SAVIOUR from sin, I wait to prove	".Trim());
            EnglishSongList.Add("	559: COME, O my God,the promise seal,	".Trim());
            EnglishSongList.Add("	560: JESUS hath died that I might live,	".Trim());
            EnglishSongList.Add("	561: FATHER of Jesus Christ, my Lord,	".Trim());
            EnglishSongList.Add("	562: GOD of all power,and truth,and grace,	".Trim());
            EnglishSongList.Add("	563: LORD, I believe a rest remains	".Trim());
            EnglishSongList.Add("	564: FATHER, I dare believe	".Trim());
            EnglishSongList.Add("	565: I KNOW that my Redeemer lives,	".Trim());
            EnglishSongList.Add("	566: GOD of all-redeeming grace,	".Trim());
            EnglishSongList.Add("	567: IN full and glad surrender	".Trim());
            EnglishSongList.Add("	568: SINCE the Son hath made me free,	".Trim());
            EnglishSongList.Add("	569: THINE for ever I God of love,	".Trim());
            EnglishSongList.Add("	570: HOLY, and true, and righteous Lord,	".Trim());
            EnglishSongList.Add("	571: BLESSED are the pure In heart,	".Trim());
            EnglishSongList.Add("	572: BEHOLD the servant of the Lord i wait	".Trim());
            EnglishSongList.Add("	573: O GOD, what offering shall I give	".Trim());
            EnglishSongList.Add("	574: FATHER, Son, and Holy Ghost,	".Trim());
            EnglishSongList.Add("	575: SERVANT of all, to toil for man	".Trim());
            EnglishSongList.Add("	576: BE it my only wisdom here	".Trim());
            EnglishSongList.Add("	577: O LOVING Lord, who art for ever seeking	".Trim());
            EnglishSongList.Add("	578: A CHARGE to keep I have,	".Trim());
            EnglishSongList.Add("	579: SAVIOUR, Thy dying love	".Trim());
            EnglishSongList.Add("	580: DISMISS  me not Thy service, Lord,	".Trim());
            EnglishSongList.Add("	581: YE servants of the Lord,	".Trim());
            EnglishSongList.Add("	582: BRIGHTLY  beams  our  Father's mercy	".Trim());
            EnglishSongList.Add("	583: HOW blessed, from the bonds of sin	".Trim());
            EnglishSongList.Add("	584: THOU,Jesu, Thou my breast inspire,	".Trim());
            EnglishSongList.Add("	585: RISE up, O men of God!	".Trim());
            EnglishSongList.Add("	586: SINCE the Son hath made me free,	".Trim());
            EnglishSongList.Add("	587: O LORD of every lovely thing,	".Trim());
            EnglishSongList.Add("	588: AWAKE, awake to love and work,	".Trim());
            EnglishSongList.Add("	589:  GO, labour on: spend, and be  spent,	".Trim());
            EnglishSongList.Add("	590: FORTH In Thy name, O Lord, I go,	".Trim());
            EnglishSongList.Add("	591: BELIEVE not those who say	".Trim());
            EnglishSongList.Add("	592: I HOPED that with the brave and strong	".Trim());
            EnglishSongList.Add("	593: EVER the harvest reaped or lost Falls the eve;	".Trim());
            EnglishSongList.Add("	594:  LORD,in the strength of grace,	".Trim());
            EnglishSongList.Add("	595: GOD of almighty love,	".Trim());
            EnglishSongList.Add("	596: MAKE me a captive, Lord,	".Trim());
            EnglishSongList.Add("	597:I.TEACH me, my God and King,	".Trim());
            EnglishSongList.Add("	598: HOLY Lamb, who Thee confess,	".Trim());
            EnglishSongList.Add("	599: SOW In the morn thy seed,	".Trim());
            EnglishSongList.Add("	600: O MASTER,let me walk with Thee	".Trim());
            EnglishSongList.Add("	601: THEY who tread the path of	".Trim());
            EnglishSongList.Add("	602: FATHER, I know that all my life	".Trim());
            EnglishSongList.Add("	603: JESUS, let all Thy lovers shine	".Trim());
            EnglishSongList.Add("	604: FILL Thou my life, O Lord my God,	".Trim());
            EnglishSongList.Add("	605: JESUS, the gift divine I know,	".Trim());
            EnglishSongList.Add("	606: COME, all whoe'er have set	".Trim());
            EnglishSongList.Add("	607:  O GOD of Bethel, by whose hand	".Trim());
            EnglishSongList.Add("	608: CAPTAIN of Israel's host,and Guide	".Trim());
            EnglishSongList.Add("	609: SAVIOUR, like a Shepherd  lead us;	".Trim());
            EnglishSongList.Add("	610:  LEADER of faithful souls, and Guide	".Trim());
            EnglishSongList.Add("	611: LEAD us, heavenly Father, lead us	".Trim());
            EnglishSongList.Add("	612: LEAD, kindly Light, amid the encircling gloom	".Trim());
            EnglishSongList.Add("	613: LEAD us, O Father,In the paths of peace;	".Trim());
            EnglishSongList.Add("	614: HEAVENLY Father, Thou hast brought us	".Trim());
            EnglishSongList.Add("	615: GUIDE me, O Thou great Jehovah,	".Trim());
            EnglishSongList.Add("	616: THROUGH the night of doubt and sorrow,	".Trim());
            EnglishSongList.Add("	617: RIGHTLY gleams our banner,	".Trim());
            EnglishSongList.Add("	618: HAPPY band of pilgrims,	".Trim());
            EnglishSongList.Add("	619: FORWARD f be our watchword,	".Trim());
            EnglishSongList.Add("	620: WHO would true valour see,	".Trim());
            EnglishSongList.Add("	621: JESUS the good Shepherd is;	".Trim());
            EnglishSongList.Add("	622:  SHOW me the way. O Lord,	".Trim());
            EnglishSongList.Add("	623: I DARED  not  hope  that Thou wouldst deign to come	".Trim());
            EnglishSongList.Add("	624: JESUS, still lead on,	".Trim());
            EnglishSongList.Add("	625:  TO the hills will lift mine eyes,	".Trim());
            EnglishSongList.Add("	626:  I WANT a principle within	".Trim());
            EnglishSongList.Add("	627:  HOW happy every child of grace,	".Trim());
            EnglishSongList.Add("	628: YE that do your Master's will,	".Trim());
            EnglishSongList.Add("	629:  ALL as God wills, who wisely heeds	".Trim());
            EnglishSongList.Add("	630:  GRANT us light, that we may know	".Trim());
            EnglishSongList.Add("	631:  TALK In the light:	".Trim());
            EnglishSongList.Add("	632:  TIE Thou my Vision,	".Trim());
            EnglishSongList.Add("	633: O King of mercy,	".Trim());
            EnglishSongList.Add("	634:  TIILL your anchor hold In the storms of life,	".Trim());
            EnglishSongList.Add("	635:  JESUS, my Truth, my Way,	".Trim());
            EnglishSongList.Add("	636:  LIGHT of the world,faint were our weary feet	".Trim());
            EnglishSongList.Add("	637: THE sands of time are sinking;	".Trim());
            EnglishSongList.Add("	638: TO God, the only Wise,	".Trim());
            EnglishSongList.Add("	639: CHRIST, who knows all His sheep,	".Trim());
            EnglishSongList.Add("	640: SUNSET and evening star,	".Trim());
            EnglishSongList.Add("	641: HILE ebbing nature grieves,	".Trim());
            EnglishSongList.Add("	642: WHEN on my day of life the night is falling,	".Trim());
            EnglishSongList.Add("	643: WHEN this passing world Is done,	".Trim());
            EnglishSongList.Add("	644: THOU Judge of quick and dead,	".Trim());
            EnglishSongList.Add("	645: THAT day of wrath, that dreadful day	".Trim());
            EnglishSongList.Add("	646: DAY of wrath I  O day of mourning!	".Trim());
            EnglishSongList.Add("	647: LORD, It belongs not to my care	".Trim());
            EnglishSongList.Add("	648: AWAY with our sorrow and fear	".Trim());
            EnglishSongList.Add("	649: THERE Is a land of pure delight,	".Trim());
            EnglishSongList.Add("	650: JERUSALEM, my happy home,	".Trim());
            EnglishSongList.Add("	651: HARK!hark,my soul Angelic songs are swelling	".Trim());
            EnglishSongList.Add("	652: BRIEF life is here our portion,	".Trim());
            EnglishSongList.Add("	653:  SWEET place : sweet place alone	".Trim());
            EnglishSongList.Add("	654: THE homeland! The homeland	".Trim());
            EnglishSongList.Add("	655: JERUSALEM, my happy home,	".Trim());
            EnglishSongList.Add("	656: AROUND the throne of God in heaven	".Trim());
            EnglishSongList.Add("	657: THOR those we love  within  the veil,	".Trim());
            EnglishSongList.Add("	658: fOR ever with the Lord Amen;so let it be:	".Trim());
            EnglishSongList.Add("	659: DAY of rest and gladness,	".Trim());
            EnglishSongList.Add("	660: THIS Is the day of light:	".Trim());
            EnglishSongList.Add("	661: COME, let us with our Lord arise,	".Trim());
            EnglishSongList.Add("	662: SWEET Is the sunlight after rain,	".Trim());
            EnglishSongList.Add("	663: LIGHT of light, enlighten me,	".Trim());
            EnglishSongList.Add("	664: HOW blest the hour Lord Jesus,	".Trim());
            EnglishSongList.Add("	665: SWEET is the work, my God, my King,	".Trim());
            EnglishSongList.Add("	666: HE rose today with,anthems sweet	".Trim());
            EnglishSongList.Add("	667: THE day  Thou  gavest,Lord,Is ended,	".Trim());
            EnglishSongList.Add("	668: ANGEL voices, ever singing	".Trim());
            EnglishSongList.Add("	669: DEAR Lord and Father of mankind,	".Trim());
            EnglishSongList.Add("	670: JESUS, Thou soul of all our Joys,	".Trim());
            EnglishSongList.Add("	671: SING  Alleluia forth In duteous O praise,	".Trim());
            EnglishSongList.Add("	672: SAVIOUR, blessdd Saviour,	".Trim());
            EnglishSongList.Add("	673: SUMMER suns are glowing	".Trim());
            EnglishSongList.Add("	674: LOVE Divine whose constant beam	".Trim());
            EnglishSongList.Add("	675: JESUS, where'er Thy people meet,	".Trim());
            EnglishSongList.Add("	676: GREAT is the Lord our God,	".Trim());
            EnglishSongList.Add("	677: WE love the place, O God,	".Trim());
            EnglishSongList.Add("	678: LORD of the worlds above,	".Trim());
            EnglishSongList.Add("	679: PLEASANT are Thy courts above,	".Trim());
            EnglishSongList.Add("	680: GLAD was my heart to hear	".Trim());
            EnglishSongList.Add("	681: GOD of mercy, God of grace,	".Trim());
            EnglishSongList.Add("	682: GOD of pity, God of grace,	".Trim());
            EnglishSongList.Add("	683: TO, God Is here ! Let us adore,	".Trim());
            EnglishSongList.Add("	684: JESUS, stand among us	".Trim());
            EnglishSongList.Add("	685: STAND up and bless the Lord,	".Trim());
            EnglishSongList.Add("	686: LIFT up your hearts! We lift them, Lord, to Thee;	".Trim());
            EnglishSongList.Add("	687: I BOW in silence at Thy feet;	".Trim());
            EnglishSongList.Add("	688:  GOD our Father, who dost make us one,	".Trim());
            EnglishSongList.Add("	689:  AT even, ere the sun was set,	".Trim());
            EnglishSongList.Add("	690: OUR day of praise is done,	".Trim());
            EnglishSongList.Add("	691: SAVIOUR,again to Thy dear name we raise	".Trim());
            EnglishSongList.Add("	692: O SAVIOUR, bless us ere we go;	".Trim());
            EnglishSongList.Add("	693: LORD, dismiss us with Thying,neace;	".Trim());
            EnglishSongList.Add("	694: LORD, Thou hast been our dwelling place	".Trim());
            EnglishSongList.Add("	695: PRAISE, Lord, for Thee in Zion waits;	".Trim());
            EnglishSongList.Add("	696: CHILDREN of the heavenly King,	".Trim());
            EnglishSongList.Add("	697: BLEST are the humble souls that see	".Trim());
            EnglishSongList.Add("	698:  GOD our Father, who dost make us one,	".Trim());
            EnglishSongList.Add("	699: GREAT is our redeeming Lord	".Trim());
            EnglishSongList.Add("	700: WHO in the Lord confide,	".Trim());
            EnglishSongList.Add("	701: THE Church's one foundation	".Trim());
            EnglishSongList.Add("	702: CHRIST is our corner-stone,	".Trim());
            EnglishSongList.Add("	703:  CiTY of God,how broad and far	".Trim());
            EnglishSongList.Add("	704: BY the holy hills surrounded,	".Trim());
            EnglishSongList.Add("	705: GOD is the refuge of His saints,	".Trim());
            EnglishSongList.Add("	706: GLORIOUS things of thee are spoken,	".Trim());
            EnglishSongList.Add("	707: THOU not made with hands,	".Trim());
            EnglishSongList.Add("	708: LIfE love Thy Kingdom. Lord,	".Trim());
            EnglishSongList.Add("	709: AND are we yet alive,	".Trim());
            EnglishSongList.Add("	710: BRETHREN  In  Christ,  and  well beloved,	".Trim());
            EnglishSongList.Add("	711: HOW pleasant, how divinely fair,	".Trim());
            EnglishSongList.Add("	712: BLEST be the dear uniting love,	".Trim());
            EnglishSongList.Add("	713: LET us Join tis God com-	".Trim());
            EnglishSongList.Add("	714: HE wants not friends that hath Thy love,	".Trim());
            EnglishSongList.Add("	715: fOR the might of Thine arm we	".Trim());
            EnglishSongList.Add("	716: THOU God of truth and love,	".Trim());
            EnglishSongList.Add("	717: HELP us to help each other, Lord,	".Trim());
            EnglishSongList.Add("	718: JESUS, we look to Thee,	".Trim());
            EnglishSongList.Add("	719: SEE,Jesu,Thy  disciples  see,	".Trim());
            EnglishSongList.Add("	720: CHRIST, from whom all blessings flow,	".Trim());
            EnglishSongList.Add("	721: JESUS, united by Thy grace	".Trim());
            EnglishSongList.Add("	722: LIFT up your hearts to things above,	".Trim());
            EnglishSongList.Add("	723: O GOD of our forefathers, hear,	".Trim());
            EnglishSongList.Add("	724: JESUS, Lord of life and glory,	".Trim());
            EnglishSongList.Add("	725: LORD, in this Thy mercy's day,	".Trim());
            EnglishSongList.Add("	726: SAVIOUR, when In dust to Thee	".Trim());
            EnglishSongList.Add("	727: JESUS, with  Thy Church  abide;	".Trim());
            EnglishSongList.Add("	728: O GOD of mercy, God of might,	".Trim());
            EnglishSongList.Add("	729: LORD of our life, and God of our	".Trim());
            EnglishSongList.Add("	730: FATHER of everlasting grace,	".Trim());
            EnglishSongList.Add("	731: O CHRIST,our God,who with	".Trim());
            EnglishSongList.Add("	732: SWEETLY the holy hymn	".Trim());
            EnglishSongList.Add("	733: JESUS, Sun of Righteousness,	".Trim());
            EnglishSongList.Add("	734: JESUS, meek and gentle,	".Trim());
            EnglishSongList.Add("	735: WHEN the weary, seeking rest,	".Trim());
            EnglishSongList.Add("	736:  SHEPHERD   divine, our wants relieve	".Trim());
            EnglishSongList.Add("	737: JESU,to Thee our hearts we lift	".Trim());
            EnglishSongList.Add("	738: REVIVE  Thy  work, O Lord,	".Trim());
            EnglishSongList.Add("	739:  HUB Father,hear our longing prayer,	".Trim());
            EnglishSongList.Add("	740: FATHER of all, to Thee	".Trim());
            EnglishSongList.Add("	741: WE have not known Thee as we ought,	".Trim());
            EnglishSongList.Add("	742: THY kingdom come—on bended knee	".Trim());
            EnglishSongList.Add("	743: NOT for our sins alone	".Trim());
            EnglishSongList.Add("	744: O HAPPY day that fixed my choice	".Trim());
            EnglishSongList.Add("	745: ALL praise to our redeeming Lord,	".Trim());
            EnglishSongList.Add("	746: I AM Thine, O Lord; I have heard Thy voice,	".Trim());
            EnglishSongList.Add("	747:  ALL thanks to the Lamb,	".Trim());
            EnglishSongList.Add("	748: COME, and let us sweetly join	".Trim());
            EnglishSongList.Add("	749: COME, let us use the grace divine,	".Trim());
            EnglishSongList.Add("	750: O GOD, how often hath Thine ear	".Trim());
            EnglishSongList.Add("	751: SEE Israel's gentle Shepherd stand	".Trim());
            EnglishSongList.Add("	752: BLESSED Jesus, here we stand,	".Trim());
            EnglishSongList.Add("	753: FRIEND of the home, as when in Galilee	".Trim());
            EnglishSongList.Add("	754: STAND, soldier of the Cross,	".Trim());
            EnglishSongList.Add("	755: LORD Jesus Christ, our Lord most dear,	".Trim());
            EnglishSongList.Add("	756: BREAD of the world,in mercy broken;	".Trim());
            EnglishSongList.Add("	757: BREAD the table of the Lord,	".Trim());
            EnglishSongList.Add("	758: I AM not worthy, holy Lord,	".Trim());
            EnglishSongList.Add("	759: AND now, O Father, mindful of the love	".Trim());
            EnglishSongList.Add("	760: SAVIOUR, and can It be	".Trim());
            EnglishSongList.Add("	761: JESUS, we thus obey	".Trim());
            EnglishSongList.Add("	762: IN memory of the Saviour's love	".Trim());
            EnglishSongList.Add("	763: ACCORDING to thy gracious word,	".Trim());
            EnglishSongList.Add("	764: AUTHOR of life divine,	".Trim());
            EnglishSongList.Add("	765: COME, Thou everlasting Spirit,	".Trim());
            EnglishSongList.Add("	766: THE known to us in breaking bread,	".Trim());
            EnglishSongList.Add("	767: COME,Holy Ghost,Thine influence shed,	".Trim());
            EnglishSongList.Add("	768: O BREAD to pilgrims given,	".Trim());
            EnglishSongList.Add("	769: BREAD of heaven, on Thee I feed,	".Trim());
            EnglishSongList.Add("	770: JESUS, to Thy table led,	".Trim());
            EnglishSongList.Add("	771: VICTIM divine,Thy grace we claim,	".Trim());
            EnglishSongList.Add("	772: THERE,O my Lord, I see Thee face to face;	".Trim());
            EnglishSongList.Add("	773:  MY Christ redeemed,in  Christ restored,	".Trim());
            EnglishSongList.Add("	774: O GOD of Love, to Thee we bow,	".Trim());
            EnglishSongList.Add("	775: THE voice that breathed o'er Eden,	".Trim());
            EnglishSongList.Add("	776: FATHER,all creating,	".Trim());
            EnglishSongList.Add("	777: O PERFECT Love,all human thought transcending,	".Trim());
            EnglishSongList.Add("	778: How  beauteous are their feet	".Trim());
            EnglishSongList.Add("	779: COME, Holy Ghost, our souls Inspire,	".Trim());
            EnglishSongList.Add("	780: MASTER, speak! Thy servant	".Trim());
            EnglishSongList.Add("	781: LORD, speak to me, that I may	".Trim());
            EnglishSongList.Add("	782: THINE Thou upon us, Lord, O True Light of men, today;	".Trim());
            EnglishSongList.Add("	783: SHALL I, for fear of feeble man,	".Trim());
            EnglishSongList.Add("	784: THAT shall  we offer our good	".Trim());
            EnglishSongList.Add("	785: JESUS, if we aright confess	".Trim());
            EnglishSongList.Add("	786: LORD, grant us, like the watching five,	".Trim());
            EnglishSongList.Add("	787: LORD of the harvest, hear	".Trim());
            EnglishSongList.Add("	788: DISPOSER Supreme, and Judge of the earth,	".Trim());
            EnglishSongList.Add("	789: FORGET them not,	".Trim());
            EnglishSongList.Add("	790: TOOK from Thy sphere of endless day,	".Trim());
            EnglishSongList.Add("	791: JESUS, Thy wandering sheep behold	".Trim());
            EnglishSongList.Add("	792: LORD, if at Thy command	".Trim());
            EnglishSongList.Add("	793: LORD of the living harvest	".Trim());
            EnglishSongList.Add("	794: ETERNAL Son, eternal Love,	".Trim());
            EnglishSongList.Add("	795: CHURCH of God, arise,	".Trim());
            EnglishSongList.Add("	796: LORD, Thy ransomed Church is waking	".Trim());
            EnglishSongList.Add("	797: ONCE again, dear Lord, we pray	".Trim());
            EnglishSongList.Add("	798: FAR round the world Thy children sing their song :	".Trim());
            EnglishSongList.Add("	799: THE fields are all white,	".Trim());
            EnglishSongList.Add("	800: SAVIOUR, quicken many nations,	".Trim());
            EnglishSongList.Add("	801:  FROM Greenland�s icy mountains,	".Trim());
            EnglishSongList.Add("	802: THE heavens declare Thy glory,Lord,	".Trim());
            EnglishSongList.Add("	803:  THOU whose almighty word	".Trim());
            EnglishSongList.Add("	804: SPREAD, O spread, thou mighty word,	".Trim());
            EnglishSongList.Add("	805: CHRIST for the world, we sing :	".Trim());
            EnglishSongList.Add("	806: LET the song go round the earth :	".Trim());
            EnglishSongList.Add("	807: AND let our bodies part,	".Trim());
            EnglishSongList.Add("	808: SPEED Thy servants,Saviour,speed them;	".Trim());
            EnglishSongList.Add("	809: IT CANNOT tell why He,whom angels worship,	".Trim());
            EnglishSongList.Add("	810: FATHER, let Thy kingdom come,	".Trim());
            EnglishSongList.Add("	811: THY kingdom come, O God,	".Trim());
            EnglishSongList.Add("	812: GOD Is working His purpose out,	".Trim());
            EnglishSongList.Add("	813: THE Lord will come,and not be slow;	".Trim());
            EnglishSongList.Add("	814: HEAD of  Thy  Church Spirit fills	".Trim());
            EnglishSongList.Add("	815: HILLS of the North, rejoice,	".Trim());
            EnglishSongList.Add("	816: THE Son of God goes forth to war,	".Trim());
            EnglishSongList.Add("	817: FILING out the banner 1 Let it float	".Trim());
            EnglishSongList.Add("	818: HAPPY the souls to Jesus Joined,	".Trim());
            EnglishSongList.Add("	819: FORTH rode the knights of old	".Trim());
            EnglishSongList.Add("	820: WHO is on the Lord's side?	".Trim());
            EnglishSongList.Add("	821: STAND up, stand up for Jesus	".Trim());
            EnglishSongList.Add("	822: ONWARD! Christian soldiers,	".Trim());
            EnglishSongList.Add("	823: OUR, Life Is Hid with Christ In God;	".Trim());
            EnglishSongList.Add("	824: COME,let us Join our friends above	".Trim());
            EnglishSongList.Add("	825: THE saints of God, their conflict past,	".Trim());
            EnglishSongList.Add("	826: O GOD,  to   whom  the  faithful dead	".Trim());
            EnglishSongList.Add("	827: THEIR names are names of kings	".Trim());
            EnglishSongList.Add("	828: TEN thousand times ten thousand,	".Trim());
            EnglishSongList.Add("	829: HARK!The song of jubilee,	".Trim());
            EnglishSongList.Add("	830: HARK!The sound of holy voices,	".Trim());
            EnglishSongList.Add("	831: GiVE me the wings of faith to rise	".Trim());
            EnglishSongList.Add("	832: FOR all the saints who from their	".Trim());
            EnglishSongList.Add("	833: WHAT are these arrayed In white,	".Trim());
            EnglishSongList.Add("	834: ABOVE the clear blue sky,	".Trim());
            EnglishSongList.Add("	835: WHEN, His salvation bringing,	".Trim());
            EnglishSongList.Add("	836: HOSANNA, loud hosanna,	".Trim());
            EnglishSongList.Add("	837:  CHILDREN of Jerusalem	".Trim());
            EnglishSongList.Add("	838: JESUS, high in glory,	".Trim());
            EnglishSongList.Add("	839: THERE'S a friend for little children	".Trim());
            EnglishSongList.Add("	840: GOD my Father, loving me,	".Trim());
            EnglishSongList.Add("	841: JESUS, Friend of little children,	".Trim());
            EnglishSongList.Add("	842: GENTLE Jesus, meek and mild,	".Trim());
            EnglishSongList.Add("	843: IN our dear Lord's garden,	".Trim());
            EnglishSongList.Add("	844: JESUS, tender Shepherd, hear me;	".Trim());
            EnglishSongList.Add("	845: GoD make my life a little light	".Trim());
            EnglishSongList.Add("	846: LORD,  when  we  have not  any light,	".Trim());
            EnglishSongList.Add("	847: O JESUS, we are well and strong,	".Trim());
            EnglishSongList.Add("	848: HUSHED was the evening hymn,	".Trim());
            EnglishSongList.Add("	849: FATHER, lead me day by day	".Trim());
            EnglishSongList.Add("	850: LOOKING upward every day,	".Trim());
            EnglishSongList.Add("	851: ALL things bright and beautiful,	".Trim());
            EnglishSongList.Add("	852:  ALL things which live below the sky,	".Trim());
            EnglishSongList.Add("	853: A LITTLE child may know	".Trim());
            EnglishSongList.Add("	854: IT is a thing most wonderful,	".Trim());
            EnglishSongList.Add("	855:  I LOVE to think, though I am young,	".Trim());
            EnglishSongList.Add("	856: I LOVE to hear the story	".Trim());
            EnglishSongList.Add("	857: GOD has given us a Book full of stories,	".Trim());
            EnglishSongList.Add("	858: TELL me the stories of Jesus	".Trim());
            EnglishSongList.Add("	859: ONCE In royal David's city	".Trim());
            EnglishSongList.Add("	860: AWAY In a manger, no crib for a bed,	".Trim());
            EnglishSongList.Add("	861:  COME little children, I pray ye come all,	".Trim());
            EnglishSongList.Add("	862: WISE men, seeking Jesus,	".Trim());
            EnglishSongList.Add("	863: THE shepherds had an angel,	".Trim());
            EnglishSongList.Add("	864: REMEMBER all the people	".Trim());
            EnglishSongList.Add("	865: I THINK, when I read that sweet story of old,	".Trim());
            EnglishSongList.Add("	866: WHEN mothers of Salem,	".Trim());
            EnglishSongList.Add("	867: DAY by day we magnify Thee,	".Trim());
            EnglishSongList.Add("	868: LORD and Saviour, true and kind,	".Trim());
            EnglishSongList.Add("	869: PRAISE to our God,who with love never swerving	".Trim());
            EnglishSongList.Add("	870: LORD, behold us with Thy blessing,	".Trim());
            EnglishSongList.Add("	871: IN our work and In our play,	".Trim());
            EnglishSongList.Add("	872: WE bless Thee. Lord, for all this common life	".Trim());
            EnglishSongList.Add("	873: THOU gracious God, whose mercy lends  ".Trim());

            EnglishSongList.Add("	874: AWAY with our fears!	".Trim());
            EnglishSongList.Add("	875: O HAPPY home where Thou art loved the dearest,	".Trim());
            EnglishSongList.Add("	876: OMNIPRESENT God, whose aid	".Trim());
            EnglishSongList.Add("	877: HOW do Thy mercies close  me round	".Trim());
            EnglishSongList.Add("	878: O GOD, our help In ages past,	".Trim());
            EnglishSongList.Add("	879: GOD save our .gracious Queen;	".Trim());
            EnglishSongList.Add("	880: GOD bless our native land!	".Trim());
            EnglishSongList.Add("	881:  LORD,while for all mankind we	".Trim());
            EnglishSongList.Add("	882: REJOICE,   O   land,   In   God   thy	".Trim());
            EnglishSongList.Add("	883:  JUDGE eternal, throned In splen-	".Trim());
            EnglishSongList.Add("	884:  BEFORE Thy throne, O God, we kneel;	".Trim());
            EnglishSongList.Add("	885:   REJOICE to-day with one accord,	".Trim());
            EnglishSongList.Add("	886:  To Thee our God we fly,	".Trim());
            EnglishSongList.Add("	887: GOD of our fathers, unto Thee    ".Trim());

            EnglishSongList.Add("	888: O KING of kings, O Lord of hosts,	".Trim());
            EnglishSongList.Add("	889: GOD of our fathers, known of old,	".Trim());
            EnglishSongList.Add("	890: LIFT up your heads, ye mighty gates,	".Trim());
            EnglishSongList.Add("	891: KING of the City Splendid,	".Trim());
            EnglishSongList.Add("	892: ETERNAL Ruler of the ceaseless round	".Trim());
            EnglishSongList.Add("	893: O YE who taste that love Is sweet,	".Trim());
            EnglishSongList.Add("	894: FATHER, who on man dost shower	".Trim());
            EnglishSongList.Add("	895: WHERE cross the crowded ways of life,	".Trim());
            EnglishSongList.Add("	896: NOW praise we great and famous men,	".Trim());
            EnglishSongList.Add("	897: WHAT  service  shall  we  render thee	".Trim());
            EnglishSongList.Add("	898: ONCE to every man and nation	".Trim());
            EnglishSongList.Add("	899: LAND of our Birth, we pledge to thee	".Trim());
            EnglishSongList.Add("	900: I VOW to thee, my country, all	".Trim());
            EnglishSongList.Add("	901: GOD the All-terrible I King, who ordainest	".Trim());
            EnglishSongList.Add("	902: ALL glory to God in the sky,	".Trim());
            EnglishSongList.Add("	903: O GOD of love, O King of peace,	".Trim());
            EnglishSongList.Add("	904: BEHOLD, the mountain of the Lord	".Trim());
            EnglishSongList.Add("	905:Ring out, wild bells, to the wild sky,	".Trim());
            EnglishSongList.Add("	906: LORD Christ, when first Thou cam'st to men,	".Trim());
            EnglishSongList.Add("	907: ALMIGHTY Father, who dost give	".Trim());
            EnglishSongList.Add("	908: LIFE of ages, richly poured,	".Trim());
            EnglishSongList.Add("	909: WHEN wilt Thou save the people?	".Trim());
            EnglishSongList.Add("	910: THESE things shall be : a loftier race	".Trim());
            EnglishSongList.Add("	911: O BROTHER man, fold to thy heart thy brother!	".Trim());
            EnglishSongList.Add("	912: TURN back, O man, forswear thy foolish ways;	".Trim());
            EnglishSongList.Add("	913: WITH the sweet word of peace	".Trim());
            EnglishSongList.Add("	914: GOD be with  you till we meet again,	".Trim());
            EnglishSongList.Add("	915: FATHER, who art alone	".Trim());
            EnglishSongList.Add("	916: HOLY Father, in Thy mercy,	".Trim());
            EnglishSongList.Add("	917: ETERNAL Father, strong to save,	".Trim());
            EnglishSongList.Add("	918: O LOVE divine, that stooped to share	".Trim());
            EnglishSongList.Add("	919: THINE  arm, O Lord,in days of old,	".Trim());
            EnglishSongList.Add("	920: THOU to whom the sick and dying	".Trim());
            EnglishSongList.Add("	921: FROM Thee all skill and science flow,	".Trim());
            EnglishSongList.Add("	922: O THOU  before  whose  presence	".Trim());


            dgEng.ItemsSource = EnglishSongList;
            if (rdEnlish.IsChecked == true) { dgEng.Visibility = Visibility.Visible; } else { dgEng.Visibility = Visibility.Hidden; }
        }
        private void fillTeluguSongslList()
        {
            TeluguSongList = new List<string>();
            TeluguSongList.Add("	1: అన్ని కాలంబుల నున్న యెహోవా ని నెన్నఁదరంబయో కన్న తండ్రి వన్నె కెక్కిన మోక్ష వాసాళి సన్నుతు లున్నతమై యుండ మున్నె నీకు ||నన్ని||	".Trim().ToString());
            TeluguSongList.Add("	2: గానముఁ జేయుఁడు సుకీర్తనను యెహోవాను గూరిచి క్రొత్తఁ గాను రక్తిగను ||గానము||	".Trim().ToString());
            TeluguSongList.Add("	3: యేసు నాయకుఁడ యెల్ల వేళలను నీ దాసుల నేలుమయ్యా మోసములన్నిటి మునగఁద్రోతునని బాసలు జేసిన ప్రభుఁడవు నీవెగా ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	4: దేవా దివ్యానంత ప్రభావ మాంపాహి ఘన యెహోవా స్థావర జంగమ సహిత నిఖిల జగ దావన పావన భావ నిరంతర ||దేవా||	".Trim().ToString());
            TeluguSongList.Add("	5: నీతిగల యెహోవా స్తుతి మీయాత్మతో నర్పించుఁడి మీయాత్మతో నర్పించుడి దాతయౌ మన క్రీస్తు నీతిని దాల్చుకొని సేవించుఁడి ||నీతి||	".Trim().ToString());
            TeluguSongList.Add("	6: భీకరుండౌ మా యెహోవా పీఠ మెదుటం గూడరే యేకమై సాష్టాంగపడి సర్వేశ్వరుని గొనియాడరే ||భీకరుండౌ||	".Trim().ToString());
            TeluguSongList.Add("	7: సన్నుతింతుమో ప్రభో సదమలమగు భక్తితో కన్నతండ్రి కావుమా కలుషము నెడబాపుమా||	".Trim().ToString());
            TeluguSongList.Add("	8: సర్వ శక్తుని స్తోత్రగానము సల్పరే జగ మెల్లను నిర్వహించును దాస భారము నిత్య మెద రాజిల్లను ||సర్వ||	".Trim().ToString());
            TeluguSongList.Add("	9: ప్రబలముగనే ప్రస్తుతించెద ప్రభుని కృపలన్ని ప్రతి దినము నిను ప్రచురపరచెద ప్రభుడ నావిభుడా ||ప్ర||	".Trim().ToString());
            TeluguSongList.Add("	10: ఎంత ప్రేమ యెంత ప్రేమ యెంత ప్రేమయా దేవుఁడెంత గొప్ప ప్రేమయై వెలుంగుచుండునే ||ఎంత||	".Trim().ToString());
            TeluguSongList.Add("	11: చూచుచున్నాము నీ వైపు మా ప్రియ జనక చూచుచున్నాము నీవైపు చూచుచు నీ ప్రేమ సొంపు సువార్తను జాఁచుచుఁ గరములు చక్కఁగా నీవైపు ||చూచు||	".Trim().ToString());
            TeluguSongList.Add("	12: దేవ సంస్తుతి చేయవే మనసా శ్రీ మంతుడగు యెహోవా సంస్తుతి చేయవే మనసా దేవ సంస్తుతి చేయుమా నా జీవమా యెహోవా దేవుని పావన నామము నుతించుమా నా యంతరంగములో వసించు నో సమస్తమా ||దేవ||	".Trim().ToString());
            TeluguSongList.Add("	13: నా కాలగతు లెవ్వి నా చేతులను లేవు నాదు దేవ యెపుడు నీకే వాని మీద నిత్యాధికారంబు నిల్చియుండు ||నా||	".Trim().ToString());
            TeluguSongList.Add("	14: నాకేమి కొదువ నాధుఁడుండ నిఁక శ్రీకరుండగు దేవుడే నా శ్రేష్ట పాలకుఁడు నా యేక రక్షకుఁడు గనుక ||నాకేమి||	".Trim().ToString());
            TeluguSongList.Add("	15: యెహోవా నా కాపరి లే మేమి గలుగదు తన మహా కృపతోఁ బ్రోచి నన్ను మనుపు నాతఁడే||	".Trim().ToString());
            TeluguSongList.Add("	16: యెహోవా నా మొఱ లాలించెను దన మహా దయను నను గణించెను అహర్నిశల దీనహీనుఁడగు నాదు హాయనెడు ధ్వని గ్రహించి మనిపెను ||యెహోవా||	".Trim().ToString());
            TeluguSongList.Add("	17: యెహోవా భజన చేయండి పాప నరులారా యీ రీతి మరచి పోకండి ||యెహోవా||	".Trim().ToString());
            TeluguSongList.Add("	18: కూడికొని యున్నాము సంఘ ప్రభో కూడికొని యున్నాము తోడ నుండెద ననుచు నమ్ముచు దొడ్డ దగు నీ పాద సన్నిధి ||కూడికొని||	".Trim().ToString());
            TeluguSongList.Add("	19: చూడ గోరెద దేవ మందిరావరణములను చూడ గోరెద చూడ నాకు నాశ గలదు సుందరావరణములవి చూడ నాదు ప్రాణమెంతో సొమ్మసిల్లుచున్నదహా ||చూడ||	".Trim().ToString());
            TeluguSongList.Add("	20: పరిశుద్ధ పరిశుద్ధ పరిశుద్ధ ప్రభువా వరదూత లైన నిన్ వర్ణింపఁ గలరా ||పరిశుద్ధ||	".Trim().ToString());
            TeluguSongList.Add("	21: త్రిత్వమై నిత్యత్వమున నేకత్వమగు దేవా నీ సత్యసామర్థ్యత్వముల నిజ తత్వము గణించి నిను నిత్యము స్తుతించెదను ||త్రిత్వమై||	".Trim().ToString());
            TeluguSongList.Add("	22: వ్యోమ సింహాసనస్థుఁడ యుర్వి పాదపీఠస్థుఁడ మామకీన దయా మయుఁడ మమ్ముఁగావుమో దేవుఁడ ||వ్యోమ||	".Trim().ToString());
            TeluguSongList.Add("	23: ఎటుల నీకు స్తుతు లొనర్తుము యెహోవ తనయ యెటుల నీకుఁ నుతు లొనర్తుము పటుతర పాపంబులనెడి పంకమందుఁజిక్కి మదిని దిటముఁ జెడిన మమ్ముఁ బ్రోచి దిక్కుఁజూపినట్టి యేసూ ||యెటుల||	".Trim().ToString());
            TeluguSongList.Add("	24: భూమండలము దాని సంపూర్ణత యును లోకమును భూమండల వాసులను బొల్పార యెహోవావే ||భూ||	".Trim().ToString());
            TeluguSongList.Add("	25: పరలోకమున నుండు దేవ నీ పదముల కొనరింతు సేవ దురితంబులకు నేను వెఱచి యున్నానని కరుణించి నీ సుతుని ధర కంపితివి గాదా అరయఁగా నీ ప్రేమ యింతనఁ దరము గాదో పరమ జనక మరణ పర్యంతంబు నిను నే మరువఁ జాలను వరకృపా నిధి ||పరలోక||	".Trim().ToString());
            TeluguSongList.Add("	26: రండి యుత్సహించి పాడుదము రక్షణ దుర్గము మన ప్రభువే||	".Trim().ToString());
            TeluguSongList.Add("	27: కలుగునుగాక దేవునికి మహిమ కలుగునుగాక కలుగు నున్నతమైన ఘన స్థలములందున నిలకు సమాధానం నరుల కాయన దయ ||కలుగును||	".Trim().ToString());
            TeluguSongList.Add("	28: మహిమ సర్వోన్నతమైన దైవమునకి మ్మహి సమాధానానుగ్రహము గల్గున్ర్పభో ||మహిమ||	".Trim().ToString());
            TeluguSongList.Add("	29: పాహిలోక ప్రభో పాహి లోక ప్రభో పాహి యని వేఁడు మాం పాహిలోక ప్రభో||	".Trim().ToString());
            TeluguSongList.Add("	30: మా యేసు క్రీస్తు నీవే మహిమగల రాజవు నీవు నీవే తండ్రికి నిత్యకుమారుడవు ఓ క్రీస్తూ||	".Trim().ToString());
            TeluguSongList.Add("	31: ఓ ప్రభుండా నిన్ నుతీంచుచున్నాము వినయముతోడ మా ప్రభుండ వంచు నిన్ను మానక మేమొప్పుకొందు ||మో||	".Trim().ToString());
            TeluguSongList.Add("	32: దహన బలి నీకు ననిష్టము మరియు దైవ బలులు విరిగిన యాత్మయే యెహోవ దేవ విరిగి నలిగిన యట్టి హృదయం బలక్ష్యంబు సేయవు ||దహన||	".Trim().ToString());
            TeluguSongList.Add("	33: యెహోవ గద్దె ముందట జనంబులార మ్రొక్కుఁడి యెహోవ దేవుఁడే సుమీ సృజింపఁ జంపఁ గర్తయే	".Trim().ToString());
            TeluguSongList.Add("	34: సర్వేశా! రమ్ము నీ సన్నిధి కాంతి నొసంగు మాకు సత్య సనాతన సర్వాధికారుఁడా సదా మమ్మేలుము సర్వోన్నతా!	".Trim().ToString());
            TeluguSongList.Add("	35: ఇన్నాళ్లు మాకు సాయమై యీ ముందుకును మా యున్నత గృహ మండవై యొప్పెడు దైవమా!	".Trim().ToString());
            TeluguSongList.Add("	36: సర్వాద్భుతంబులన్ సర్వత్రఁ జేయుకర్తన్ సర్వాత్మ లింతటన్ శ్లాఘింపఁ జేరరండి! మా రాకపోకలన్ మం వీడకుండను మా రక్షకుండిట్లే మమ్మాదరించును	".Trim().ToString());
            TeluguSongList.Add("	37: మాకర్త గట్టి దుర్గము నే నమ్ము ఆయుధంబు సంప్రాప్తమైన కష్టములన్నిటి నణంచు ఆ పాత శత్రువెంతో క్రూరుఁడు తదాయుధములుపాయ శక్తులు అతం డసమానుండు.	".Trim().ToString());
            TeluguSongList.Add("	38: కృపగల దేవుని సర్వదా నుతించుఁడి దివ్య కృపా ప్రేమలు ఎల్లకాల ముండును.	".Trim().ToString());
            TeluguSongList.Add("	39: నృపా! విమోచకా! ప్రభూ వేలాది నోళ్ల నీ కృపా జయప్రభావముల్ నుతింతు నెంతయున్.	".Trim().ToString());
            TeluguSongList.Add("	40: శుద్ధి, శుద్ధి, శుద్ధి! సర్వశక్త ప్రభు ప్రాతఃకాలస్తుతి నీకీ చెల్లింతుము శుద్ధి, శుద్ధి, శుద్ధి! కృపగల దేవా! ముగ్గురైయుండు దైవత్ర్యేకుఁడా!	".Trim().ToString());
            TeluguSongList.Add("	41: మేలుకొనరే మీ మనంబుల మేలిమిగ మీ మేరఁ దప్పక పాలు మాలక లేచి దేవుని పాదములు పూజింప గ్రక్కున ||మేలుకొనరే||	".Trim().ToString());
            TeluguSongList.Add("	42: తెల్లవారిన వేళఁ దెలి వొంది మన క్రీస్తు దివ్య నామముఁ బాడెరె యో ప్రియులార దివస రక్షణ వేఁడరే తల్లి రొమ్మున దాఁచు పిల్ల రీతిని మనలఁ జల్లదనముగ రాతి రెల్లఁ గాచిన విభునిఁ ||దెల్లవారిన వేళ||	".Trim().ToString());
            TeluguSongList.Add("	43: శ్రీ యేసు కర్తను సేవఁ జేయుటకు మేల్కొను శ్రీయేసు కర్తను శ్రేయముల నెఱింగి నీకు రేయిపవ లొసంగి యెడఁ బాయని యంతరంగి యపాయంబుఁ ద్రోయ సహాయంబుఁజేయ ||శ్రీ యేసు||	".Trim().ToString());
            TeluguSongList.Add("	44: సకల జగజ్జాల కర్తా భక్త సంఘ హృదయ తాప హర్తా యకలంక గుణమణి నికర పేటీ కృత ప్రకట లోకచయ పరమ దయాలయ ||సకల||	".Trim().ToString());
            TeluguSongList.Add("	45: వేఁడెద నాదగు వినతిని గైకొనవే జగదీశ ప్రభో నేఁడు ప్రతిక్షణ మెడబాయక నా తోడ నుండవె ప్రభో ||వేఁడెద||	".Trim().ToString());
            TeluguSongList.Add("	46: ప్రభువా నిన్నారాధింపను జేరితిమి యుదయ శుభకాంతి ప్రభవింపఁగా దేవా నేఁడు శుభకాంతి విరజిమ్మఁగా విభవముగను ప్రభాకరముగను విరియు నీ తేజంబెలర్పఁగ నభి దనంబులఁగూడి భక్తిని యాత్మతో సత్యంబుతోడను ||ప్రభువా||	".Trim().ToString());
            TeluguSongList.Add("	47: లేచి స్తుతింపఁ బూనుఁడి లోకేశ్వరుని లేచి స్తుతింపఁ బూనుఁడి లేచి స్తుతించెదము చూచుచు మనలను బ్రోచి ప్రేమతోఁ గరము జాచి కాపాడు విభుని ||లేచి||	".Trim().ToString());
            TeluguSongList.Add("	48: స్తోత్రము స్తోత్రము ఓ దేవా ఈ వేకువనే స్తోత్రము జేతుము మా దేవా రాత్రియందున మమ్ము రక్షించి గాపాడి ధాత్రి మరియొక దినమున్ దయతో నిచ్చెన దేవా||	".Trim().ToString());
            TeluguSongList.Add("	49: వినవే నా వినతి నివేదన దయ వెలయఁగ నో ప్రభువా నిను శర ణొందితి ననుఁ గుశలంబున నునుపవె యో ప్రభువా ||వినవే||	".Trim().ToString());
            TeluguSongList.Add("	50: దేవ నీకు స్తోత్రము ఈ రాత్రిలో నీ వెలుఁగు దీవెనకై కావుము నన్నిప్పుడు రాజుల రాజా ప్రోవు రెక్కల నీడలో ||దేవ||	".Trim().ToString());
            TeluguSongList.Add("	51: దినము గతియించెను దిననాధుఁడ పరాద్రి వెనుకడాఁగె నిఁ కమా మునిమాపు సంస్తవముఁ గొనుము సంప్రీతిమై ఘనుఁడ దేవా ||దినము||	".Trim().ToString());
            TeluguSongList.Add("	52: ఆకాశంబు భూమియు అంతట చీకటి యాయెను ప్రాకెడు చీకటి సమయమున ప్రార్థన చేతుము మా దేవా||	".Trim().ToString());
            TeluguSongList.Add("	53: ఈ సాయంకాలమున యేసు ప్రభో వేఁడెదము నీ సుదయారస మొల్క నిత్యంబు మముఁగావు ||మీ||	".Trim().ToString());
            TeluguSongList.Add("	54: నా యేసూ, ఆత్మ సూర్యుఁడా నీవున్న రాత్రి కమ్మదు నా యాత్మలో నీ విప్పుడు వసించి పాయకుండుమీ.	".Trim().ToString());
            TeluguSongList.Add("	55: ప్రొద్దు గ్రుంకుచున్నది సద్దణంగుచున్నది యాకసంబు దివ్వెలు లోకమున్ వెల్గింపఁగా స్తుతించుఁడి. || శుద్ధ, శుద్ధ, శుద్ద సర్వేశుఁడా యిద్దరాకాశంబులు సన్నుతించుచున్నవి సర్వోన్నతా ||	".Trim().ToString());
            TeluguSongList.Add("	56: రాత్రియయ్యెన న్నెడఁబాయకు ధాత్రిపైఁ జీఁకతులుఁ గ్రమ్మెను సహాయ మేమి లేనివారికి సహాయుఁడా, నన్ బాసిపోకుమీ.	".Trim().ToString());
            TeluguSongList.Add("	57: ఓ రక్షకా, నీ దివ్య నామము ఐక్యంబుతోను స్తుతియింతుము ఆరాధనాంత మెందు వేళయం దను గ్రహించు నీదు దీవెనన్.	".Trim().ToString());
            TeluguSongList.Add("	58: ఇది యెహోవా కలిగించిన దినము సుదివసంబునను జొప్పడు గడియలు కొదువలేని దయ గుల్కెడు వానివి ||యిది||	".Trim().ToString());
            TeluguSongList.Add("	59: సుక్షేమ శుభకాల విశ్రాంతి దినమా విచారమెల్ల తీర్చు దైవాదివారమా ఈనాడు మేము కూడి దేవాలయంబున మా త్ర్యేక దేవ స్తుతిఁగావింతు మెంతయు.	".Trim().ToString());
            TeluguSongList.Add("	60: గొప్ప దేవ నాకు తండ్రివి యాకాశమందు గొప్ప దేవ నాకుఁ దండ్రివి తప్పకుండ వత్తు నీదరికి యేసు నామమందు గొప్ప కరుణ చేత నన్నిప్పుడు తగఁ జేర్చుకొనుము ||గొప్ప||	".Trim().ToString());
            TeluguSongList.Add("	61: ఘనుఁడైన యెహోవా గద్దె ముందట మీరు వినతు లిప్పుడు చేయుడి యోజనులార వినయంబుగా నిర్మలానంద రసలహరి మన మనం బొప్పుచుండనో జనులార ||ఘనుఁడైన||	".Trim().ToString());
            TeluguSongList.Add("	62: గతకాలములయందు ఘనసహాయుడ దేవా హితనిరీక్షణ నీవే యెన్నేండ్లకైన అతిగా వీచినగాడ్పు లందు దుర్గంబీవై నిత్మాంత గృహమీవె నిత్యఁడౌ ప్రభువా ||గత||	".Trim().ToString());
            TeluguSongList.Add("	63: పరిమపురి కల్పభూజ నిరత భూనరుల పూజ యురుతరచిత మహిమతేజ వరస్తుతి సల్పెదము రాజ	".Trim().ToString());
            TeluguSongList.Add("	64: ఎంత ప్రేమించెనో దేవుఁడు మనపై నెంతదయఁజూపెనో వింతగల యీ దైవప్రేమను సాంతమున ధ్యానింపరే ||ఎంత||	".Trim().ToString());
            TeluguSongList.Add("	65: దేవుని గొప్ప ప్రేమను కలంబు తెల్పజాలదు అత్యున్నత నక్షత్రమున్ అధోగతిన్ అవరించున్ నశించు జాతిన్ రక్షింపన్ సుతుని బంపెను పాపంబు నుండి పాపికి విశ్రాంతి జూపెను ||దేవుని ప్రేమ సంపద అపారమైనది నిరంతరంబు నిల్చును ప్రేమ సంగీతము||	".Trim().ToString());
            TeluguSongList.Add("	66: దైవ ప్రేమ పృథ్విలోని యన్నిటిని మించును యేసు మాలో నివసించు యది మా విముక్తియే నీ కమూల్య ప్రేమ యుండు నీవు దాసుల మైన మమ్ముఁ గృపతో రక్షించుము.	".Trim().ToString());
            TeluguSongList.Add("	67: శాశ్వతుడా! విస్మయమొంది నేను నీ స్వంతహస్త సృష్టిజూడగా నీ స్వరం విందున్ ఉరుములయందు యేసు ప్రభూ నిన్నారాధింతును ||ఓ రక్షకా! నీ స్తుతి పాడెదన్ నూరంతలన్ మహాదేవా నా రక్షకా! నమస్కరింతునిన్ మారని యో మహాదేవా||	".Trim().ToString());
            TeluguSongList.Add("	68: ఘన భవ దుపకృతు లను మాటికి నే వినుతింతును దే నిజసుత యొనరఁగ నాపై ననుక్రోశముఁదగ నునుపవే క్రైస్తవ జన విహిత||ఘన||	".Trim().ToString());
            TeluguSongList.Add("	69: సర్వదేశములారా శ్రీ యేసే దేవుండు ఉర్వి నుత్సాహముతో గురుస్తోత్రము జేయను రండి||సర్వ||	".Trim().ToString());
            TeluguSongList.Add("	70: దేవ కుమారా దీనోపకారా నా వంక దయఁజూప నా యన్న రారా||దేవ||	".Trim().ToString());
            TeluguSongList.Add("	71: నీవు నా దేవుండవై యు న్నావు యేసు నాధ నీవిలఁ బ్రోవవే నన్నుఁ గావవే ||నీవు||	".Trim().ToString());
            TeluguSongList.Add("	72: మంగళముఁబాడరె క్రీస్తునకు జయ మంగళముఁబాడరె యో ప్రియులారా మంగళముఁ బాడరెర్ మంగళముఁ బాడి దు స్సంగతిని వీడి ప్రభు సంగులను గూడి మదిఁ బొంగుచుఁ జెలంగుచును ||మంగళము||	".Trim().ToString());
            TeluguSongList.Add("	73: మంగళమే యేసునకు మనుజావతారునకు శృంగార ప్రభువునకు క్షేమాధిపతికి ||మంగళమే||	".Trim().ToString());
            TeluguSongList.Add("	74: వందనమే యేసునకు వరుసుగుణోదారునకు సౌందర్య ప్రభువునకు సర్వేశ్వర నీకు ||వందనమే||	".Trim().ToString());
            TeluguSongList.Add("	75: మంగళంబని పాడరే క్రీస్తుకు జయ మంగళంబని పాడరే యేసుకు జయ మంగళంబని పాడరే మంగళంబని పాడి సజ్జ నాంగ పూజితుఁడై కృపాత రంగిలోక సమూహ పాపవి భంగుడని యుప్పొంగి జయజయ ||మంగళ||	".Trim().ToString());
            TeluguSongList.Add("	76: క్రీస్తుయేసుకు మంగళం మా కీర్తి రాజుకు మంగళం క్రీస్తుయేసే దైవమంచును కూడి పాడుదు మంగళం||	".Trim().ToString());
            TeluguSongList.Add("	77: విజయగీతముల్ పాడరే క్రీస్తునకు జయ విజయగీతముల్ పాడరే వృజిన మంతటి మీఁద విజయ మిచ్చెడు దేవ నిజకుమారుని నామమున్ హృదయములతో భజన జేయుచు నిత్యమున్ ||విజయ||	".Trim().ToString());
            TeluguSongList.Add("	78: యేసు భజనయే మనలను ఆ సుగతికిఁ దీయు జనులారా దాసజనులు జేయు పలు దోసములు మోయు ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	79: శ్రీ యేసునే భజించు నా మనసా శ్రీ యేసునే భజించు శ్రీ యేసు ప్రభునే భజించు నా మనసా శ్రీ యేసునే భజించు ||శ్రీ యేసు||	".Trim().ToString());
            TeluguSongList.Add("	80: యేసుని భజియింపవే మనసా నీ దోసములు చనఁ జేసి కృపతోఁ బ్రోచునే మనసా వాసి కెక్కిన క్రీస్తు మోక్షని వాసిగా కిఁక వేరేలేరని దోసిలొగ్గి నుతించితే నిను త్రోసివేయఁడు దోసకారని ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	81: భజనచేయుచు భక్తపాలక ప్రస్తుతింతు నీ నామమును వృజినములపై జయము నిచ్చిన విజయుఁడా నిను వేఁడుకొందు||	".Trim().ToString());
            TeluguSongList.Add("	82: యేసుభజనసేయవే దోసపుమనసా! వాసిగ నేనే, వరరక్షకుఁడు వేసారి వసుధ నెవ్వారినిఁ గానము ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	83: రారే మన యేసు స్వామిని జూతము కోర్కె లూర ప్రియు లారా పేర్మిని గూరిమి భక్తులఁ విందుట భూరిద యామృత సారము లోలికెడు చారు కటాక్ష వి శాలేక్షణుఁడఁట నారకులగు నర నారీజనులకు దారక మొసఁగను దానె పిలుచునఁట దారుణ పాప మ హారణ్యమునకుఁ గారుచిచ్చు గతి గంపడువాఁడట ఘోరదరిద్రతఁ గూల్చెడివాఁడట సారం బగు తన సభకు మకుటమఁ ట ||రారే||	".Trim().ToString());
            TeluguSongList.Add("	84: ఇదిగో నీతిభాస్కరుండు ఉదయమాయె నతని నీతి హృదయ కమలమునను నిలిచి మది తమోగుణంబులణపె సదమల జ్ఞానంబు నొసఁగె ||ఇదిగో||	".Trim().ToString());
            TeluguSongList.Add("	85: చేరికొల్వుఁడి క్రీస్తుని పాదములఁ జేరి కొల్వుఁడి చేరి కొల్వుఁడి స్థిరమతితో మీ నోరు నిండ మది కోరికఁ దీరఁ ||జేరి||	".Trim().ToString());
            TeluguSongList.Add("	86: ఏమి నేను సమర్పింతు యేసూ యెట్లు నిన్ను స్తుతియింతు ఏమి సమర్పింతు హీనుఁడ నగు నేను గామితార్థము లెల్ల గలుగఁజేయు నీకు ||నేమి||	".Trim().ToString());
            TeluguSongList.Add("	87: సర్వ లోక సం పూజ్యా నమోనమో సర్వ జ్ఞాన సంపూర్ణా నమోనమో సర్వ సత్య సారాంశా నమోనమో దేవా గావో ||	".Trim().ToString());
            TeluguSongList.Add("	88: నమో యేసునాధా నాధా నమో జీవనాధా సమాన విరహిత సనాతనాత్మా సమున్నతోజ్వల ప్రశాంత ధామా ||నమో||	".Trim().ToString());
            TeluguSongList.Add("	89: వందనమయ్యా యేసు నీకు వందనమయ్యా మా కోరిక లందియ్య వయ్యా వందనమయ్య నీ సుందర పాదార విందములకు భక్తి వినతులు గావింతు సందియంబులులేని పరమానందమున నీయందు డెందము పొందుపడఁ జేయవె యెహోవా నందనా పాపేంధనాగ్ని ||వందనమయ్యా||	".Trim().ToString());
            TeluguSongList.Add("	90: క్రీస్తునాయక నీ దయాళిని కీర్తనలుగా బాడుదున్ నేస్తుతులతోఁ దండ్రి దేవుని నిత్యమును గొండాడుదున్ ||క్రీస్తు||	".Trim().ToString());
            TeluguSongList.Add("	91: నా రక్షకా యేసునాధ ఇమ్మానుయేలు ఘోర పాపుల పాప భార విమోచక ||నా రక్షకా||	".Trim().ToString());
            TeluguSongList.Add("	92: యేసు పదాంబుజ శరణం నర దోష మహాంబుధి హరణం యేసే మార్గము యేసే సత్యము యేసే జీవము యేసుకు శరణం||	".Trim().ToString());
            TeluguSongList.Add("	93: దేవాత్మ జయో దీనదయాళూ పావనాత్మ మము బ్రోచితహో నీవే గదా మా నిజరక్షణకై జీవమీయ ధర జేరితహో||	".Trim().ToString());
            TeluguSongList.Add("	94: సమానులెవరు ప్రభో నీ సమానులెవరు ప్రభో సమస్త మానవ శ్రమాను భవమున్ సహించి వహించి ప్రేమించగల నీ ||సమాను||	".Trim().ToString());
            TeluguSongList.Add("	95: యేసు క్రీస్తుఁడు నిత్య దేవుఁడు ఎఱిగి నమ్ముఁడి మనుజులారా మోస మొందక మోక్షపతికిఁక దాసులై బ్రతుకండి రండి ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	96: దేవుని నీతి ప్రతాపం భువి యేసుని సిల్వ ప్రభావం దేవుల దేవుని అపురూపం భువి యేసుని నామ స్వరూపం దేవ యెహోవ సువాక్యం -సౌభాగ్యం దైవ జనుల హృదయానందం. ||యేసుక్రీస్తు దైవ సుతుండు యేసుక్రీస్తు మనుజసుతుండు యేసుక్రీస్తు దేవుండు యేసే ప్రభువు -స్తుతిపాత్రుడు||	".Trim().ToString());
            TeluguSongList.Add("	97: శ్రీ రక్షకుని నామము కీర్తించి కొల్వుఁడీ కిరీట ముంచి చాటుఁడి -శ్రీ రాజా, రాజా, రాజా, రాజాధిరాజా!	".Trim().ToString());
            TeluguSongList.Add("	98: సుందర రక్షకా! సృష్టియొక్క నాధా దేవమానవ పుత్రుఁడా నిన్నుఁ బ్రేమింతున్ సదా సేవింతున్ మదాత్మతోఁ గిరీటమా.	".Trim().ToString());
            TeluguSongList.Add("	99: స్తుతి స్తుతి సదయుఁడైన యేసు నూటి న్నీకుసృష్టి చెల్లించును నీతిమంతా నిఖిల దూతలు చేరి నీకే కీర్తి భక్తిఁజెల్లింతురు. చేతనుంచి పిల్లల నెల్లను యేసు మితిలేని ప్రేమను గాచును. ||స్తుతి స్తుతి సదయుఁడైన యేసు ఖ్యాతితో నీకెన్నఁడొనర్తుము||	".Trim().ToString());
            TeluguSongList.Add("	100: పాపల్ హోసన్నా పాటల్ పాడిన రీతిగన్ నృపాలస్తుతి కీర్తుల్ నీకుఁ జెల్లింతుము దావీదు పుత్రకుండా యిశ్రాయేల్ పాలకా దేవుని పేర వచ్చు ధీరుండా ధన్యాత్మ.	".Trim().ToString());
            TeluguSongList.Add("	101: నా యాత్మ నీలో మేల్కొని దయాళుని కీర్తింపుము ప్రియంబుతో నీరక్షకున్ ప్రపూర్ణ ప్రేమబాడుము.	".Trim().ToString());
            TeluguSongList.Add("	102: మమున్ సృజించిన దేవుండు ప్రాణము నొసంగి యెప్పుడు కాపాడు మమ్మును సంతోష స్వర మెత్తుచు స్తుతించుచుండుఁడాయనన్.	".Trim().ToString());
            TeluguSongList.Add("	103: నమస్కరింప రండి దావీదు పుత్రుని శ్రీ యేసు రక్షకుండు ఏతెంచె భూమికి న్యాయంబు లోకమందు స్థాపించి నిత్యము అన్యాయ మంతఁ దాను పోఁగొట్టవచ్చెను.	".Trim().ToString());
            TeluguSongList.Add("	104: వినరే యో నరులారా వీనుల కింపు మీర మనల అక్షింప క్రీస్తు మనుజావతారుఁ డయ్యొ వినరే అనుదినమును దే వుని తనయుని పద వనజంబులు మన మున నిడికొనుచును ||వినరే||	".Trim().ToString());
            TeluguSongList.Add("	105: రారె గొల్లవారలారా నేటి రాత్రి బేత్లెహేము నూర జేరి మోక్షదూత కోరి దెల్పెను క్రీస్తు వారి జాడకన్ను లారా జూతము వేగ ||రారె||	".Trim().ToString());
            TeluguSongList.Add("	106: వచ్చిగాబ్రియేలు పల్కెను మరియ మచ్చకంటిడెంద ముల్కెను హెచ్చైన శుభముల నెనలేని కృప దేవుఁ డిచ్చి యింతులలోని న్నెచ్చు జేయునటంచు ||వచ్చి||	".Trim().ToString());
            TeluguSongList.Add("	107: ఉదయించినాఁడు క్రీస్తుఁడు నేఁడు ఉదయించినాఁడు విదితయౌ మరియ నందనుఁడై యిమ్మానుయేల్ సదయుఁడై చెడియున్న పృథివికి నొదవ సమ్మద మల పిశాచికి మద మణంగను సాధు జనముల హృదయముల ముద మెదుగునట్లుగ ||నుదయించి||	".Trim().ToString());
            TeluguSongList.Add("	108: కొనియాడఁ దరమె నిన్ను కోమల హృదయ కొనియాడఁ దరమె నిన్ను తనరారు దినకరుఁ బెనుతారలను మించు ఘనతేజమున నొప్పు కాంతిమంతుఁడ వీవు ||కొనియాడ||	".Trim().ToString());
            TeluguSongList.Add("	109: చింత లేదిఁక యేసు పుట్టెను వింతగను బేత్లెహేమందునఁ చెంత జేరను రండి సర్వజనాంగమా సంతస మొందుమా ||చింత||	".Trim().ToString());
            TeluguSongList.Add("	110: పుట్టె యేసుఁడు నేఁడు మనకు పుణ్యమార్గము జూపను పట్టి యయ్యెఁ బరమ గురుఁడు ప్రాయశ్చిత్తుఁడు యేసుడు ||పుట్టె||	".Trim().ToString());
            TeluguSongList.Add("	111: ఱేఁడు మెస్సీయ జన్మించెను శ్రీదా వీదు పురమున నుద్భువించెను వేడుకతోడను బాడుఁడి పాటలు రూఢిగ సాతాను కాడిని దొలఁగింప ||ఱేఁడు||	".Trim().ToString());
            TeluguSongList.Add("	112: రక్షకుండుదయించ్నాఁడఁట మనకొరకుఁబరమ రక్షకుం డుదయించి నాఁడఁట రక్షకుం డుదయించినాఁడు రారె గొల్లబోయలార తక్షణమునఁ బోయి మన ని రీక్షణ ఫల మొందుదము ||రక్షకుండు||	".Trim().ToString());
            TeluguSongList.Add("	113: సంతోషించుఁడి యందరు నాతో సంతోషించుఁడి యొక వింతయగు కీర్తనఁ బాడ వచ్చితిని సంతోషించుఁడి నాతో ||సంతో||	".Trim().ToString());
            TeluguSongList.Add("	114: జ్ఞాను లారాధించిరి యేసు ప్రభునిఁ బూని పాపులఁ బ్రోవ మెనిఁ దాల్చిన తరి ||జ్ఞాను||	".Trim().ToString());
            TeluguSongList.Add("	115: గీతములు పాడుఁడీ యేసునికి సం గీతములు పాడుఁడీ పాతకుల మగు మనల దారుణ పాతకము తన విమలరక్త స్నాతులనుగాఁ జేసి పాపను భాతకులలో నవతరించెను ||గీతములు||	".Trim().ToString());
            TeluguSongList.Add("	116: రారె చూతుము రాజసుతుడీ రేయి జనన మాయెను రాజులకు రా రాజు మెస్సియ రాజితంబగు తేజమదిగో ||రారె||	".Trim().ToString());
            TeluguSongList.Add("	117: యేసునాధుని యోధులందరు వాసిగ నిటరండు వేగమె వాసిగ నిటరండు భాసురముగ ప్రభు జన్మము బాడుచు నాసతోడ రండు వేగమె యాసతోడ రండు ||జే జయం||	".Trim().ToString());
            TeluguSongList.Add("	118: మేము వెళ్లిచూచినాము స్వామి యేసుక్రీస్తును ప్రేమ మ్రొక్కి వచ్చినాము మా మనంబులలరగ ||మేము||	".Trim().ToString());
            TeluguSongList.Add("	119: లోకమంతట వెలుగు ప్రకాశించెను యేసు జన్మించినపుడు ఆకాశమునందు గొప్ప నక్షత్రంబు బుట్టెనపుడు లోకజ్ఞానులు గొల్లలు వెళ్లి లోక రక్షకుడేసుకు మ్రొక్కిరి ||లో||	".Trim().ToString());
            TeluguSongList.Add("	120: చూడరే మాఱేఁడు పుట్టి నాఁడు బెత్లెహేములో నేఁడీ భూమి వాసులకు నిండు రక్షణబ్బెను ||చూడరే||	".Trim().ToString());
            TeluguSongList.Add("	121: శ్రీ యేసుండు జన్మించె రేయిలో నేఁడు పాయక బెత్లెహేమ యూరిలో ||శ్రీ యేసుండు||	".Trim().ToString());
            TeluguSongList.Add("	122: లాలిలాలి లాలి లాలమ్మ లాలీ లాలియని పాడరే బాలయేసునకు ||లాలి||	".Trim().ToString());
            TeluguSongList.Add("	123: ఇశ్రాయేలీయుల దేవుండే యెంతో స్తుతి నొందును గాక యాశ్రితువౌ తన జనులకు దర్శన మాత్మ విమోచన కలిగించె ||నిశ్రా||	".Trim().ToString());
            TeluguSongList.Add("	124: నాదు ప్రాణము ప్రభుని మిగుల ఘ నంబు చేయుచున్నది నాదు నాత్మ దేవునం దా నం మొందెను నిరతము ||నాదు||	".Trim().ToString());
            TeluguSongList.Add("	125: నీ సమాధానము దాసుని కిప్పుడు నాధా దేవా యిచ్చి నీ మాటచొప్పున పోనిచ్చుచున్నావు నాధా దేవా ||నీ సమాధానము||	".Trim().ToString());
            TeluguSongList.Add("	126: ఓ సద్భక్తులారా ! లోకరక్షకుండు బెత్లెహేమందు నేఁడు జన్మించెన్ రాజాధిరాజు ప్రభువైన యేసు నమస్కరింప రండి నమస్కరింప రండి. నమస్కరింప రండి యుత్సాహముతో.	".Trim().ToString());
            TeluguSongList.Add("	127: దూత పాట పాడుఁడీ రక్షకున్ స్తుతించుఁడీ ఆ ప్రభుండు పుట్టెను బెత్లెహేము నందునన్ భూజనంబు కెల్లను సౌఖ్యసంభ్ర మాయెను ఆకసంబునందున మ్రోగు పాట చాటుఁడీ దూత పాట పపాడుఁడీ రక్షకున్ స్తుతించుఁడీ.	".Trim().ToString());
            TeluguSongList.Add("	128: శుద్ధరాత్రి! సద్ధణంగ నందఱు నిద్రపోవ శుద్ధ దంపతుల్ మేల్కొనఁగాఁ బరిశుద్ధుఁడౌ బాలకుఁడా! దివ్య నిద్ర పొమ్మా దివ్య నిద్ర పొమ్మా.	".Trim().ToString());
            TeluguSongList.Add("	129: శ్రీ రక్షకుండు పుట్టఁగా నాకాశ సైన్యము ఇహంబున కేతెంచుచు ఈ పాట పాడెను. 'పరంబునందు స్వామికి మహా ప్రభావము ఇహంబునందు శాంతిని వ్యాపింపనీయుఁడు'.	".Trim().ToString());
            TeluguSongList.Add("	130: క్రైస్తవులారా! లెండి యీనాడు క్రీస్తు పుట్టెనంచు పాడుఁడి; ప్రసన్నుఁడైన తండ్రి ప్రేమను ఆసక్తిపరులై కీర్తించుఁడి క్రీస్తేను మానవాళితోడను నశింపవచ్చెనంచు పాడుఁడి.	".Trim().ToString());
            TeluguSongList.Add("	131: హాయి, లోకమా! ప్రభువచ్చెన్ అంగీకరించుమీ పాపాత్ములెల్ల రేసునున్ కీర్తించి పాడుఁడీ.	".Trim().ToString());
            TeluguSongList.Add("	132: రండి పాడ దూతలారా నిండు సంతోషంబుతో యేసుని జన్మంబు గూర్చి ఈ భూలోకమంతట రండి నేడు పుట్టినట్టి రాజు నారాధించుడి.	".Trim().ToString());
            TeluguSongList.Add("	133: ఓ బెత్లెహేము గ్రామమా! సద్దేమిలేకయు నీవొంద గాఢనిద్రపై వెలుంగు తారలు కానేమి, నిత్యజ్యోతి జ్వలించు నీతమిన్ పెక్కేండ్ల భీతివాంఛలీ రాత్రి తీరె నీలోన్.	".Trim().ToString());
            TeluguSongList.Add("	134: వేకువచుక్కల శ్రేష్ఠమౌ దానా! మా యిరుల్ బాపి నీ సాయమిమ్ము ప్రాగ్దిశ తార దిజ్మండల భూషా మా బాలరక్షకు జూపింపుమా.	".Trim().ToString());
            TeluguSongList.Add("	135: రండి సువార్త సునాదముతో రంజిలు సిలువ నినాదముతో తంబుర సితార నాదముతో ప్రభుయేసు దయానిధి సన్నిధికి	".Trim().ToString());
            TeluguSongList.Add("	136: యేసు నామామృతము కన్నను వేరే మాకిఁక లేదుగా దోసముల నెడబాపి పరమని వాస పదవికిఁ జేర్చుఁగా ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	137: యేసు నామ మెంతో మధురం యేసు నామ మెంతో మధురం దోసములు మోసములు నాధ మొనరించు ప్రభు ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	138: యేసు నామమే పావనము మాకు యేసు గద నిత్య జీవనము దాస జన హృద్వికాసమైయెల్ల దోసములకు వి నాశకరమైన ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	139: యేసే, భగవన్నామం భజింపను యేసే, భగవన్నామం భజింప నిరంతర ||మేసే||	".Trim().ToString());
            TeluguSongList.Add("	140: యేసు నీ నామామృతము మా కెంతో రుచి యయ్యా దేవ మా దోసములను హరించి మోక్షని వాసులుగఁ జేయుటకు భాసుర ప్రకాశమైన ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	141: వరనామమే శరణము శరణము క్రీస్తు వరనామమే శరణము శరణం ||వర||	".Trim().ToString());
            TeluguSongList.Add("	142: శ్రీ యేసు దివ్య నామస్మరణ చేయవే మనసా పాయక స్మరియించి పరము పొందువే మనసా ||శ్రీ||	".Trim().ToString());
            TeluguSongList.Add("	143: రారాజగు యేసునినామం రమ్యంబగు దేవుని నామం ఈశుండగు యేసునినామం ఈధర నిదె పావననామం యేసునినామం దేవునినామం రమ్యంబగు దేవుని నామం ||రారాజు||	".Trim().ToString());
            TeluguSongList.Add("	144: క్రీస్తే సర్వాధికారి క్రీస్తే మోక్షాధికారి క్రీస్తే మహోపకారి క్రీస్తే ఆ సిల్వధారి ||	".Trim().ToString());
            TeluguSongList.Add("	145: నీవేయని నమ్మక యేసునాకు నీవేయని నమ్మిక నీవే మార్గంబు నీవే సత్యంబు నీవే జీవంబు నీవే సర్వంబు ||నీవే||	".Trim().ToString());
            TeluguSongList.Add("	146: క్రీస్తేసు శక్తినామమెల్లరు కీర్తించి కొల్వుడిలన్ యెపుడు కీర్తి కిరీటము ధరియింప జేయుడి క్రీస్తే రారాజనుడి ||క్రీస్తే||	".Trim().ToString());
            TeluguSongList.Add("	147: నాయేసు నామ శబ్దము ఎంతో యింపైనది భయాదులెల్ల దీరిచి విశ్రాంతి నిచ్చును.	".Trim().ToString());
            TeluguSongList.Add("	148: యేసు నామము స్మరించు బాధ నీకుఁ గల్గఁగా నద్ది క్షేమ సౌఖ్య మిచ్చు దాని స్మరియించుము. ||శ్రేష్ఠమౌ నామము ఆదరించు నిలను శ్రేష్ఠమౌ నామము మోక్షసౌఖ్య మద్దియే||	".Trim().ToString());
            TeluguSongList.Add("	149: దేవుని ప్రేమ యిదిగో జనులార భావంబునం దెలియరే కేవలము నమ్ముకొనినఁ పరలోక జీవంబు మన కబ్బును ||దేవుని||	".Trim().ToString());
            TeluguSongList.Add("	150: వినరె మనుజులార క్రీస్తుఁ డిలనుఁ జేయు ఘనములైన పనులలోనఁ జిత్రమొక్క పని వచించెద ||వినరె||	".Trim().ToString());
            TeluguSongList.Add("	151: అందమైన క్రీస్తు కథ మీ రాలింపరయ్య ||అందమైన||	".Trim().ToString());
            TeluguSongList.Add("	152: కనరె యేసుని ప్రత్యక్షంబు అన్య జనులకు గల్గిన, విధమెట్లొ తరచి ||కనరె||	".Trim().ToString());
            TeluguSongList.Add("	153: నేర్చుకొనరే యేసువాడుక లనుదినము మీ బ్రతుకునందున నేర్చుకొనిన మీరలాయన జనముగ నొప్పుదురు ఇలలో ||నేర్చుకొనరే||	".Trim().ToString());
            TeluguSongList.Add("	154: ఎవరు భాగ్యవంతు లౌదు రవని లోపల మోక్ష వివరమైన క్రీస్తు బోధ చెవులొగ్గి వినువారికన్న ||నెవరు||	".Trim().ToString());
            TeluguSongList.Add("	155: వినరయ్య నరులారా విశ్వాసమున క్రీస్తు విమల బోధ పాప మనుజుల కెల్ల పా వన జీవనము సేయు వసుధ మీఁద ||వినరయ్య||	".Trim().ToString());
            TeluguSongList.Add("	156: ఏలాటివాఁడో కాని యీ యేసుని నేమని వివరింతుము గాలివాన యేసుని గద్దింపునకుఁ చాల భయపడి నిలిచెను ||ఏలాటి||	".Trim().ToString());
            TeluguSongList.Add("	157: యేసు వస్త్రపు చెంగును మాత్రమే యాసించి ముట్టినట్టి దోసకారుల రోగముల్ వెంటనే తొలఁగి పోయెను నిజముగ ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	158: సీయోనుకన్యా సంభ్రమపడుచు వేయుము కేకల్ పాయక నీ రాజు భారవాహక మెక్కి బాలస్తోత్రములతో బైలుదేరి వచ్చె ||సీయోను||	".Trim().ToString());
            TeluguSongList.Add("	159: ద్రాక్షావల్లిని నేను ద్రాక్షాతీగెలు మీరు అక్షయు డేసిటు బలికె అతిముదమునను వినరండి ||ద్రాక్షా||	".Trim().ToString());
            TeluguSongList.Add("	160: ఇదిగో శుభద రక్షణము దేవుఁడు పంపె నిదిగో శుభద రక్షణము సదమలంబగు పూర్వ సత్యవాక్యమునందు మృదువుగా దీర్ఘ ద ర్శుల చేతఁ బలుకఁబడె ||ఇదిగో||	".Trim().ToString());
            TeluguSongList.Add("	161: వింతగల మా యేసు ప్రేమను సంతసమున స్తుతింతును పంతముగఁ దన ప్రాణమును పా పులకు నియ్యను వచ్చి సిలువను జచ్చి నను రక్షించె నహహా ||వింత||	".Trim().ToString());
            TeluguSongList.Add("	162: అన్నా మన యేసు ప్రభుని కన్న రక్షకుఁడు లేఁడు ఎన్న రాని మన యఘము లన్ని సడలించి ప్రోచు ||నన్న||	".Trim().ToString());
            TeluguSongList.Add("	163: ఇడుగో గొఱ్ఱెలకాపరి సోదరులారా యిడుగో గొఱ్ఱెలకాపరి కడగానరాని కారడవిలో నలసట పడెడు గొఱ్ఱెలను పేరిడిబిల్చి రక్షించు ||నిడుగో||	".Trim().ToString());
            TeluguSongList.Add("	164: ఈయనా యేసు రక్షకుడు తన దాయమని రక్షింపఁ దలఁచెనా నన్ను నీయనా యేసు రక్షకుఁడు ఆయాసమగు నొక్క మోపు నే మోయలేకుండ నా మూపుపై నుండ శ్రేయఃకరపు సిలువఁజూపి నాకు హాయి నిచ్చెను భార మంత వెడలించి ||యీయనా||	".Trim().ToString());
            TeluguSongList.Add("	165: ఈలాటిదా యేసు ప్రేమ నన్ను తూలనాడక తనదు జాలి జూపినదా ||ఈలాటిదా||	".Trim().ToString());
            TeluguSongList.Add("	166: యేసురాజు నీదు ప్రేమ నెంచ తరముగాదయా దోషియైన నన్ను బ్రోవ నీసుప్రాణమిడితివా ||యేసురాజా||	".Trim().ToString());
            TeluguSongList.Add("	167: ఓ వింత! నా రక్షకుఁడా నాకై నీ విలువ రక్తము కార్చితివా జీవాధిపతి మృతిఁ జెందె నహహా పురుగు వంటి నాకై నీ జీవ మర్పించి నావా ||ఓ వింత||	".Trim().ToString());
            TeluguSongList.Add("	168: పరమ రక్షక యేసు ప్రభువా నే నీ పాలఁ పడితి పాలన సేయవే ధరజనంబులుసేయు బహువిధ దురితములు క్షమియించి సద్గతి తెరవు జూపి తరింపఁజేసెడి దొరవటంచును మరుగుజోచ్చితి ||పరమరక్షక||	".Trim().ToString());
            TeluguSongList.Add("	169: పాపి కాశ్రయుఁడవు నీవే యేసు నీవే	".Trim().ToString());
            TeluguSongList.Add("	170: యేసుక్రీస్తు ప్రభువా మేము నీ మోక్షముఁ బొందుటకు దోసపు లోకము లోనికి వచ్చితి దోషులఁ బ్రోచుటకు ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	171: యేసూ నన్ను ప్రేమించినావు పాపినైన నన్ను ప్రేమించినావు||	".Trim().ToString());
            TeluguSongList.Add("	172: యేసుక్రీస్తు దొరికె నేని యేమికొదువింకేమి భయము దోసకారి జనుల కెంతోఁ గ్రాసమవునా యేసు పేరు ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	173: యేసుని ప్రేమను నేమారకను నెప్పుడు దలఁచవే యో మనసా వాసిగ నాతని వరనామంబును వదలక పొగడవె యో మనసా||	".Trim().ToString());
            TeluguSongList.Add("	174: యేసువంటి ప్రియ బంధుఁడు నాకిఁక నిహ పరములలో లేఁడన్న భాసురముగ నిజ భక్తుల కది యను భవ గోచర మెపు డగు నన్న ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	175: ఏమి లేదు సుమీ జగములో యేసుని ప్రేమ సారము కన్నను పామరం బేటికి వృధా కను దామరలు మూయగనె చీకటి యౌ మనంబున నెల్ల సత్యము గామి గని సర్వంబు విడువుఁ ||డేమి||	".Trim().ToString());
            TeluguSongList.Add("	176: శ్రేష్ఠుఁడెల్లవారిలోను మా యేసువే తల్లికంటె ప్రియుడౌను మా యేసువే లోకస్నే హమస్థిరంబు నేఁడు ప్రేమరేపు కక్ష స్థిరుడైన మిత్రుడౌను మా యేసువే.	".Trim().ToString());
            TeluguSongList.Add("	177: యేసు శిష్యులకు నెరుక జేసిన భవిష్యోక్తులు వినరే కైసరయన గర ప్రాంతములను ఘనుఁడు చేరి తన గతి మతిఁ దలఁచుచు ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	178: ఆ యంధకారంపు రేయిలో క్రీస్తు పడు నాయాసములు దలఁచరే సాయంతనము శిష్య నమితితో భోజనముఁ జయఁగూర్చున్న ప్రభువు భక్తుల కనియె ||నా యంధ||	".Trim().ToString());
            TeluguSongList.Add("	179: నా యన్న రాఁగదే ఓ యేసు తండ్రి నా యన్న రాఁగదే నా ప్రాణ ధనమా నా పట్టుకొమ్మా నా ముద్దు మూట నా ముక్తిబాట నా యన్న రాఁగదే నా యన్న సిలువలో నీ వాయాసపడిన నాఁటి నీ యంఘ్రియుగమునిపుడు నా యాసఁదీరఁజూతు ||నా యన్న||	".Trim().ToString());
            TeluguSongList.Add("	180: మనస యేసు మరణ బాధ లెనసి పాడవే తన నెనరుఁ జూడవే యా ఘనునిఁ గూడవే నిను మనుప జచ్చుటరసియే మరక వేఁడవే ||మనస||	".Trim().ToString());
            TeluguSongList.Add("	181: రాజులకు రాజైన యీ మన విభుని పూజసేయుటకు రండి యీ జయశాలి కన్న మన కింక రాజెవ్వరును లేరని ||రాజులకు||	".Trim().ToString());
            TeluguSongList.Add("	182: ఎంతో దుఃఖముఁ బొందితివా నాకొర కెంతో దుఃఖము పొంది తివా యెంతో దుఃఖము నీకు ఎంతో చింతయు నీకు ఎంతో దిగులయ్యా నాకు ఆ పొంతి పిలాతు యూ దులు నీకుఁ బెట్టిన శ్రమలను దలపోయఁ గా ||నెంతో||	".Trim().ToString());
            TeluguSongList.Add("	183: సిలువను మోసితివా నా కొఱకై కలువరి మెట్టపైకి సిలువ నా యాత్మలోఁ బలుమాఱు దలఁపఁగాఁ దాలిమి లేదాయెను హా యీ జాలికి మారుగా నేనేమి సేయుదు ప్రేమను మరువఁజాల ||సిలువ||	".Trim().ToString());
            TeluguSongList.Add("	184: ఏమాశ్చర్యము ప్రియులారా క్రీస్తు మరణము ప్రేమజూడరెమనసార ఆ మహాత్ముఁడు మరణ మగు రీతిఁ గనుకొన్న సామాన్యమగు నొక్క జనుని చందము గాదు ఈ మహిని గల పాప జీవుల పై మహాకృపఁ జూపి నిత్య క్షేమ మొసఁగెడు కొరకు బలు శ్రమ చే మృతుండైనాఁడు స్వేచ్ఛను ||ఏమాశ్చర్యము||	".Trim().ToString());
            TeluguSongList.Add("	185: అపు డర్చకాదు లుప్పొంగిరి ప్రభుని విపరీతముగఁ జంపసాగిరి కృపమాలినట్టి పా పపు జిత్తమున నిష్ఠు రపు సిల్వమానిపైఁ బ్రభుని వేయుట కొప్పి ||రపు డర్చ||	".Trim().ToString());
            TeluguSongList.Add("	186: ఏ పాప మెఱుఁగని యోపావన మూర్తి పాప విమోచకుండ నా పాలి దైవమా నా పాపముల కొఱ కీ పాట్లు నొందినావా ||యే పాప||	".Trim().ToString());
            TeluguSongList.Add("	187: పాపులయెడ క్రీ స్తుని ప్రియ మెట్టిదో పరికింపరె క ల్వరిగిరిపై నాపదలను దన కీగతిఁ బెట్టెడు కాపురుషుల దెసఁ గనుగొను కృపతో ||బాపుల||	".Trim().ToString());
            TeluguSongList.Add("	188: చూడరే క్రీస్తుని జూడరే నా సఖులార చూడరే క్రీస్తుని జూడరే చూడరే నాముక్తి పదవికి ఱేఁడు యేదశఁ గూడినాఁడో ||చూడరే||	".Trim().ToString());
            TeluguSongList.Add("	189: వందనం నీకే వందనం పరిశుద్ధ శిరమా వందనం నీకే వందనం వందనం బొనరింతు నీ దౌ నందమగు ఘన నామమునకె ||వందనం||	".Trim().ToString());
            TeluguSongList.Add("	190: ఆహా యెంతటి శ్రమలఁ బొందితి వయ్యో దాహ మాయెను నీకు సిల్వపై ద్రోహు లందరు గూడి రయ్యయ్యో నీదు దేహంబు బాధించి రయ్యయ్యో ||యాహా||	".Trim().ToString());
            TeluguSongList.Add("	191: ఎంతో వింత యెంతో చింత యేసునాధు మరణ మంత పంతము తోఁ జేసి రంత సొంత ప్రజలు స్వామి నంత ||ఎంతో||	".Trim().ToString());
            TeluguSongList.Add("	192: ఐదు గాయము లొందినావా నాకొర! కైదు గాయము లొంది నావా ఐదు గాయముల నా యాత్మఁ దలంప నా కారాట మెచ్చినదే నీ మైదీగె నావంటి మర్త్యుల పాల్జేసి మరణ మొందితివి గదే ||ఐదు||	".Trim().ToString());
            TeluguSongList.Add("	193: చూడరే సిలువను వ్రే లాడు యేసయ్యను పాడు లోకంబునకై గోడు జెందెఁ గదా ||చూడరే||	".Trim().ToString());
            TeluguSongList.Add("	194: యేసునాధుని సిలువపైని వేసి శ్రమఁబొదించినది నా దోసమే దుస్సహ వాసమే ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	195: ఎన్నఁడు గాంచెదమో యేసుని నెన్నఁడు గాంచెదమో యెన్నఁడు జూతుము కన్నె కుమారుని సన్నుతి జేయుచును ||నెన్నఁడు||	".Trim().ToString());
            TeluguSongList.Add("	196: ఆహా మహాత్మ హా శరణ్యా హా విమోచకా ద్రోహ రహిత చంపె నిను నా దోషమేగదా ||యాహా||	".Trim().ToString());
            TeluguSongList.Add("	197: అయ్యో నాదగు ఘోరపాపము గదా భారమై నీపై నొరిగె నెయ్యము వీడి మెస్సీయ్య నిన్ సిలువ కొయ్యపైని గొరత కప్పగించిన ||దయ్యో||	".Trim().ToString());
            TeluguSongList.Add("	198: సిలువే నా శరణాయెను రా నీ సిలువే నా శర ణాయెను రా సిలువ యందే ముక్తి బలముఁ జూచితి రా ||నీ సిలువే||	".Trim().ToString());
            TeluguSongList.Add("	199: సిరులెల్ల వృధ కాఁగఁ పరికించి నాకున్న గురువముఁ దిరస్కరింతున్ వెర మహిమ రారాజు మరణాద్భుతపు సిలువ నరయుచున్నట్టి వేళన్ ముఖ్యము లైన ||సిరు లెల్ల||	".Trim().ToString());
            TeluguSongList.Add("	200: చేడియలు గుంపుగూడిరి క్రీస్తు జాడఁ గని తాల్మి నీడిరి ఆడికలనోర్చి నేఁడు మన పాఁలి వాఁడుసిలువ ను న్నాడు గదె యంచు ||చేడియలు||	".Trim().ToString());
            TeluguSongList.Add("	201: కలవరి మెట్టపై కలవర మెట్టిదొ సిలువెటులోర్చితివో పలుశ్రమ లొందినీ ప్రాణము బెట్టితి ||కల||	".Trim().ToString());
            TeluguSongList.Add("	202: కల్వరి గిరిజేరు మనసా సిల్వ సరస ||కల్వరి||	".Trim().ToString());
            TeluguSongList.Add("	203: ఎందుఁబోయెదవో హా ప్రభురాయ ఎందుఁబోయెదవో ఎందుఁ బోయెదవయ్య యీ దుర్మానవశ్రేణి బొందఁదగిన భరంబుఁ బూని రక్షక నీవు ||ఎందు||	".Trim().ToString());
            TeluguSongList.Add("	204: సిలువలో వ్రేలాడు ప్రభువే విలువ కందఁగ రాని యీవుల నెలమి మనకై కొనియెఁగల్వరి నిపుడు సాష్టాంగము లొనర్చుచు ||సిలువ||	".Trim().ToString());
            TeluguSongList.Add("	205: ఏమి నేరంబులేక యా మరణస్తంభము నేల మోయ నాయెను నా యేసు ఎంత ఘోరము లాయెను ఈ మానవులు యెరుషలేము బైటకు దీయ నేమి నేరము దోచెను ||ఏమి||	".Trim().ToString());
            TeluguSongList.Add("	206: కరుణసాగర వీవేకావా మరణమొంద సిల్వ మెట్టకు మోసినావా కరుణ సాగర వీవెకావ మరియు కల్వరి మెట్టమీఁదను కడకు మేకులుఁ గొట్టబడి నీ మరణరక్తము చేత నరులకు పరమరక్షణఁ దెల్పినావా ||కరుణ||	".Trim().ToString());
            TeluguSongList.Add("	207: ఎంత గొప్ప బొబ్బ పుట్టెను దానితో రక్షణ మంతయును సమాప్త మాయెను ఎంత గొప్ప బొబ్బ పుట్టెను యేసునకుఁ కల్వరి మెట్టను సంతసముతో సిల్వఁ గొట్టఁగ నూర్యుఁ డంధకారమాయెను ||ఎంత||	".Trim().ToString());
            TeluguSongList.Add("	208: హర్షమే యెంతో హర్షమే క్రీస్తును కార్యము హర్షమే యెంతో హర్షమే హర్షమే తద్భక్తవరులకు నద్భుతంబగు యేసు క్రియలా కర్షమై హృదయంబు నందలి కలుషముం ధ్వంసింపఁజేయు ||హర్షమే||	".Trim().ToString());
            TeluguSongList.Add("	209: నా కొఱకుఁ చనిపోయి నాఁడ ఆద యాకరుండిరు వంక దొంగలతోడ ||నా కొఱకు||	".Trim().ToString());
            TeluguSongList.Add("	210: గాయంబుతో నిండారు ఓ శుద్ధ శిరస్సా! హా! ముండ్ల కిరీటంబు భరించు శిరస్సా! నీకిప్పుడు డపకీర్తి హాస్యంబు గల్గెఁగా కర్తా! ఘనంబు కీర్తి ఎన్నడు గల్గుఁగా	".Trim().ToString());
            TeluguSongList.Add("	211: సిల్వయొద్దఁ జేరుదున్ బీద హీనయంధుఁడన్ లోకమున్ త్యజింతును పూర్ణముక్తి నొందుదున్ ||కర్త, నిన్నె నమ్ముదున్ కల్వరీ గొఱ్ఱెపిల్లా మోకరించి వేఁడెదన్ నన్నుఁ గావుమో ప్రభో!||	".Trim().ToString());
            TeluguSongList.Add("	212: మహాత్ముఁడైన నా ప్రభు విచిత్ర సిల్వఁ జూడ నా యాస్తిన్ నష్టంబుగా నెంచి గర్వం బణంగఁ ద్రొక్కుదున్.	".Trim().ToString());
            TeluguSongList.Add("	213: మరణమున్ జయించి లేచెను మన ప్రభువు నేఁడు మహిమ దేహ మొనరఁ దాల్చెను ధర సమాధి బంధములను ధన్యముగను త్రెంచి లేచి కొఱత లన్ని తీర్చి జీవ వరము లియ్య వసుధపైని ||మరణమున్||	".Trim().ToString());
            TeluguSongList.Add("	214: రండు విశ్వాసులారా రండు విజయము సూచించు చుండెడు సంతోషంబును గల్గి మెండుగ నెత్తుడి రాగముల్ నిండౌ హర్షము మనకు నియమించె దేవుఁడు విజయం, విజయం, విజయం, విజయం ||విజయం||	".Trim().ToString());
            TeluguSongList.Add("	215: సుదతులార మీ రిచ్చోట నెవ్వరి వెదుకుచునున్నారు మృదువుగాను జీ వించు వాని పెద్ద నిదుర బోయినటు లెదలందు భావించి ||సుదతులార||	".Trim().ToString());
            TeluguSongList.Add("	216: విజయంబు విజయంబు విజయంబు మా యేసు నిజమె మృత్యువు గెల్చి నేఁడు వేంచేసె యజమానుఁ డెల్ల ప్ర యాసము లెడఁబాప స్వజనుల రక్షింప సమసె సిలువమీఁద ||విజయంబు||	".Trim().ToString());
            TeluguSongList.Add("	217: హలెలూయ యని పాడుఁడీ సమాధిపై వెలుఁ గేమొ పరికించుఁడీ కలఁడు యేసు సజీవుఁడయి, లే ఖనముల లవి నెరవేరెను కలిమి మోదము గులగ, దివి నుతి సలువ మహిమను వచ్చును ||హలెలూయ||	".Trim().ToString());
            TeluguSongList.Add("	218: యేసు లేచెను ఆదివారమున యేసు లేచెను వేకువజామున యేసు లేచెను||	".Trim().ToString());
            TeluguSongList.Add("	219: క్రీస్తు లేచెను హల్లెలూయ క్రీస్తు నన్నులేపును ఇద్దియె సునాద సత్యము ఇలను చాటుడి నిత్యము||	".Trim().ToString());
            TeluguSongList.Add("	220: యేసు పునరుత్థానమాయెను చావునొంది క్రీ స్తేను పునరుత్థానమాయెను యేసు పునరుత్థానమాయె దాసులెల్ల నుతింప వింతగ భాసురంబుగ భక్తలంబర వాసులుగఁ దాఁజేయు నిప్పుడు ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	221: యేసు సమాధిలో పరుండియుండి వాసిగ మూఁడవ నాఁడు లేచెన్. || లేచెన్ సమాధినుండి మృత్యువుపై విజయమొంది శత్రువు నోడించి జయశాలియై నాత్యముం జీవించ మధ్యవర్తియై; లేచెను! లేచెను హల్లెలూయ! లేచెను ||	".Trim().ToString());
            TeluguSongList.Add("	222: క్రీస్తు నేడు లేచెను ఆ ఆ ఆ హల్లెలూయ మర్త్యదూత సంఘమా ఆ ఆ ఆ హల్లెలూయ భూమి నాకసంబులో ఆ ఆ ఆ హల్లెలూయ బాడుమిందు చేతను ఆ ఆ ఆ హల్లెలూయ.	".Trim().ToString());
            TeluguSongList.Add("	223: క్రీస్తు ప్రభుని ప్రత్యక్షతలను వివ రించెద వినరే ప్రియులార వాస్తవముగ మరణించి బ్రతికెనని వసుధలోఁ బ్రకటింపరె యూరూరఁ ||గ్రీస్తు||	".Trim().ToString());
            TeluguSongList.Add("	224: ఇదిగో నా శిష్యులారా యెఱుక లుంచుఁడి మోక్ష సదనమున కేను బోదు సంతోషించు(డి ||ఇదిగో||	".Trim().ToString());
            TeluguSongList.Add("	225: పరమ ప్రభో యేసురక్షకా ధననరుల బ్రోచి పరమ కారోహణంబైతివా మరియయందు జననమొంది వరము లిడుచు దిరిగిధరను మరణమొంది తిరిగిలేచి పరము కేగితివా ప్రభో ||పరమ||	".Trim().ToString());
            TeluguSongList.Add("	226: మేఘంబుపై నెక్కి మేలుగ ప్రభు క్రీస్తు యాకసంబున కేగెను ప్రాకటముగను ఆత్మనంది ప్రజ్ఞ మీరగ సాక్ష్యమిచ్చి యేక దీక్షను యేసు రాకకు నెదురు జూడుడటంచు ప్రభువు ||మేఘంబు||	".Trim().ToString());
            TeluguSongList.Add("	227: కోలాహలముగఁ గూరిమితోఁ గూడి కోలాటమాడను రా రా మా పాలిటి యేసుని పేరఁ మాపాలిటి యేసుని పేర మ మ్మేలెడి దేవుని పేరఁ ||గోలాహలముగ||	".Trim().ToString());
            TeluguSongList.Add("	228: నా(డు వచ్చినట్లు గాదు నేఁడు వచ్చుట తేరి చూడరాదు క్రీస్తు నింకఁ జొత్తు మెచ్చుట ||నాఁడు||	".Trim().ToString());
            TeluguSongList.Add("	229: మహిమతో మన యేసు ఇహమునకు వేంచేయున్ సహోదరులారా మన మా మహిమలో వెలుఁగుదుము ||మహిమతో||	".Trim().ToString());
            TeluguSongList.Add("	230: అయ్యో యిది దుఃఖము ప్రభు తీర్పువేళ నయ్యో యిది యెంత దుఃఖము చయ్యన యెహోవా సింహా సనము చుట్టు వహ్ని మండు నయ్యెడ విశ్వాసులకు దు రాత్మల కగు నిత్య ఖేద ||మయ్యో||	".Trim().ToString());
            TeluguSongList.Add("	231: ఓహోహో మా యన్నలారా యుద్యోగింపండి యిపుడే త్రాహి త్రాహి యనుచుఁ క్రీస్తుని దయను గోరండి ||ఓహో||	".Trim().ToString());
            TeluguSongList.Add("	232: కోప దినము వచ్చును పాపుల గుండె పగులు కాలము వచ్చును శ్రీ పాల యేసుని దాపునఁ జేరక మాపు రేపులు మహ పాపులకును గొప్ప ||కోప||	".Trim().ToString());
            TeluguSongList.Add("	233: వచ్చును క్రీస్తు వచ్చును భూలోకమునకు వచ్చును క్రీస్తు వచ్చును చెచ్చెరను మేఘములపె రవ మిచ్చు బూర సునాదములతో హెచ్చుగను దూతస మూహము లచ్చుగను సేవింపగ్రక్కున ||వచ్చును||	".Trim().ToString());
            TeluguSongList.Add("	234: యేసు వచ్చెడి వేళాయె సోదరులారా కాశమేఘములతోను భాసురమగుతన నివాసంబునకుమనల దీసుకపోయిప్రకాశితులను జేయ ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	235: ప్రభు పునరాగమరీతి విను మో ప్రభాతగీతి చయ్యన రానయె జ్యోతి సమయంబులేదు ధాత్రి ||ప్రభు||	".Trim().ToString());
            TeluguSongList.Add("	236: రాజాధి రాజా రారా రాజులకు రాజువై రారా రాజయేసు రాజ్యమేల రారా రవికోటితేజ యేసురారా|| ఓ...మేఘ వాహనంబుమీద వేగమే ఓ.. మించు వైభవంబుతోడ వేగమే ||రాజాధి||	".Trim().ToString());
            TeluguSongList.Add("	237: పరిశుద్ధాత్మ నిత్యాత్మ పరమ పావురమా దురతేచ్ఛలను దూర పరచు సత్యాత్మా ||పరిశుద్ధాత్మ||	".Trim().ToString());
            TeluguSongList.Add("	238: దైవాత్మా దిగుము దాసుల పైని నీ దయా దృష్టిఁ పారజేయుము ప్రేమన్ నింపు దేవా యాత్ముండ దిగుము మమ్ముల శుద్ధీకరించుము దయారసముచే ||దైవాత్మా||	".Trim().ToString());
            TeluguSongList.Add("	239: ఆత్మా నడుపు స త్యము లోని కిపుడే యాత్మా నడుపు ఆత్మా నీ సాయంబు నధికంబుగా నిచ్చి ఆత్మానందముతో దై వారాధనమున ||కాత్మా||	".Trim().ToString());
            TeluguSongList.Add("	240: శ్రీ యేసు స్వామి తిరిగి మోక్షంబుఁ జేరగా ఒక్కాదరణకర్తను ఒసంగెను.	".Trim().ToString());
            TeluguSongList.Add("	241: దివ్య పావనాత్మ, నీ యీవు లన్ని మంచివి నీదు ముఖ్యదానమీ -దివ్య ప్రేమయే-	".Trim().ToString());
            TeluguSongList.Add("	242: దైవాత్మ పరిశుద్ధుడా ధారాళ ప్రేమను దండిగ నిచ్చి మమ్మును దయన్ దీవించుము.	".Trim().ToString());
            TeluguSongList.Add("	243: పరిశుద్ధాత్మను గోరుము జీవము యేసు ప్రభుని పేరట వేడుము నరు లందరి మీఁద నా యాత్మ నుంతు నని పరలోకపు తండ్రి పలికె వేదమునందు ||పరిశుద్ధాత్మను||	".Trim().ToString());
            TeluguSongList.Add("	244: పరిశుద్ధాత్ముఁడ దేవ! ప్రభువా నీ కరుణ మా పైన వర్షించు మయ్య వరుఁడా నీ భక్తుల మనముల నాత్మల బలపర్చి రక్షించి మరి స్వస్తి నిడు మయ్య ||పరి||	".Trim().ToString());
            TeluguSongList.Add("	245: రమ్ము రమ్ము పరిశుద్ధాత్మా రమ్ము రమ్ము రమ్ము దీవింపఁగ నిమ్ము నీదు కృపను నింపు మా డెందముల్ నెమ్మదిఁ బొందంగ ||రమ్ము||	".Trim().ToString());
            TeluguSongList.Add("	246: పరిశుద్ధాత్ముఁడ ప్రభువ! వరదా! మా హృదయమం దిరముల వసి యింపుమా అరుదైన నీదివ్య తరశక్తులను దాల్చి త్వరగా మాపై దిగుమా కరుణాబ్ధివై యిపుడు ||పరిశుద్ధాత్ముఁడ||	".Trim().ToString());
            TeluguSongList.Add("	247: పరిశుద్ధాత్మ ప్రభుని వరదివ్యశక్తిబం ధురము ధరణికిజీవ సంజీవము పరమౌన్నత్యంబైన పరలోక సువిశేష పరమార్థములు దెలుపు నెఱిమార్గము ||పరి||	".Trim().ToString());
            TeluguSongList.Add("	248: పరిశుద్ధాత్మా పావురమా నీ దాసులపై కరుణతో నరుదెంచుమా పరిశుద్ధుడగు యేసు పరమున కరిగి యా దరణకర్తగ నిన్ను దయచేసె గద మాకు ||పరి||	".Trim().ToString());
            TeluguSongList.Add("	249: రమ్ము పరిశుద్ధాత్మ దేవుఁడా మమ్మును గృపాస నమ్ముకడకు నెమ్మి నడుపుమా మమ్ము నడుపు దీక్షతోఁబ రమ్ము విడిచి యాత్మస్వరూ పమ్మున నరుదెంచిన దై వమ్ము నీవెకద యెహోవ ||రమ్ము||	".Trim().ToString());
            TeluguSongList.Add("	250: పరిశుద్ధాత్మునిఁ బొందుము ప్రభువిచ్చెడు వరసహాయునిఁ బొం దుము పరిశుద్ధవర్తనకు పరమసాహాయ్యంబుఁ పరముఁజేరువఱకు పరి పూర్తిగా దొరకు ||పరి||	".Trim().ToString());
            TeluguSongList.Add("	251: వినరే యపోస్తలుల కార్యముల్ క్రైస్తవు లను వారి కవి యెంతో ధైర్యముల్ మనసు లొక్కటిఁ జేసి కొని యట్లు ప్రార్థింప ఘన ముగ విమలాత్మ చనుదెంచె వారిపై ||వినరే||	".Trim().ToString());
            TeluguSongList.Add("	252: దేవుఁ డిచ్చిన దివ్యవాక్య మి దేను మన కో యన్నలారా భావ శుద్ధిని జేయు ఘన శుభ వర్తమానము దీని పేరు ||దేవుఁ డిచ్చిన||	".Trim().ToString());
            TeluguSongList.Add("	253: దేవుని గ్రంధము దినదినము చదువుము పావనమార్గము జీవము సత్యము ||దేవుని||	".Trim().ToString());
            TeluguSongList.Add("	254: ప్రభువా పంపుమా నీ శుభవర్షము నిమ్మా ప్రబలంబుగ నీ వాక్యం బనెడి విభవామృతము కురియఁజేసి ||ప్రభువా||	".Trim().ToString());
            TeluguSongList.Add("	255: సుఖ మిచ్చెగద మాకు ప్రభుయేసువా నీ సురుచిరమగు వాక్కు నిఖిలకల్మష వనమునకు దవ శిఖి శిఖిలవలె గాల్చు నీదగు ముఖవికాసిత వాక్యములు బహు సుఖము లొసఁగు తవాశ్రితాళికి ||సుఖ మిచ్చె||	".Trim().ToString());
            TeluguSongList.Add("	256: మమ్ముఁ ప్రేమఁ జూచి దేవుఁడు మకు బోధపరపఁగ ఇమ్ముగాను లేఖనముల నిచ్చె మాకు భూమిపై ||మమ్ము||	".Trim().ToString());
            TeluguSongList.Add("	257: శ్రీ వినోద దాయకంబు దేవుని వాక్యంబు జీవమునకు నాస్పదంబు చిరమగు ధనంబు భావంబుల మార్చు నంబు బహుళ సాధనంబు ||శ్రీ||	".Trim().ToString());
            TeluguSongList.Add("	258: యెహోవ పురి పునాది యిల మహా స్థిరంబైనది	".Trim().ToString());
            TeluguSongList.Add("	259: యేసు దేహము సంఘము ప్రభు క్రీస్తుపై వి శ్వాస మమరి క్రా లెడు జనము యేసు ప్రాయశ్చిత్త రక్తము దోసములను బాపు నంచు నాసతోడ నమ్మి తమ ప్ర యాసములను దీర్చుకొన్న ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	260: ఎల్ల సోదరు లైక్యత వసియించుట యెంత మేలు మనోహరము ||ఎల్ల||	".Trim().ToString());
            TeluguSongList.Add("	261: సమకూర్చుము తండ్రి క్రైస్తవ సభలో నైక్యతను ద్వరలోఁ దమ ప్రియ కొమరుఁడు శ్రమలకుఁ బూర్వం బమితాసక్తితో నడిగిన విధ మున ||సమ||	".Trim().ToString());
            TeluguSongList.Add("	262: ప్రభుక్రీస్తు యేసు ప్రేమించె సంఘమును పరిమళ వాసనగానుండ ప్రభువు చిత్తమును పరిగణించుటయె సంఘము నీ బాధ్యతగాదా! ||ప్రభు||	".Trim().ToString());
            TeluguSongList.Add("	263: సంఘ శిరసై వెలయు ప్రభువా సత్యకృప సంపూర్ణ ప్రభావా సర్వ క్రైస్తవ సంఘ మహి మా స్త్రోత్రగీతల్ స్వీకరింపుమా ||సంఘ||	".Trim().ToString());
            TeluguSongList.Add("	264: ఈ సంఘం పునాది క్రీస్తే సాధీశుఁడే దక్కించె యేసు దీని వాక్కాపుల్ రెట్టించే పై నుండి వచ్చి యేసు పెండ్లాడె నీమెనే కోరుచు రక్త మిచ్చి కొనె నీ కన్యనే	".Trim().ToString());
            TeluguSongList.Add("	265: దేవుని సీయోన్ పురమా! శ్రేష్టమౌ పట్టణమా! స్థావరంబైన పురమా! దేవుని నివాసమా! యుగముల శిలయైన దేవుడే నీ పునాదీ! శత్రువు జయించలేని రక్షణ నీ దుర్గము.	".Trim().ToString());
            TeluguSongList.Add("	266: ఘన యెహోవా నీ గుడారం బున నతిథియౌ వాడెవండు తనర నీ పరిశుద్ధ పర్వత మున వసించెడు వాఁడెవండు ||ఘన||	".Trim().ToString());
            TeluguSongList.Add("	267: ఎంతో సుందరమైనవి ధర గిరులపై నెంతో యందమైనవి సంత తంబుఁ బరమ ప్రేమను దెల్ప సంతస మందుచు సరిగ బ్రకటన జేయ అంతటను బనిఁ బూని ప్రభు న త్యంతముగఁ బ్రక టించి వసుధ న నంత మగు శుభవార్తఁ జాటెడు వింత యగు బోధకుల పాదము ||లెంతో||	".Trim().ToString());
            TeluguSongList.Add("	268: పరిశుద్ధాత్ముఁడ, లెమ్ము నీ సంఘముపై నీ వర దీవెనల నుంచుమీ చిరుత కాలపు సభ కా పరు లొంది నీ యగ్ని యరుల నెదిరించి చా టిరి నీదు సత్యంబు ||పరి||	".Trim().ToString());
            TeluguSongList.Add("	269: అడుగుచున్నా మో దేవ కడు దయను గావఁ జెడుగుల మైన మేము ని న్నడుగుటకు నే బిడియ మొందము అడుగుఁడి మీ కిడియెద నంచు నాన తిచ్చిన వాగ్దానమునఁ గని ||యడుగు||	".Trim().ToString());
            TeluguSongList.Add("	270: దీవెనల నిడు దేవా నీదు సేవకై వెడలెడు దీనులపైఁ పావనాత్మ నంపుము పనులలో నడిపింపుము కేవలంబుగ మా తనువులు నీ సేవకై యర్పింప గజేయుము ||దీవెనల||	".Trim().ToString());
            TeluguSongList.Add("	271: వినరే నరులారా మనముల వేడుకలను మీర మన, రక్షకుఁడగు మరియా తనయుని మహిమలు చెవులార ||వినరే||	".Trim().ToString());
            TeluguSongList.Add("	272: దేవా శిశువుల( దెచ్చితిమి నీవు దీవించువీరల దివ్య కృపమీర||దేవ||	".Trim().ToString());
            TeluguSongList.Add("	273: యే సొసంగె గొప్ప యాజ్ఞను తన శిష్యులకును యేసొసంగె గొప్ప యాజ్ఞను దాసులునుగఁ జేయ బోయి ధరణిమీఁది రాష్ట్రములకు ఆ సను బాప్తిస్మ మిచ్చి నా సుబోధ నేర్పుఁడనుచు ||యేసొసంగె||	".Trim().ToString());
            TeluguSongList.Add("	274: ఆచరించుచునున్నాము ఆ చందము మేము యే చందమేసు ప్రభు సెల విచ్చివేంచేసితో పరమండలికి ||ఆచరించు||	".Trim().ToString());
            TeluguSongList.Add("	275: రండి రండి సువార్తబోధ విన రారోజనులారా నిండు మనంబుల కోర్కెలూరగను నిజరక్షకుఁడగు యేసునిఁ జేర ||రండి||	".Trim().ToString());
            TeluguSongList.Add("	276: మనస! యాత్మ! తేజరిల్లుమా యలంకరించు కొనుము పాప మంత వీడుమా వినుము నేఁడు యేసు నీకు ఘనముగాను విందుఁ జేసి నినుఁ దలచి చేరవచ్చె ఘనుని వెల్గులోని కేగుము ||మనస||	".Trim().ToString());
            TeluguSongList.Add("	277: ఓ దయానిలయా! ప్రభువా! మా కున్న స్వనీతి బలముగాక నీ దయాహృదయంబె నమ్ముచు నీదగు బల్లను జేరఁదెగించితి ||మో దయా||	".Trim().ToString());
            TeluguSongList.Add("	278: జీవాహారము రమ్ము చిరజీవాన్నము నిచ్చి జీవిత క్షుద దీర్చుము జీవనపథములో చీకటి పడువేళ జీర్ణించు కొనిపోవు జీవితాశలఁ బెంచ ||జీవా||	".Trim().ToString());
            TeluguSongList.Add("	279: దేవా దీవించు మిప్పుడు దీన జనాళిన్ గావ రా రమ్మెల్లప్పుడు నీ వరగద్దెచుట్టు నిజ దాసు లిటులఁ గూడి పావన సంస్కారమును బంచి పాలొందుచుండ ||దేవా||	".Trim().ToString());
            TeluguSongList.Add("	280: చేరి భుజియింపుడీవిందు యేసు సిద్ధపరచిన కృపావిందు తోరణంబగు మేడ గదిలో జేరి శిష్యుల తోడ సిలువ భారమున్ మదినెంచి నెరపిన భావ గర్భితమైన విందు ||చేరి||	".Trim().ToString());
            TeluguSongList.Add("	281: మానవుఁడవై సకల నరుల మానక నా దోషములఁ బాపుటకు బలి యైతివే యేసూ బహు ప్రేమతోడ ||మానవుఁడవై||	".Trim().ToString());
            TeluguSongList.Add("	282: మన యేసు మరణస్మా రణవిందులోఁబాలు గొనరండు ప్రియులార వినయమానసులై మన దోష చయమెల్లఁ దనమేన ధరియించు కొనిమనల గావ నా యన పడిన శ్రమలెంచి ||మన యేసు||	".Trim().ToString());
            TeluguSongList.Add("	283: స్తోత్రార్పణ నర్పింతము జప ధూపము వేసి కీర్తింతము పాత్రుం డైన శ్రీ యేసుఁడు పరమ భోజనాంశమైనందున ||స్తోత్రార్పణ||	".Trim().ToString());
            TeluguSongList.Add("	284: యేసూ, నిన్ జూతు నిందుఁ దేటగా అగోచరార్థముల్ నే ముట్టదున్ కృపన్ నేఁ బట్టకొందు గట్టిగా నీ మీఁద వేయుదున్ నా భారము.	".Trim().ToString());
            TeluguSongList.Add("	285: శ్రీ రాజిల్లుచు యేసు క్రీస్తు వేంచేసెను భారతిని జయించి ప్రజాళిన్ బ్రోచును! ఆరాజు శాశ్వితుండు భూరిదయాళుఁడు వీరాగ్రేసరుండాజిన్ విజయ ధ్వజంబదె!	".Trim().ToString());
            TeluguSongList.Add("	286: గ్రీన్లాండ్ దేశస్థులును ఇండియా జనులున్ ఆఫ్రికా ఖండమందు నివాసులెల్లరు సముద్ర ద్వీపస్థులు సువార్త వెలుగు మాకు నిప్పించుడని మమ్మును పిల్తురు.	".Trim().ToString());
            TeluguSongList.Add("	287: శ్రీయేసు రాజ్య ముండును సూర్యుండు వెల్గు చోటెల్ల కల్పాంతకాల మౌదాక ఆ రాజ్యము వ్యాపించును.	".Trim().ToString());
            TeluguSongList.Add("	288: శుభవార్త వింటిమి యేసు రక్షించును ఎల్లవారు విననీ యేసు రక్షించును ప్రభు మాట వింటిరా పర్వతంబుల్ దాటుచు వార్త ప్రకటింపుడి యేసు రక్షించును.	".Trim().ToString());
            TeluguSongList.Add("	289: ఇఁక నేమి గతి యున్నది మానవులారా యిఁక నేమి గతి యున్నది పాపులకోస మిఁక నేమి గతి యున్నది యొకఁ డైనఁ ఋణ్యాత్ముఁ డుర్వి లేఁడని ముందె ప్రకటించి దావీదు పల్కె వేదము నందు ||ఇఁక||	".Trim().ToString());
            TeluguSongList.Add("	290: ఎందుకు మఱచితివి యేసుని ప్రేమ ఎందుకు మఱచితివి ఎందుకు మఱచితివి పొందితివి నిందలు సుందర మగునట్టి సుఖమైన ప్రభు ప్రేమ ||నెందుకు||	".Trim().ToString());
            TeluguSongList.Add("	291: ధరణిలోని ధనము లెల్ల ధరణిపాలై పోవును గరిమతోడ నీవు గైకొను నిరత ముండెడి ధనమును ||ధరణి||	".Trim().ToString());
            TeluguSongList.Add("	292: నిజముగాఁ పరిశుద్ధు డొకఁ డీ నేలపై లేఁడు వృజినములచేఁ జెడిన మదిని బ విత్రమూలం బెటుల బొడమును ||నిజము||	".Trim().ToString());
            TeluguSongList.Add("	293: పాపులకు సఖుండు మన ప్రాపు యేసె సుమండి భువి పాపులకు సఖుండు ||పాపులకు||	".Trim().ToString());
            TeluguSongList.Add("	294: యేసునే సేవింపరండి మోసపోకండి ప్రభు దోసములను బాపు నండి దొడ్డ ప్రభువండి ప్రభు ||యేసునే||	".Trim().ToString());
            TeluguSongList.Add("	295: మన మొదటి తల్లిదండ్రులల్ మాయకు లోనైరి అన్నలారా వారి కనుగొనలకు సిగ్గు గదుర మోములు వంచి రన్నలారా ||మన||	".Trim().ToString());
            TeluguSongList.Add("	296: నమ్మరె నరులార యేసుని సమ్మతిగాఁ జేరి నమ్మిన వారల నిమ్ముగ బ్రోచును సొమ్ముగ తను జేర్చి ||నమ్మరె||	".Trim().ToString());
            TeluguSongList.Add("	297: యేసు క్రీస్తుని గొల్వ రన్న యీ జగతిలోన నెవ్వరు లేరు వాని కన్న యేసుని వాక్యము ఎవ్వరి కబ్బునో దోసము విడి పర వాసము దొరకును ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	298: రండి యేసుని యొద్దకుఁ ప్రియులారా మీరు రండి యేసుని యొద్దకు రండి రండి రయమున బిలుచుచు నుండెడి రక్షకుఁ డొసఁగెను బ్రాణము ||రండి||	".Trim().ToString());
            TeluguSongList.Add("	299: యేసు నాథ కథా సుధా రస మిదిగో పానముఁ జేయరే దోసకారి జనంబులారా దురిత భవముల బాయరే ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	300: రారె యేసుని జూతము కోరిక దీర రారె యేసుని జూతము రారె యేసుని జూడ రారాజై మన జీవా ధార కరుణామృత సారమై యున్నాఁ డు ||రారె||	".Trim().ToString());
            TeluguSongList.Add("	301: రారో జనులారా వేగముఁ గూడి రారో ప్రియులారా శాశ్వతమైన ఘన రక్షణఁ జేర సారాసారముల్ సమ్మతిగాఁ జూచి ధీరత్వమునఁ క్రీస్తు జేరు దారిఁ గోరి ||రారో||	".Trim().ToString());
            TeluguSongList.Add("	302: యేసుని సుచరిత మెంత పొనరినది యెవ్వరు విని యెద రీ జగతిన్ భాసుర నయ మను బంధము గలిగిన భక్తుల కిది సౌ భాగ్యముగా ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	303: పోయెఁగ పోయెఁగ కాలము వెళ్లి పోయెఁగ పోయెఁగ మాయ సంసార సం పదఁ గూర్ప మరిగి యాయు వంతయు వ్యర్థ మైపోయెఁ దరిగి ||పోయెఁగ||	".Trim().ToString());
            TeluguSongList.Add("	304: వినరే యేసుక్రీస్తు బోధ మదిని గొనరే యాతని సత్య బోధ వినిన యేసుని బోధ విశ్వాసమున మీరు గొనయెదరు నిజముగ గొప్ప భాగ్యంబులు ||వినరే||	".Trim().ToString());
            TeluguSongList.Add("	305: రండి మానవులారా రక్షకునిన మ్మండి వేగము ప్రియులారా రండి పాపుల బ్రోచుటకు పర మండలంబును విడిచి యీ భువి మండలంబున కరుగుదెంచిన మహాత్మున్ గనుగొని సుఖింపను ||రండి||	".Trim().ToString());
            TeluguSongList.Add("	306: పాపినినేనని ప్రభుపదములకడ ప్రార్థన సేయుము ఓ మనసా పాపుల మిత్రుడు ప్రభు యేసునికడ పాపక్షమాపణ కలదో మనసా ||పాపిని||	".Trim().ToString());
            TeluguSongList.Add("	307: హే ప్రభుయేసు హే ప్రభు యేసు హే ప్రభు దేవసుతా సిల్వధరా పాపహరా, శాంతికరా ||హే ప్రభు||	".Trim().ToString());
            TeluguSongList.Add("	308: పాపకూపమునందు పడి మునిగియున్నావు పాటింపవది యెందుకు పాప జన్మము పాపకర్మము పాపపూరితమైన హృదయము ఓపరాని భయంకరోగ్రత శాపములు సమకట్టియుండగ ||పాప||	".Trim().ToString());
            TeluguSongList.Add("	309: దారుణ మగు మరణ వారిధి దాఁట నె వ్వారి శక్యము సోదర ఘోర మగు కెరటములవలె వి స్తారముగ నేరములు పైఁగొని పారు చుండునప్పు డద్దరిఁ జేరు టెట్లు దారిఁ గనరే ||దారుణ||	".Trim().ToString());
            TeluguSongList.Add("	310: హృదయమనెడు తలుపు నొద్ద యేసు నాధుండు నిలచి సదయుఁ డగుచుఁ దట్టుచుండు సకల విధములను ||హృదయ||	".Trim().ToString());
            TeluguSongList.Add("	311: జను లందఱు వినండి దివ్య సంగతి తండ్రియైన దేవుఁ డెంత ప్రేమ చూపెను. ||యేసు క్రీస్తు నాకుఁగాను బ్రాణ మిచ్చెను తన్ను ఁ జేర నన్ను ఁ బిల్చెన్ క్రీస్తు వత్తును ||	".Trim().ToString());
            TeluguSongList.Add("	312: మహా వైద్యుండు వచ్చెను ప్రజాళిఁ బ్రోచు యేసు సహాయ మియ్య వచ్చెను సంధింపరండి యేసున్ || మాధుర్యంపు నామము మోద మిచ్చు గానము వేద వాక్యసారము యేసు దివ్య యేసు ||	".Trim().ToString());
            TeluguSongList.Add("	313: త్రాహి మాం క్రీస్తు నాధ దయఁ జూడ రావే నేను దేహి యనుచు నీ పాదములే దిక్కుగాఁ జేరితి నిపుడు ||త్రాహి||	".Trim().ToString());
            TeluguSongList.Add("	314: దేవ! దీనపాపిని ఓ పావన గావు కృపా బహుళ్యము చేత ||దేవా||	".Trim().ToString());
            TeluguSongList.Add("	315: ఉన్నపాటున వచ్చు చున్నాను నీ పాద సన్నిధి కో రక్షకా యెన్న శక్యముగాని పాపము లన్ని మోపుగ వీపుపైఁబడి యున్న విదె నడలేక తొట్రిలు చున్నవాఁడను నన్ను దయఁగను ||ఉన్న||	".Trim().ToString());
            TeluguSongList.Add("	316: దిక్కులేని వాఁడనో ప్రభో నీ యండజేరి మ్రొక్కి సేవఁజేతు నో ప్రభో మ్రొక్కి విన్నవించు వారి యక్కరలను దీర్చు సత్యము గ్రక్కున నిడి యాదరించు మక్కువైన దేవ తనయ ||దిక్కులేని||	".Trim().ToString());
            TeluguSongList.Add("	317: పాపము దలఁచు సుమీ పశ్చా త్తాపముఁ బొందు సుమీ దాపని యేసుని పాదంబులబడి పాపము వీడు సుమీ ||పాపము||	".Trim().ToString());
            TeluguSongList.Add("	318: పాపినయ్యా నేఁ బాపి నయ్యా కాపాడ వయ్యా పాపభారము నుండి పాపు మయ్యా నన్నుఁ పాపభారమునుండి పాపు మయ్యా ||పాపి||	".Trim().ToString());
            TeluguSongList.Add("	319: ఎఱింగి యెఱిఁగి చెడిపోతివి మనసా యిఁక నీ దిక్కెవ్వరు చెపుమా దురితం బిది స చ్ఛరితం బిది యని యెరుక సరకు గొన కేమియు నీ ||యెఱిఁగి||	".Trim().ToString());
            TeluguSongList.Add("	320: యేసు విభునిఁ దలఁచి మదిలో ద్వేషము లణఁగింపరే మోస విశ్వ భ్రాంతు లెల్ల రోసి పరిహర్షింపరే ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	321: ఆదరింపుము యేసువా ని న్నాశ్రయించితి నా కికన్ లేదు వేరొక యాశ్రయంబని లెస్సగా మది నమ్మితిన్ ||ఆద||	".Trim().ToString());
            TeluguSongList.Add("	322: శరణు నా యేసు ప్రభువా నీవెగా పరలోకమునకుఁ ద్రోవ కరుణతో నన్నుఁ గావ నీ కన్న గర్త యెవ్వఁడు యేసువా ||శరణు||	".Trim().ToString());
            TeluguSongList.Add("	323: రావయ్య యేసునాధా మా రక్షణమార్గము నీ సేవఁ జేయ మమ్ముఁ జేపట్టుటకు ||రావయ్య||	".Trim().ToString());
            TeluguSongList.Add("	324: ఏ ముఖాంబుతోడ వత్తు యేసు నాధనీదు మ్రోల కావరించి నిన్నుమఱచి యేక మైతి బామరులతో నేది దారి నిన్నుఁ జేర నేమో తెలియదాయెను ||ఏ ముఖంబు||	".Trim().ToString());
            TeluguSongList.Add("	325: నన్ను దిద్దుము చిన్న ప్రాయము సన్నుతుండగు నాయనా నీవు కన్న తండ్రి వనుచు నేను నిన్ను ఁ జేరితి నాయనా ||నన్ను||	".Trim().ToString());
            TeluguSongList.Add("	326: నమ్మితి నయ్యా యేసయ్యా నీ పాదములే నమ్మితి నయ్యా యేసయ్యా నమ్మితి నయ్య నా నెమ్మదిలో నిన్ను నిమ్ముగఁ గృప నాపైఁ గుమ్మరిం చుము వేగ ||నమ్మితి||	".Trim().ToString());
            TeluguSongList.Add("	327: దేవ నీవు నన్ను ఁ బరిశో ధించి బాగుగఁ దెలిసికొంటివి నీ వెఱుఁగు దువు నేను కూర్చుండుటయును నే లేచుటయును ||దేవ||	".Trim().ToString());
            TeluguSongList.Add("	328: పాప పశ్చాత్తాప మొందని వారికి పరమ భాగ్య మేడ నబ్బునే మనసా పాపాత్ములకు యేసు పరమండలము నుండి భూమధ్యమునకుఁ దా వచ్చెను పాపిష్ఠుల రమ్మని పిలిచెను నా ప్రాపుఁ గోరుమని చెప్పెను మనసా ||పాప||	".Trim().ToString());
            TeluguSongList.Add("	329: పాపిని కృప జూపవయ్యా దాపు జేరితిని యేసయ్యా పాప భారము క్రింద శ్రమపడి కృంగియున్నాను యేసయ్యా ||పాపి||	".Trim().ToString());
            TeluguSongList.Add("	330: ఖండింపవలెను దుర్గుణములు ఖండింపవలెను ఖండింపవలెఁ బాప ముండఁజూచి యేసు నండఁజేరి మన గుండె పదిలముఁ జేసి ||ఖండింప||	".Trim().ToString());
            TeluguSongList.Add("	331: మనసా వినవేమే క్రీస్తునిఁ గని సేవింపవేమే అనుదినమున నీ కాయువు క్షీణం బగుచున్నది గదవే ||మనసా||	".Trim().ToString());
            TeluguSongList.Add("	332: అపరాధిని యేసయ్య కృప జూపి బ్రోవుమయ్యా నెపమెంచకయె నీ కృపలో నపరాధములను క్షమించు ||అప||	".Trim().ToString());
            TeluguSongList.Add("	333: పశ్చాత్తాపము బొందుము జీవమ నీవు ప్రభుని సన్నిధి కేగుము పశ్చాత్తాపములేని ప్రజలెవ్వరికి గాని నిశ్చయముగ గల్గు నిత్యమౌ నరకంబు ||పశ్చాత్తా||	".Trim().ToString());
            TeluguSongList.Add("	334: ఉన్నట్టు నేను వచ్చెదన్ పాపిష్ఠు న్నీవు పిల్వఁగన్ నీ నెత్రుచేతఁ గడ్గుమా యో గొఱ్ఱె పిల్ల దేవుఁడా!	".Trim().ToString());
            TeluguSongList.Add("	335: ఓ యేసు, రక్షకా నీ పిల్పు విందును కల్వరి పై నా పాపము నివృత్తి చేసితి. ||యేసు, వచ్చెదన్ నన్ను ఁ జేర్చుము నన్ నీ రక్తమందున పవిత్ర పర్చుము ||	".Trim().ToString());
            TeluguSongList.Add("	336: యేసు, నీదు జాలివల్ల లెక్క లేనివారలు రక్షణంది సంతసిల్ల నిమ్ము వారి డెందముల్ నీదు సిల్వ వంతవార్తఁ జాటఁజేసి రాష్ట్రముల్ చూడ నిమ్ము త్రాణకర్త! నీ కృపా ప్రకాశముల్	".Trim().ToString());
            TeluguSongList.Add("	337: తన యక్రమములకు క్షమా పణ నొందినవాఁడు తన పాప ములకు బ్రాయశ్చిత్తము బును బొందినవాఁడును ధణ్యుండౌ ||తన||	".Trim().ToString());
            TeluguSongList.Add("	338: యేసుఁడు రాఁగన్ జేసిన దోషము నాశన మాయెన్ ||యేసుఁడు||	".Trim().ToString());
            TeluguSongList.Add("	339: ఎంత పాపి నైనను యేసు చేర్చుకొనును అంచు నీ సువార్తను అంతటఁ జాటించుఁడి ||హల్లెలూయ హల్లెలూయ యెంత పాపి నైనను యేసు చేర్చుకొనున టంచుఁ బ్రకటించుఁడి||	".Trim().ToString());
            TeluguSongList.Add("	340: సిల్వ చెంత నేసువా చేర్చి నన్ను నుంచు కల్వరిన్ స్రవించెడు కల్వలో నన్నుంచు. ||సిల్వకే సిల్వకే చెల్లునా విముక్తి చెల్వ మొప్ప నద్దరిన్ జేర నాకు ముక్తి ||	".Trim().ToString());
            TeluguSongList.Add("	341: డాగు నేది మాపును వేగ యేసు రక్త ధారే రోగి కేయౌషథము బాగుగా నా రక్త ధారె || హా దివ్య రక్తము ఆ బుగ్గ వినహా యేదియు లేదుగా యేసు యొక్క రక్త ధారె ||	".Trim().ToString());
            TeluguSongList.Add("	342: నాకై చీల్చఁబడ్డ యో నా యనంత నగమా నిన్ను డాగి యందునఁ చెను మీరఁ బారెడు రక్త జలధారలా సక్తిఁ గ్రోలఁగా నిమ్ము.	".Trim().ToString());
            TeluguSongList.Add("	343: ఇమ్మానుయేలు రక్తము ఇంపైన యూటగు ఓ పాపి! యందు మున్గుము పాపంబు పోవును ||యేసుండు నాకు మారుగా ఆ సిల్వఁ జాపఁగా శ్రీ యేసు రక్త మెప్పుడు స్రవించు, నాకుఁగా ||	".Trim().ToString());
            TeluguSongList.Add("	344: పరమ రాజ్యమునకు నరులు తిరిగి పుట్టవలయు ననుచుఁ బరమ గురువు యేసు క్రీస్తు స్థిరము చేసెను ||పరమ||	".Trim().ToString());
            TeluguSongList.Add("	345: హా! యానంద సుదినము నా యేసున్ నమ్ము దినము ప్రయాస మెల్ల బోయిన దయా రక్షణ దినము. ||భాగ్యమౌ దినము ప్రభున్ గైకొన్న దినము భక్తి ప్రార్థన లేసుఁడు ప్రఖ్యాతి నాకు నేర్పిన భాగ్యమౌ దినము ప్రభున్ గైకొన్న దినము ||	".Trim().ToString());
            TeluguSongList.Add("	346: యేసు నావాడని నమ్ముదున్ భాసిల్లు దివ్య సౌభాగ్యము దాసుఁడ నౌచు పాల్పొందెదన్ నాశంబు లేని సౌఖ్యంబును. ||ఇదే నా పాట నాసుకధ యేసుని సదా స్తుతించుట ఇదే నా పాట నాసుకధ యేసుని నిత్యం ధ్యానించుట ||	".Trim().ToString());
            TeluguSongList.Add("	347: ఆనంద మగు ముక్తి యే నా మందిరము జ్ఞాని మానుగఁ జూచు దాని సుందరము ||ఆనందమగు||	".Trim().ToString());
            TeluguSongList.Add("	348: నా కింత ప్రోత్సాహా నందంబుల్ గల్గుట కే కర్త ఘనమైన హేతువై యుండు నాకు గల యున్నత కతమ్మే నాధుఁ డగును నేను మురియు శ్రీకరంబగు నామ మేది సిల్వఁబడ్డ యేసు క్రీస్తే ||నా కింత||	".Trim().ToString());
            TeluguSongList.Add("	349: సంతోషింపరె ప్రియులారా యేసుని చెంత సంతసింపరె మనసార ఎంతో ప్రేమించి య నంతు డొసగెను సుతుని వింతగ బ్రతుకువ సంత శోభను దాల్చె అంతరంగములో వసించిన చింత లెల్లను వాడ బారెను గంతు లిడుచును నూత్నజీవ ల తాంతములు పూయంగ దొడగెను ||సంతో||	".Trim().ToString());
            TeluguSongList.Add("	350: నా యేసు! నా యాత్మ బలమా! నీదు గాయంబులే నిలువబలమైన స్థలము సకల సృష్టి పునాదియపుడే నాదు సకల పాపములకై బలియైతి వేసు! సకల భూమ్యాకాశములను సమము గా గతించినఁగాని నీ ప్రేమ నిలుచు ||నా||	".Trim().ToString());
            TeluguSongList.Add("	351: నీ కన్న నిఁక వేరే వేల్పులు లేరయ్యా నిజముగా నా యేసువా నీ కరుణ యను నెనరుచేతను నీదు సత్య సువార్త ద్వార ప్రాకటంబుగ నన్నుఁ బిలిచిన లోక రక్షక నీకు మ్రొక్కెద ||నీ కన్న||	".Trim().ToString());
            TeluguSongList.Add("	352: వెలుగును రక్షణ కర్తయునగునా బలమగు దేవుని స్తోత్రింతును వెరువను నేనిక నెవ్వరికిన్ వెలుగైన యేసే నా దుర్గము	".Trim().ToString());
            TeluguSongList.Add("	353: నేను క్రీస్తు ప్రభుని జేరి నేను క్రీస్తువాడ నౌదు నేను క్రీస్తు సొత్తు గాన నేను నా సమస్తమును నాధు డేసు కిపుడు యిత్తు ||నే||	".Trim().ToString());
            TeluguSongList.Add("	354: దాపుఁజేరుచుఁ బాడుము జీవపు మాటలన్ మాధుర్యంబగు గానము మరలఁ బాడుము జీవమైన పాటన్ త్రోవఁజూపు మాటన్ || సుందర మానందముగన్ సొంపుగఁ బాడుము ||	".Trim().ToString());
            TeluguSongList.Add("	355: యేసుని జేరఁ వేగము రా మార్గముఁ జూపి వేదములో దాపున నుండి క్రీస్తు దయన్ రమ్మని పిల్చును. || సంతసంబు సంతసంబు బల్ పాపశుద్ధి మేము పొందఁగా యేసుని యెద్దనుండ సదా మోక్ష పథంబున ||	".Trim().ToString());
            TeluguSongList.Add("	356: సాక్ష్య మిచ్చెద స్వామి యేసు దేవుఁ డంచు సాక్ష్య మనఁగఁ గనిన వినిన సంగతులను దెల్పుటయే సాక్ష్య మిచ్చు కొఱుకు నన్ను స్వామి రక్షించె నంచు ||సాక్ష్య||	".Trim().ToString());
            TeluguSongList.Add("	357: ఇతరుల సాక్ష్యము లెంతో గలిగియున్న మరి సాక్ష్యమే మంచిది మృతిబొందిలేచియు న్నతమోక్ష రాజ్యాధి పతియై యున్న యేసు ప్రభువే మా విభుఁడైన ||నితరుల||	".Trim().ToString());
            TeluguSongList.Add("	358: సిలువ సైనికులారా నిలువండి వడి లేచి బలుఁడు యేసుక్రీస్తు ప్రభు దయ జయ మౌను ||సిలువ||	".Trim().ToString());
            TeluguSongList.Add("	359: వీరుల మయ్యా జయ వీరుల మయ్యా మా వైరిఁ జంప యుద్ధమాడు శూరుల మయ్యా ||వీరుల||	".Trim().ToString());
            TeluguSongList.Add("	360: యేసు క్రీస్తు మతస్థుఁ డనఁగా నెఱిఁగి మనుఁడీ జగము లోపల వాసిగాఁ ప్రభు యేసు దాసులె పరమునందు ని వాసులగుదురు ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	361: యేసుప్రభుకై సాక్షులెవరెవరో ఎవ్వరెవ్వరో యని యాశతో ప్రభు వడుగుచున్నాడు యేసు కొరకై నిల్చి క్రైస్తవ యువకులెల్లరు సాక్ష్యమిచ్చుచు భాసురంబుగ క్రీస్తు నెంతో భారతీయులు ప్రస్తుతించరో ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	362: క్రీస్తు యోధులారా యుద్ధ మాడుఁడీ క్రీస్తు సిల్వ మీరు పట్టి గెల్వుఁడీ మన రాజు క్రీస్తు దండు నడ్పును చూడు మాకు ముందు క్రీస్తు ధ్వజము. || క్రీస్తు వీరులారా యుద్ధ మాడుఁడీ క్రీస్తు ధ్వజ మెత్తి జయ మొందుఁడీ ||	".Trim().ToString());
            TeluguSongList.Add("	363: ఓ యేసు భక్తులారా, మీ రాజు ధ్వజము గ్రహించి సాహసించి పోరాడి గెల్వుఁడీ విశ్వాసులార, రండి మీ రక్షణార్థమై ప్రయాసపడ్డ యేసు విజయ మిచ్చును.	".Trim().ToString());
            TeluguSongList.Add("	364: నా యాత్మ! లెమ్ము! సిద్ధము కమ్ము నా రాజిఁ బూని పాయక పోర వలెను నిజమ్ము వేయి శరంబుల నేయుచు శత్రు వ మేయత నిను పడఁ ద్రోయఁ దెగించెను ||నా యాత్మ||	".Trim().ToString());
            TeluguSongList.Add("	365: లేలెమ్ము క్రైస్తవుఁడా నీలో మేల్కొని లేలెమ్ము క్రైస్తవుఁడా నీలో మేల్కొని ||లేలెమ్ము||	".Trim().ToString());
            TeluguSongList.Add("	366: ఏల చింత యేల వంత యిచట నీకు క్రైస్తవ పాలకుండు యేసు నీదు వంత లెల్ల నెరుఁగుఁగా ||యేల||	".Trim().ToString());
            TeluguSongList.Add("	367: దేవా! వెంబడించితి నీ నామమున్ జీవితేశ్వర నా జీవితాశ నీవే రావె నా భాగ్యమా యేసువా ||దేవా||	".Trim().ToString());
            TeluguSongList.Add("	368: భయమేల క్రైస్తవుండా నీవిక నపజయమున బ్రతుకనేల జయ శూరుడగు ప్రభువు యిలనీకు జయము నిచ్చుచు నుండగ ||భయమేల||	".Trim().ToString());
            TeluguSongList.Add("	369: శోధనకు మీరు చోటియకుఁడి ధైర్యము వహించి పోరాటమును సాధించెడు వారు జయించెదరు సాతానుకు లొంగఁ బాపం బగును. ||యేసు శక్తిని గోరి యెల్లకాలము వేఁడుఁ డేసుఁ డాశతో మిమ్ము డాసి నడుపును ||	".Trim().ToString());
            TeluguSongList.Add("	370: నా దేవ ప్రభువా నీ చెంతను సదా వసింపను నా కిష్టము ఏవైన శ్రమలు తటస్థమైనను నీ చెంత నుందును నా ప్రభువా	".Trim().ToString());
            TeluguSongList.Add("	371: జీవితంబు ఘోర కష్టనష్టంబుల్ ఆవరించి నిన్ను దుఃఖపర్చిన దేవుడిచ్చినట్టి ఈవులెంచుము నీ వాశ్చర్య మొందెదవు. వానికై. ||ఎంచుము లెక్కించు మీవులన్ ఎంచుచూడు మేసుదీవెనల్ ఎంచు మెంచు మెంచు మీవులన్ వింత నొందెదవు నీవు వానికై ||	".Trim().ToString());
            TeluguSongList.Add("	372: ఓ మా తండ్రి నీదు నామము నిత్య మెన్ను చుండు గాక సకల లోకము క్షేమముగను విమలముగను జెన్ను మిరగఁ బరలోక ధాముఁడవై వెలయునట్టి ధన్య సౌజన్యమాన్య ||ఓ మా తండ్రి||	".Trim().ToString());
            TeluguSongList.Add("	373: దాసుల ప్రార్థన దప్పక యెసఁగెడు యేసు నాయకుఁడై మా వేల్పు దోసములు సేయు దుర్జనుఁడైనను దోసి లొగ్గఁ బర వాసి జేయునఁట ||దాసుల||	".Trim().ToString());
            TeluguSongList.Add("	374: పరమ నందుండెడు మా పరమ జనక నీదు పేరు పరిశుద్ధం బగును గాక త్వరగను నీ రాజ్యంబు ధరకు నరుగు దెంచుఁగాక పరమునందు నెట్టులనో ధరణియందు నట్లు నీ చి త్తంబు నెరవేరుఁగాక ||పరమ||	".Trim().ToString());
            TeluguSongList.Add("	375: ఆలించు దేవా నా మనవుల నాలించు దేవా యాలించు నా దేవ యన్ని సమయంబులఁ జాల గనపరచుచుఁ జక్కని నీ దయ ||ఆలించు||	".Trim().ToString());
            TeluguSongList.Add("	376: దేవా సహాయము నిమ్మా జీవంపు టూటలు ద్రావుట కిమ్మా ||దేవా||	".Trim().ToString());
            TeluguSongList.Add("	377: నన్ను ఁ గన్నయ్య రావె నా యేసు నన్నుఁ గన్నయ్య రావె నా ప్రభువా ||నన్ను||	".Trim().ToString());
            TeluguSongList.Add("	378: కఱుణాపీఠము జేరరే దేవుని కృపా చరణ స్థలిని జేరరే పరలోక జనకుని వరములు లభియించు తరుణమౌ ప్రార్థనలో కరములు జోడించి ||కఱుణా||	".Trim().ToString());
            TeluguSongList.Add("	379: యేసు పరలోక నాయక సువి శేష సుఫల ప్రదాయక దోషరహిత ప్ర క్రాశ స్వయ ఛిద్వ లాస పరమ ని వాస బుధ దేవ ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	380: నా యేసు నాధా ననుఁ జూడవే నా జీవనాధా నా యేసునాధ మా నవ పాప మోచక నీ యనుగ్రహముచే నిరతంబు భువిలోన ||నా యేసు||	".Trim().ToString());
            TeluguSongList.Add("	381: నిన్ను నేను విడువను దేవ నీవు నను దీవించు వరకు నిన్ను నమ్మినవారల నెల్ల నీవు చక్కఁగ దీవించెదవు ||నిన్ను||	".Trim().ToString());
            TeluguSongList.Add("	382: విన రమ్ము యేసు నాధుఁడ నా మనవి నిప్పుడు ఘన మైన నీదు నెనరుచే ననుఁ గావు మెప్పుడు ||విన రమ్ము||	".Trim().ToString());
            TeluguSongList.Add("	383: ప్రార్థన వినెడి పావనుడా ప్రార్థన మాకు నేర్పుమయా ||ప్రార్థన||	".Trim().ToString());
            TeluguSongList.Add("	384: ఓ ప్రార్థనా సుప్రార్థనా నీ ప్రాభవంబున్ మరతునా? నా ప్రభువున్ ముఖా ముఖిన్ నేఁ బ్రణుతింతు నీ ప్రభన్ నా ప్రాణమా సు ప్రార్థనా నీ ప్రేరణంబుచేఁ గదా నీ ప్రేమధారఁ గ్రోలుదు నో ప్రార్థనా సుప్రార్థనా.	".Trim().ToString());
            TeluguSongList.Add("	385: యేసు, నీ సదాత్మ వృష్టి భక్తు లెల్లవారిపై నీవు కుమ్మరింపఁగాను నాపైఁ గుమ్మరించుమీ. || నన్నునున్, నన్ను నున్ నన్నాశీర్వదించుమీ ||	".Trim().ToString());
            TeluguSongList.Add("	386: ఆశీరవంబు ల్మామీఁద వర్షింపజేయు మీశ యాశతో నమ్మి యున్నాము నీసత్య వాగ్దత్తము. || ఇమ్మహి మీద క్రుమ్మరించుము దేవ క్రమ్మర ప్రేమ వర్షంబున్ గ్రుమ్మరించుము దేవా ||	".Trim().ToString());
            TeluguSongList.Add("	387: రక్షకా, నన్ మర్వఁబోకు మొఱ్ఱ నాలించు అన్యులైనవారిఁ బిల్వన్ మర్వఁబోకు నన్ ||యేసు, యేసు మొఱ్ఱ నాలించు అన్యులైన వారిఁ బిల్వన్ మర్వఁబోకు నన్ ||	".Trim().ToString());
            TeluguSongList.Add("	388: విశ్వాసముతో వేఁడెడి వారికి విశ్వ మంతయును వీల్పడును శాశ్వత రాజ్య థీశ్వరుఁ డాఢ్యుఁడు శాశ్వత మగు నీ శాసన మె చ్చెను ||విశ్వా||	".Trim().ToString());
            TeluguSongList.Add("	389: విశ్వాస ఫలితములు విశదమ్ముగా నీకు వివరింతు విను క్రైస్తవా విశ్వాస వంతునికి విశ్వమ్ములోపల మ వశ్యమ్మొదవు క్రైస్తవా ||విశ్వా||	".Trim().ToString());
            TeluguSongList.Add("	390: సందియము వీడవే నా మనసా యా నందమున గూడవే సందియము లింకేల నిను సుఖ మొందఁ జేసెడు క్రీస్తు రక్తపు బిందువులు శుభవార్తవాక్యము లందుఁ గని తెలి వొంది బ్రతుకుచు ||సందియము||	".Trim().ToString());
            TeluguSongList.Add("	391: విశ్వాసమే విజయము విను ప్రియుఁడా య విశ్వాస మపజయము విశ్వాసాయుతమైన విసుకని సుకార్యములే విశ్వాసవంతునికి విజయ మొసంగును నిజము ||విశ్వాసమే||	".Trim().ToString());
            TeluguSongList.Add("	392: ఓ దేవ రక్షకా నే విశ్వాసంబుతో నిన్ జూతును నా మొఱ్ఱాలించుము నా పాప మార్పుము నన్నింక నీ దరిన్ సదా యుంచు.	".Trim().ToString());
            TeluguSongList.Add("	393: నీ చరణములే నమ్మితి నీ పాదములే పట్టితిఁ బట్టితిఁ బట్టితి ||నీ చరణములే||	".Trim().ToString());
            TeluguSongList.Add("	394: ఎందు కే చింతించెదవు నా డెందమా నీ కందమా యిందాఁక రక్షించినవాఁ డిఁకను నిన్ను విడువఁబోడు ||ఎందుకే||	".Trim().ToString());
            TeluguSongList.Add("	395: మనమీ మనుమీ మనస నీ వనుదినము యేసుని సరస ఘన ధనముల నీవు రోసి దేవ తనయుని కృపఁ దల పోసి ||మనమీ||	".Trim().ToString());
            TeluguSongList.Add("	396: దేవ దాసపాలక రాజా రావే జీవముల ప్రదాతవై ప్రకాశ మొందఁగా దేవా దేవా దీన పోషకా ||దేవ||	".Trim().ToString());
            TeluguSongList.Add("	397: ఎన్నడు నెడఁబాయ నే కొల(ది విడనాఁడ ననిన తండ్రి నిరత మన్ని బాధలయందు నన్ని దుఃఖములందు నన్ను ఁ బ్రోచు ||ఎన్నడు||	".Trim().ToString());
            TeluguSongList.Add("	398: జీవమా చింతించకుండు నిన్నుఁ గావ వచ్చిన యేసు కరుణా మయుండు జీవమా చింతించి క్షితి మూరె డైన నీ జీవము కున్నతిఁ జేసెదవా కావున నీ చింతా క్రాంతము వెడలించు దేవుఁ డెహోవ నీ దిక్కని నమ్మి ||జీవమా||	".Trim().ToString());
            TeluguSongList.Add("	399: భయము నొందకుము క్రైస్తవ సహోదర యింక భయము నొంద కుము భయము నొందకుము హృదయ వాసుఁడగు క్రీస్తు దయ నీ తలఁపు లెల్ల రయముగ నెరవేర్చు ||భయము||	".Trim().ToString());
            TeluguSongList.Add("	400: యేసునాధుని సేవ యిపుడు మాకబ్బెను వెఱవము వెఱవము యేసు దాసులతో బొత్తు భక్తి మా కమరెను జడియము జడియము ||యేసు||	".Trim().ToString());
            TeluguSongList.Add("	401: వెరువనేల మనసా క్రీస్తుని వేఁడవే నా మనసా యిరుకునఁ బడి యెడు వేళలోఁ క్రీస్తుని చరణము చేరువ జేరిన సుఖ మది ||వెరువ||	".Trim().ToString());
            TeluguSongList.Add("	402: దినదినముకు దిక్కు నీవే మా దేవుఁడా మమ్ము కనిపెట్టి కాపాడ నెపుడు కర్త వీవే కర్త వీవే ||దినదినమునకు||	".Trim().ToString());
            TeluguSongList.Add("	403: పాడుదును క్రీస్తు పేర పదము నెంతో వేడుదు నా దివ్యాగురు నివ్విధముఁ జూడఁజూడ మదిలో నెంతో వేడుకగా మీఱె వింత ఱేడుఁ బోలినవా డిహ లేఁడు లేఁడందు నహహా ||పాడుదును||	".Trim().ToString());
            TeluguSongList.Add("	404: జడియకుము నే నే యున్నానని కడు నెనరు వాక్కిచ్చిన యేసుని యడుగుజాడలు వెంబడించి నడుచుకొనరాదా జీవా యిడుమ లధికము గలిగిన ప్రభుని కడకుఁ జేరరాదా ||జడియకుము||	".Trim().ToString());
            TeluguSongList.Add("	405: దేవుఁడే నా కాశ్రయంబు దివ్యమైన దుర్గము మ హా వినోదుఁ డాపదల స హాయుఁడై నన్ బ్రోచును అభయ మభయ మభయ మెప్పు డానంద మానంద మానంద మౌఁగ ||దేవుఁడే||	".Trim().ToString());
            TeluguSongList.Add("	406: మనసు నిచ్చి వినుమా మది ననుసరించి చనుమా ||మనసు||	".Trim().ToString());
            TeluguSongList.Add("	407: ప్రీతిగల మన యేసుఁ డెంతో గొప్ప మిత్రుఁడు మితిలేని దయచేత హత్తుచుఁ బ్రేమించును క్రీస్తునొద్ద మన భార మంత నప్పగించినన్ శక్తిగల యేసుచేత మోఁత లెల్ల వీడును	".Trim().ToString());
            TeluguSongList.Add("	408: యేసూ, యాత్మ ప్రియుఁడా నిన్ను నాశ్రయించితి లేవఁగా దరంగముల్ గాలివాన కొట్టఁగా లోకబాధ లన్నిఁటన్ నన్ను దాఁచు రక్షకా రేపునకు నడ్పుము నాదు యాత్మన్ బ్రోవుము	".Trim().ToString());
            TeluguSongList.Add("	409: మా శ్రమ లన్ని తీర్చితివి మాకు విశ్రాంతి నిచ్చితివి మహిమ నీకుఁ గల్గెడును మిత్రుఁడవైన రక్షకుఁడా!	".Trim().ToString());
            TeluguSongList.Add("	410: అలసటపడ్డ నీవు దేవోక్తి విను రా, నా యొద్ద, సు విశ్రాంతి పొందుము	".Trim().ToString());
            TeluguSongList.Add("	411: ఓ దేవ నేను నీ దాపున నుండెదన్ నీ దాపున నుండెదన్ నా దేవ నను లేపు నవి సిల్వ శ్రమలైనన్ నీ దాపున నుండు నీ సేవకుని పాట ||ఓ దేవ||	".Trim().ToString());
            TeluguSongList.Add("	412: కొండల తట్టు నేఁ గోర్కెతోడ నాదు కన్ను లెత్తెద నిప్పుడే దండియౌ సహాయ మెచటి నుండి నాకు వచ్చునో యండయౌ ప్రభునిచే స హాయంబు కలుగును ||గొండల||	".Trim().ToString());
            TeluguSongList.Add("	413: నీవు తోడై యున్నఁజాలు యేసు నిత్యము నాకది మేలు నీవు ధరణినుండు నీచపాపుల నెల్లఁగావఁ బ్రేమ వచ్చి ఘన ప్రాణ మిడినట్టి ||నీవు||	".Trim().ToString());
            TeluguSongList.Add("	414: నీవే నా ప్రియుఁడవు యేసు ప్రభు నీవే నా యొడయుఁడవు నీవే యనాది దేవ పుత్రుండవు నీవే లోక మెల్ల నేర్పుగఁ జేసితివి ||నీవే||	".Trim().ToString());
            TeluguSongList.Add("	415: ఓ దేవా నన్నుఁ బ్రోవ నీదె భార మయ్య రావే ||యో దేవా||	".Trim().ToString());
            TeluguSongList.Add("	416: నాధ యేసు నాధ క్రీస్తు నాధ నేననాధ సాధు జనులఁ బ్రోచు సదయు నీ దయ కాదా ||నాధ||	".Trim().ToString());
            TeluguSongList.Add("	417: నాకై చీలిన యుగ యుగముల శిల ముక్తి నా కిమ్ము శ్రీ యేసువా లోక రక్షక నన్ను నీ లోపల దాగి వీఁకతోడను నుండనిమ్ము సద్గుణ శీలా ||నాకై||	".Trim().ToString());
            TeluguSongList.Add("	418: ముక్తిఁ గనరే మీ మనంబుల శక్తిగల రక్షకుని పలుకులు ముక్తిసాధన ములకు మూలము భక్తిగొని యానంద మొందరే ||ముక్తి||	".Trim().ToString());
            TeluguSongList.Add("	419: యేసూ నా యాత్మ రక్షకుండ నన్ను వాసిగా నీ రొమున నుండఁ జేసియు జల రాసులను నీవు తీసివేయుము మోసములఁ ద్రోసి ||యేసూ||	".Trim().ToString());
            TeluguSongList.Add("	420: యేసు కరుణ యిదియే మా శరణు యేసు కరుణ ||	".Trim().ToString());
            TeluguSongList.Add("	421: శరణుఁ జొచ్చితి యేసునాధుఁడ శక్తిహీనతఁ గల్గె నా దరణ మిమ్మిల నెవ్వఁ బొందితి దవ్వుసేయక కావవే ||శరణు||	".Trim().ToString());
            TeluguSongList.Add("	422: యెహోవ నా కాపరి యిఁకఁ గొదు వేమి ||యెహోవా||	".Trim().ToString());
            TeluguSongList.Add("	423: సర్వశక్తుఁడ నిర్మలాత్ముఁడ సర్వజనసంరక్షకా మా సర్వపాపముఁ బరిహరింప నీ సర్వమహిమను విడితివా ||సర్వ||	".Trim().ToString());
            TeluguSongList.Add("	424: శరణు శరణు యేసు దేవా నన్నుఁ గరుణింపవే నిత్య జీవా పరమ దేవుని తనూ భవుఁడవై ధరణిలో నర రూపమైతివి నరులను రక్షింప ||శరణు||	".Trim().ToString());
            TeluguSongList.Add("	425: నాధా! సముయేలు రీతి నీ యామోద శబ్దము సేవకుఁడ నైన నన్ను నాతో డాలకింపనీ నాతో నీవేమందువో నే నాలించువాఁడను.	".Trim().ToString());
            TeluguSongList.Add("	426: నా రక్షకుని వెంబడింతు నన్నిటన్ ఘోరమైన కొండలైన జంకొందను సురక్షితంబుగాను నేను వెళ్లుదున్ బరమ కిరీట మొందువరకు. ||యేసున్ నేను ఎన్నఁ డెన్నడును ఆసతో నన్నిటన్ వెంబడింతును భాసురంబౌ ప్రభు వెంట కన్నుల్ మూసికొని యొక్కఁడేని వెళ్లుదున్||	".Trim().ToString());
            TeluguSongList.Add("	427: యేసూ, నా ప్రభువా, నీ ప్రేమ లేకున్న నా యాత్మ కేదియు విశ్రాంతి నియ్యదు. ||ఒక్కొక్క గంట నేను నిన్నాశించుకొందు నీ యాశీర్వాద మిమ్ము నా రక్షకుఁడా||	".Trim().ToString());
            TeluguSongList.Add("	428: ఓ దివ్యకాంతి, మబ్బు కమ్మఁగా నన్నడ్పుము నాయింటి త్రోవ దప్పిపోతిని నన్నడ్పుము నాకాళ్ల జారకుండఁ గాచుచు ఒక్కొక్క మెట్టు భద్ర పర్చుమా	".Trim().ToString());
            TeluguSongList.Add("	429: నడ్పుమీ, మహా యెహోవా లోక యాత్ర యందున నీదు శక్తి నాకు	".Trim().ToString());

            dgTel.ItemsSource = TeluguSongList;
            if (rdEnlish.IsChecked == true)
            {
                dgTel.Visibility = Visibility.Visible;
                dgTel.Visibility = Visibility.Hidden;
            }
            else
            {
                dgEng.Visibility = Visibility.Hidden;
                dgTel.Visibility = Visibility.Visible;
            }


        }

        private void getESongs(string v)
        {
            string mydocpath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            string[] para;
            string Text;
            string nTExt;
            StringBuilder strbldr = new StringBuilder();
            System.IO.StreamReader reader;
            // StreamWriter sw = new StreamWriter(@"C:\temp\t.txt");
            //    for (int i=1; i < 984; i++) {

            reader = new System.IO.StreamReader(@"MH\" + v + ".txt");
            Text = reader.ReadToEnd();
            reader.Close();
            para = Text.Split('\n').Select(m => m.Trim('\r')).ToArray();
            if (para[0].Length > 0) {
                nTExt = v.ToString() + ":" + para[1].ToString().Trim() + "\n";
            }
            else {
                nTExt = para[1].ToString().Trim() + ":" + para[2].ToString().Trim() + "\n";
            }



            //   sw.WriteLine(nTExt);


        }
          
        

        private void getTSongs(string v)
        {
            
                 using (StreamReader file = File.OpenText(@"ts\10.json"))
                 using(JsonTextReader reader = new JsonTextReader(file))
              {
                Newtonsoft.Json.Linq.JObject o2 = (Newtonsoft.Json.Linq.JObject)Newtonsoft.Json.Linq.JToken.ReadFrom(reader);
                // 
                string title;
                //"ragam":"కాంభోజి","SongId":"1","thalam":"ఆట","author":"బేళాళ జాన్","Album"
                string ragam;
#pragma warning disable CS0168 // The variable 'SongId' is declared but never used
                string SongId;
#pragma warning restore CS0168 // The variable 'SongId' is declared but never used
                string thalam;
                string author;
                string verse;
                Newtonsoft.Json.Linq.JArray a = (Newtonsoft.Json.Linq.JArray)o2["Verses"];
                int cnt = a.Count;
                title= (string)o2.SelectToken("title");
                ragam = (string)o2.SelectToken("ragam");
                thalam = (string)o2.SelectToken("thalam");
                author = (string)o2.SelectToken("author");
                for (int i=0; i<= cnt; i++) { 
                verse = (string)o2.SelectToken("Verses[" + i + "]");
                }
            }
        }

        private void fillBooks()
        {
                var rootFolder = System.IO.Path.GetDirectoryName(
    System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
            var xmlFilePath = rootFolder + @"\telugu.xml";


            // System.Diagnostics.Process.Start(path);

            TeluguDataset.ReadXml(@"telugu.xml");

            //    TeluguDataset.ReadXml(filePath);
               EnglishDataset.ReadXml(@"kjv.xml");
            dgBooks.ItemsSource = EnglishDataset.Tables["b"].DefaultView;
             
           wn.Show();
        }

 

        private void Label_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            //filling the Chapters in the grid
            lblVerse.Content = "";
            BookName = "";
            Label lbl = (Label)sender;
            BookName = lbl.Content.ToString();
            string x = lbl.Tag.ToString();
            dgChapters.ItemsSource = null;
            dgChapters.Items.Clear();

            dgVerse.ItemsSource = null;
            dgVerse.Items.Clear();

         EnglishDataset.Tables["c"].DefaultView.RowFilter = "b_Id=" + x;
            dgChapters.ItemsSource = EnglishDataset.Tables["c"].DefaultView;
            lblVerse.Content = BookName;

        }

        private void Label_MouseLeftButtonUp_1(object sender, MouseButtonEventArgs e)
        {
            //Filling the Versers
            Label lbl = (Label)sender;
            string x = lbl.Tag.ToString();
            ChapterID = x;
            Chapter = lbl.Content.ToString();
            dgVerse.ItemsSource = null;
            

            RadioButton rd = new RadioButton();
         //   Button2_click(Button2, null)
            English_Checked(English, null);
        }

        private void Label_MouseLeftButtonUp_2(object sender, MouseButtonEventArgs e)
        {

        }

        private void English_Checked(object sender, RoutedEventArgs e)
        {
            var button = sender as RadioButton;
            if (ChapterID.Length > 0) { 
            // ... Display button content as title.
            string lang = button.Content.ToString();
            if (dgVerse != null) { dgVerse.ItemsSource = null; 
            if (lang.ToUpper() == "English".ToUpper() && button.IsChecked==true)
            {
                EnglishDataset.Tables["v"].DefaultView.RowFilter = "c_Id=" + ChapterID;
                dgVerse.ItemsSource = EnglishDataset.Tables["v"].DefaultView;
            }
            else
            {
                TeluguDataset.Tables["v"].DefaultView.RowFilter = "c_Id=" + ChapterID;
                dgVerse.ItemsSource = TeluguDataset.Tables["v"].DefaultView;
            }
           
            lblVerse.Content = BookName.ToString() + " : " + Chapter.ToString();
            }
            }
        }

        private void NewCommand_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.CanExecute = true;
        }

       

        private void mnuNew_Click(object sender, RoutedEventArgs e)
        {
            //  Image img= new Image();
            // img.Source = new BitmapImage(new Uri(@"/Images/dishtype.png", UriKind.Relative));
        }

        private void colForeColor_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            dgVerse.Foreground = new SolidColorBrush(colForeColor.SelectedColor.Value);  
        }

        private void btnMove_Click(object sender, RoutedEventArgs e)
        {

        } 

        private void colBackColor_SelectedColorChanged(object sender, RoutedPropertyChangedEventArgs<Color?> e)
        {
            dgVerse.Background = new SolidColorBrush(colBackColor.SelectedColor.Value);

        }

        

        private void txtVerse_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            //displaying the verses in second window
            TextBlock lbl = (TextBlock)sender;
            string verse = lbl.Text.ToString();
            string vNumber = lbl.Tag.ToString();
            lblVerse.Content = BookName.ToString() + " : " + Chapter.ToString() + " : " + vNumber.Trim().ToString();
            txtLiveVerse.Width = 100;
            txtLiveVerse.VerticalAlignment = VerticalAlignment.Stretch;
            txtLiveVerse.HorizontalAlignment = HorizontalAlignment.Stretch;
            txtLiveVerse.Text = verse.ToString();
           
            wn.txtProjector.Text = verse.ToString();
            wn.Owner = this;
            
            // this.WindowState = WindowState.Normal;
            //  this.Activate();

            
            if (wn.IsActive ==true)
            {
                wn.Activate();
                wn.UpdateLayout();

            } else {
                // Window1 wn = new Window1();
                
             
                wn.Activate();
                wn.UpdateLayout();
            }
           
            
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = true;
            Application.Current.Shutdown();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
             
        }

        private void tglLive_Click(object sender, RoutedEventArgs e)
        {

            if (tglLive.IsChecked == true)
            {
                 
                 wn.Visibility = Visibility.Visible; 
            }

            else
            {

                wn.Visibility = Visibility.Hidden;

            }
        }

        private void rdEnlish_Checked(object sender, RoutedEventArgs e)
        {
            if (dgEng!=null && dgEng.IsVisible == false)
            {
                dgEng.Visibility = Visibility.Visible;
                dgTel.Visibility = Visibility.Hidden;

            }
        }
        private void rdTelugu_Checked(object sender, RoutedEventArgs e)
        {
            if (dgTel!=null && dgTel.IsVisible == false)
            {
                dgTel.Visibility = Visibility.Visible;
                dgEng.Visibility = Visibility.Hidden;

            }
        }
        
        private void dataGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            int ind = dgEng.SelectedIndex;
            MessageBox.Show(ind.ToString());
            stkLive.Children.Clear();
            
        }

        private void dgTeluguSongs_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {

        }

        private void TabItem_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            // TextBlock lbl = (TextBlock)sender;
            TabItem tbitem = (TabItem)sender;
          if(tbitem.Header.ToString().ToUpper() == "images".ToUpper()) {
                List<Image> lstImagesList = new List<Image>();
                Image imgTemp;

                List<string> lstFileNames = new List<string>(System.IO.Directory.EnumerateFiles(@"images\Background\", "*.jpg"));
               
                foreach (string fileName in lstFileNames)
                {
                    fileName.Replace("\\","//");
                    imgTemp = new Image();
                    imgTemp.Source = new BitmapImage(new Uri(fileName, UriKind.Relative));
                    imgTemp.Height = imgTemp.Width = 100;
                     
                    wrpimg.Children.Add(imgTemp);
                    lstImagesList.Add(imgTemp);
                }
                 // lstImages.ItemsSource = lstImagesList;
            }
        }
    }
}
