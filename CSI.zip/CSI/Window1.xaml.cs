﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace CSI
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        public Window1()
        {
            InitializeComponent();
           this.Loaded += MainWindow_Loaded;
        }

        void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            this.Left = SystemParameters.PrimaryScreenWidth + 100;
            this.WindowState = System.Windows.WindowState.Maximized;
            this.WindowStyle = WindowStyle.None; ;
            //    IntPtr handle = this.app.getWindowByName("projWin");
            double height = this.MaxHeight;
            double width = this.MaxWidth;
           // txtProjctor.Width = width;
            

           // txtProjctor.Height = height;
           // txtProjctor.VerticalAlignment = VerticalAlignment.Stretch;
            // txtProjctor.FontSize = 500;

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = false;
            this.ShowActivated = false;
           // this.Close();
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            base.Close();
        }
    }
}